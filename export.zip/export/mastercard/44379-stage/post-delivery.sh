echo 'changeit' | /usr/local/bin/cryptogetadmin -create -label X509-Default-non-PRD
 /usr/local/bin/cryptogetadmin -label X509-Default-non-PRD -cacl " : : : : : : :secadmin" 
 /usr/local/bin/cryptogetadmin -label X509-Default-non-PRD -cacl " : : : :mc: : : " 
rm 44379-stage-mdes-mastercard-int-desktop.tar
 chown -Rf 0:0  /apps_data_01/security/keystores/44379-stage-mdes-mastercard-int-desktop
rm /apps_data_01/security/keystores/post-delivery.sh
