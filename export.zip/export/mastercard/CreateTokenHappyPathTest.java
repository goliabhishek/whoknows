package com.mastercard.mdes.automation.manitoba_regression.tests.functional.createToken;

import com.mastercard.mdes.automation.manitoba_regression.support.Constants;
import com.mastercard.mdes.automation.manitoba_regression.tests.FunctionalTests;
import com.mastercard.mdes.test.automation.core.*;
import com.mastercard.mdes.test.automation.core.db_comparison.ExcelHandler;
import com.mastercard.mdes.test.automation.core.db_comparison.MiscUtilties;
import com.mastercard.mdes.test.automation.core.db_comparison.MqPerformdpTool;
import com.mastercard.mdes.test.automation.core.db_comparison.PrvsnRqstComparisonTool;
import com.mastercard.mdes.test.automation.core.mdes_utilities.MDESUtilities;
import com.mastercard.mdes.test.automation.core.request_builder.JsonObjectMapper;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenParser;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenUtil;
import org.easetech.easytest.annotation.DataLoader;
import org.easetech.easytest.annotation.Param;
import org.easetech.easytest.loader.LoaderType;
import org.easetech.easytest.runner.DataDrivenTestRunner;
import org.junit.Assume;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.*;

import static org.junit.Assert.assertTrue;

/**
 * Created by E055798 on 8/16/2016.
 */


@Category(FunctionalTests.class)
@RunWith(DataDrivenTestRunner.class)
@DataLoader(filePaths={Constants.PATH_FUNCTIONAL_CREATETOKEN+"/testCreateTokenHappyPath.xls"}, loaderType= LoaderType.EXCEL, writeData=false)

public class CreateTokenHappyPathTest {

    static private String wltPrdvrId;
    static private String storageTypeCd;
    static private String tknTypeCd;
    static private String fpanHash;

    //standard definitions (tester to update):
    static private String RELATIVE_PATH = Constants.PATH_FUNCTIONAL_CREATETOKEN;
    static private String TEST_METHOD_NAME = "testCreateTokenHappyPath";

    //standard definitions (do not update):
    static private String DATASOURCE_PATH = Constants.PATH_RESOURCES + "/" + RELATIVE_PATH + "/" + TEST_METHOD_NAME + ".xls";
    //datasourcePath = "src/test/resources/input_validation/CreateTokenInputValidation.xls";

    static private Map fullDataMap;

    //testcase specific definitions:
    private static final boolean LOG_TRUE = true;
    private Map<String, Object> excelRow;
    private Map<String, String> excelRowStr;

    private CreateTokenUtil crteTknUtil;
    private Map<String, String> crteTknReqMap;
    private Map<String, String> crteTknRspMap;
    private Map<String, String> crteTknMiscMap;
    static private String rowNumToBeExcecuted;


    @BeforeClass
    public static void setUp() throws Exception {
        LogHandler.debugPrint(DATASOURCE_PATH);
        fullDataMap = ExcelHandler.generateFullRecordMapFromExcel(DATASOURCE_PATH);
        ReportLogUtils.logTestName(Constants.PROJECT, RELATIVE_PATH, TEST_METHOD_NAME);
        wltPrdvrId = PropertyHandler.getEnvironmentProperty("manitobaDefaultWltPrvdrId");
        storageTypeCd = PropertyHandler.getEnvironmentProperty("manitobaDefaultStrgTypeCode");
        tknTypeCd = PropertyHandler.getEnvironmentProperty("manitobaDefaultTknTypeCode");

        printRequiredTables();

    }

    @Test
    public void testCreateTokenHappyPath(@Param(name = "inTestNbr") String inTestNbr) throws Exception   {

        loadExcelRow(inTestNbr,TEST_METHOD_NAME);
        //DbResetUtil.deleteMappingBySeid(excelRowStr.get("inSeid"),wltPrdvrId);
        generateFpanHash();
        createTokenRestCall();
        validateCreateTokenRsp();
        validateData();
        if(excelRowStr.get("inFpanCardDescDataFpan2")!= null) {
            validateDvcWithPrevRec();
        }
        validateMqPerformdp();

        if(!excelRowStr.get("expCnt.MSA").equals("0")) {
            validateMckServActv();
        }
        if(excelRowStr.get("inInitialTokenState").equals("Suspended-OTP")) {
            printPDMSPND();
        }

        if(excelRowStr.get("UpdAMSMckMapTbl").equals("Y")) {
            updateAmsMckMap();
        }


    }


    private void loadExcelRow(String inTestNbr,String testMethodName) {
        excelRow = MiscUtilties.createExcelRowMap(fullDataMap, testMethodName, inTestNbr);
        Assume.assumeTrue(TestUtils.isTestRunnable(inTestNbr, excelRow.get("inExec"), rowNumToBeExcecuted));
        excelRowStr = JsonObjectMapper.createStringStringMap(excelRow);
        LogHandler.debugPrint("excelRowStr=" + excelRowStr.toString());
        ReportLogUtils.logTestRowDesc(excelRowStr);
    }


    private void createTokenRestCall() throws Exception {
        crteTknUtil = new CreateTokenUtil();
        LogHandler.debugPrint("createTokenRestCall");


        crteTknUtil
                .setInHttpHdrXpod(excelRowStr.get("inHttpHdrXPod"))
                .setInDbResetIndicator("Y")
                .setInDbResetFpan(excelRowStr.get("inFpanCardDescDataFpan"))
                .setinFpanCardDescDataFpan(excelRowStr.get("inFpanCardDescDataFpan"))
                .setinFpanCardDescDataExpiry(excelRowStr.get("inFpanCardDescDataExpiry"))
                .setInHttpHdrSysUserId(excelRowStr.get("inHttpHdrSysUserId"))
                .setInDeviceType(excelRowStr.get("inDVcTypeCode"))
                .setInSeid(excelRowStr.get("inSeid"))
                .setInInitialTokenState(excelRowStr.get("inInitialTokenState"))
                .run();

        crteTknReqMap = crteTknUtil.getOutRequestMap();
        crteTknRspMap = crteTknUtil.getOutResponseMap();
        crteTknMiscMap = crteTknUtil.getOutMiscellaneousMap();

    }

    private void createTokenRestCall(String fpan) throws Exception {
        crteTknUtil = new CreateTokenUtil();
        LogHandler.debugPrint("createTokenRestCall");

                    crteTknUtil
                            .setInHttpHdrXpod(excelRowStr.get("inHttpHdrXPod"))
                            .setInDbResetIndicator("Y")
                            .setInDbResetFpan(fpan)
                            .setinFpanCardDescDataFpan(fpan)
                            .setinFpanCardDescDataExpiry(excelRowStr.get("inFpanCardDescDataExpiry"))
                            .setInHttpHdrSysUserId(excelRowStr.get("inHttpHdrSysUserId"))
                            .setInDeviceType(excelRowStr.get("inDVcTypeCode"))
                            .setInSeid(excelRowStr.get("inSeid"))
                            .run();

        //getters:
        crteTknReqMap = crteTknUtil.getOutRequestMap();
        crteTknRspMap = crteTknUtil.getOutResponseMap();
        crteTknMiscMap = crteTknUtil.getOutMiscellaneousMap();
    }

    private void validateCreateTokenRsp() throws Exception {
        final String EXP_PREFIX = "expRsp.";
        Map<String, String> expectedMap = MiscUtilties.extractByPrefix(excelRow, EXP_PREFIX);


        CreateTokenParser.validateResponse(
                EXP_PREFIX,
                expectedMap,
                crteTknRspMap);
    }

    private void updateDvc() throws Exception {
        Map<String,String> map = new LinkedHashMap<>();


        map.put("WLT_PRVDR_DVC_TYPE_CD", "");
        map.put("NTWRK_DVC_TYPE_CD ","");
        DataUtils.updDvc(
                excelRowStr.get("inSeid"),
                map,
                LOG_TRUE);

    }
    private void updateAmsMckMap() throws Exception {

        DataUtils.updateAmsMckMapRespOvrdeTxt(
                crteTknMiscMap.get("tokenPan"), excelRowStr.get("inRespOvrdeTxt"));

    }


    private void validateData() throws Exception{

            Map<String, String> PDMrecord = validatePanDvcMap();
        if(!excelRowStr.get("expPRVRQSTCount").equals("0")) {
            validatePrvsnRqst();
            validatePanDataEnc(PDMrecord.get("DVC_PAN_DATA_ENC_ID"));

        }

    }

    private void validateDvcWithPrevRec() throws Exception {


        validateCreateTokenRsp();

        List<Map<String, Object>> DvcRecBefUpdt = DataUtils.getDvcListBySeidAndWID(excelRowStr.get("inSeid"),wltPrdvrId,LOG_TRUE);
        LogHandler.debugPrint("Before Updating Dvc :" +DvcRecBefUpdt);

        updateDvc();



        List<Map<String, Object>> DvcRecAftStngToNull = DataUtils.getDvcListBySeidAndWID(excelRowStr.get("inSeid"),wltPrdvrId,LOG_TRUE);

        LogHandler.debugPrint("After Updating Dvc :" +DvcRecAftStngToNull);
        createTokenRestCall(excelRowStr.get("inFpanCardDescDataFpan2"));

        validateCreateTokenRsp();

        List<Map<String, Object>> DvcRecAftRestCallwthNewData = DataUtils.getDvcListBySeidAndWID(excelRowStr.get("inSeid"),wltPrdvrId,LOG_TRUE);
        LogHandler.debugPrint("After First RestCall Before Updating DVC Records To Null :"+DvcRecBefUpdt.toString());
        for(int j=0; j< DvcRecAftRestCallwthNewData.size();  j++)
        {
            DvcRecAftRestCallwthNewData.get(j).remove("RPLCTN_UPDT_TS");
            DvcRecBefUpdt.get(j).remove("RPLCTN_UPDT_TS");
            String wltPrvdrDvcTypeCdAfterUpdate = DvcRecAftRestCallwthNewData.get(j).get("WLT_PRVDR_DVC_TYPE_CD").toString();
            String ntwrkDvcTypeCdAfterUpdate = DvcRecAftRestCallwthNewData.get(j).get("NTWRK_DVC_TYPE_CD").toString();
            assertTrue("WLT_PRVDR_DVC_TYPE_CD is Null",(wltPrvdrDvcTypeCdAfterUpdate != null && !wltPrvdrDvcTypeCdAfterUpdate.isEmpty() && !wltPrvdrDvcTypeCdAfterUpdate.trim().isEmpty()));
            assertTrue("NTWRK_DVC_TYPE_CD is Null",(ntwrkDvcTypeCdAfterUpdate != null && !ntwrkDvcTypeCdAfterUpdate.isEmpty() && !ntwrkDvcTypeCdAfterUpdate.trim().isEmpty()));
            assertTrue("WLT_PRVDR_DVC_TYPE_CD is Not Equal to Previous One",wltPrvdrDvcTypeCdAfterUpdate.equals(DvcRecBefUpdt.get(j).get("WLT_PRVDR_DVC_TYPE_CD").toString()));
            assertTrue("NTWRK_DVC_TYPE_CD is  Not Equal to Previous One",ntwrkDvcTypeCdAfterUpdate.equals(DvcRecBefUpdt.get(j).get("NTWRK_DVC_TYPE_CD").toString()));

        }
        LogHandler.debugPrint("After Updating DVC Records To Null and After Second Rest Call :"+ DvcRecAftRestCallwthNewData.toString());
       assertTrue("Before And After Records Don't Match"+ "\n" +DvcRecBefUpdt.toString()+ "\n" +DvcRecAftRestCallwthNewData.toString(), DvcRecBefUpdt.equals(DvcRecAftRestCallwthNewData));


    }

    private static void printRequiredTables() throws Exception {
        Map<String,String> map = new HashMap<>();


        DataUtils.getDvcStrgTypeList(storageTypeCd,LOG_TRUE);

        DataUtils.getNtwrkDvcTypeLkpList(storageTypeCd,tknTypeCd,LOG_TRUE);

        DataUtils.getWltPrvdrDvcTypeList(wltPrdvrId,tknTypeCd,LOG_TRUE);

    }

    private void generateFpanHash() throws Exception {

        fpanHash = MDESUtilities.hash(excelRowStr.get("inFpanCardDescDataFpan"));
        LogHandler.debugPrint("FPAN HASH : "+fpanHash);
        LogHandler.reportPrint("FPAN HASH : "+fpanHash);
    }

    private Map<String, String> validatePanDvcMap() throws Exception {

        LogHandler.debugPrint("Validating PANDVCMAP Table ");
        Map<String,String> map = new LinkedHashMap<>();

        map.put("SEC_ELMT_ID", excelRowStr.get("inSeid"));
        map.put("HASH_FUND_PAN ",fpanHash);
        List<Map<String, Object>> PDMrecList = DataUtils.getPanDvcMapByMap(map,LOG_TRUE);
        int count =PDMrecList.size();

        LogHandler.debugPrint("Numnber of records Based on FpanHash and Seid : "+Integer.toString(count));
        Map<String, String> record = null;
        AssertionUtility.equals("Number of records Based on FpanHash and Seid are not equal to One",excelRowStr.get("expPDMCount"),count);

        if (count == 1) {

            record =JsonObjectMapper.createStringStringMap(PDMrecList.get(0));
            AssertionUtility.notNull("MAP_ID",record.get("MAP_ID"));
            AssertionUtility.notNull("DVC_PAN_DATA_ENC_ID",record.get("DVC_PAN_DATA_ENC_ID"));
            AssertionUtility.notNull("HASH_DVC_PAN",record.get("HASH_DVC_PAN"));
            if(!record.get("MAP_STAT_CD").equals("D")){
                AssertionUtility.notNull("DVC_PAN_UNQ_ID",record.get("DVC_PAN_UNQ_ID"));
                AssertionUtility.notNull("FUND_PAN_UNQ_ID",record.get("FUND_PAN_UNQ_ID"));
            }
            else{
                AssertionUtility.equals("DVC_PAN_UNQ_ID",null,record.get("DVC_PAN_UNQ_ID"));
                AssertionUtility.equals("FUND_PAN_UNQ_ID",null,record.get("FUND_PAN_UNQ_ID"));
            }
            AssertionUtility.notNull("DVC_PAN_EXPIR_DT",record.get("DVC_PAN_EXPIR_DT"));
            AssertionUtility.equals("MAP_STAT_CD",excelRowStr.get("expPDM.mapStatCd"),record.get("MAP_STAT_CD"));
            AssertionUtility.equals("SEC_ELMT_ID",excelRowStr.get("inSeid"),record.get("SEC_ELMT_ID"));
            AssertionUtility.equals("APPL_AID_TXT",excelRowStr.get("expPDM.ApplAidTxt"),record.get("APPL_AID_TXT"));
            AssertionUtility.equals("WLT_PRVDR_ID",excelRowStr.get("expPDM.WltPrvdrId"),record.get("WLT_PRVDR_ID"));
            AssertionUtility.equals("FUND_EXPIR_DT",excelRowStr.get("expPDM.FundExpirDt"),record.get("FUND_EXPIR_DT"));
            AssertionUtility.equals("CARDLET_ID",excelRowStr.get("expPDM.CardletId"),record.get("CARDLET_ID"));
            AssertionUtility.equals("SSD_AID_TXT",excelRowStr.get("expPDM.SsdAidTxt"),record.get("SSD_AID_TXT"));
            AssertionUtility.equals("DPAN_RNG_STRT_NUM",excelRowStr.get("expPDM.DpanRngStrtNum"),record.get("DPAN_RNG_STRT_NUM"));
            AssertionUtility.equals("FPAN_RNG_STRT_NUM",excelRowStr.get("expPDM.FpanRngStrtNum"),record.get("FPAN_RNG_STRT_NUM"));
            AssertionUtility.equals("RECYCLE_DPAN_SW",excelRowStr.get("expPDM.RecycleDpanSw"),record.get("RECYCLE_DPAN_SW"));
            AssertionUtility.equals("APPLET_VER_NUM",excelRowStr.get("expPDM.AppletVerNum"),record.get("APPLET_VER_NUM"));
            AssertionUtility.equals("DPAN_RECLM_SW",excelRowStr.get("expPDM.DpanReclmSw"),record.get("DPAN_RECLM_SW"));
            AssertionUtility.equals("MBL_WLT_ID",excelRowStr.get("expPDM.MblWltId"),record.get("MBL_WLT_ID"));
            AssertionUtility.equals("TOKEN_RQSTR_ID",excelRowStr.get("expPDM.TokenRqstrId"),record.get("TOKEN_RQSTR_ID"));
            AssertionUtility.equals("TOKEN_TYPE_CD",excelRowStr.get("expPDM.TokenTypeCd"),record.get("TOKEN_TYPE_CD"));
            AssertionUtility.equals("NFC_CPBL_SW",excelRowStr.get("expPDM.NfcCpblSw"),record.get("NFC_CPBL_SW"));
            AssertionUtility.equals("DSRP_ENBL_SW",excelRowStr.get("expPDM.DsrpEnblSw"),record.get("DSRP_ENBL_SW"));
            AssertionUtility.equals("PAYMT_APPL_INSTNCE_ID",excelRowStr.get("inSeid"),record.get("PAYMT_APPL_INSTNCE_ID"));
            AssertionUtility.equals("FPAN_SUF_NAM",excelRowStr.get("expPDM.FpanSufNam"),record.get("FPAN_SUF_NAM"));
            AssertionUtility.equals("CLNT_APPL_ID",excelRowStr.get("expPDM.ClntApplId"),record.get("CLNT_APPL_ID"));
            AssertionUtility.equals("TOKEN_STRG_TYPE_CD",excelRowStr.get("expPDM.TokenStrgTypeCd"),record.get("TOKEN_STRG_TYPE_CD"));
            AssertionUtility.equals("AUX_TOKEN_SW",excelRowStr.get("expPDM.AuxTokenSw"),record.get("AUX_TOKEN_SW"));
            AssertionUtility.equals("HASH_FUND_PAN",fpanHash,record.get("HASH_FUND_PAN"));
            AssertionUtility.jdbcDateGreaterThan("CRTE_DT",crteTknMiscMap.get("BEFORE.SYSDATETIME"),record.get("CRTE_DT"));
            AssertionUtility.jdbcDateGreaterThan("MAP_STAT_DT",crteTknMiscMap.get("BEFORE.SYSDATETIME"),record.get("MAP_STAT_DT"));
        }
        return record;
    }

    private  Map<String, String> validatePrvsnRqst() throws Exception {

        LogHandler.debugPrint("Validating PrvsnRqst Table ");
        List<Map<String, Object>> prvsnReqRecList = DataUtils.getPrvsnRqstListByMapId(crteTknMiscMap.get("dbMapId"), LOG_TRUE);
        int count = prvsnReqRecList.size();
        LogHandler.debugPrint("Numnber of records Based on MapId : "+Integer.toString(count));
        Map<String, String> record = null;
        AssertionUtility.equals("Number of Records in Prvsn Rqst Table",excelRowStr.get("expPRVRQSTCount"),count);

        for (int i = 0; i < count ; i++) {

            record = JsonObjectMapper.createStringStringMap(prvsnReqRecList.get(i));
            LogHandler.debugPrint("Asserting Data for prvsn Type Cd : "+record.get("PRVSN_TYPE_CD"));

            switch (record.get("PRVSN_TYPE_CD")) {

                case "PR":
                    AssertionUtility.notNull("PKG_DLVR_ID", record.get("PKG_DLVR_ID"));
                    AssertionUtility.equals("PRVSN_TYPE_CD", excelRowStr.get("expPRVRQST.PrvsnTypeCd"), record.get("PRVSN_TYPE_CD"));
                    AssertionUtility.equals("PRVSN_STAT_CD", excelRowStr.get("expPRVRQST.PrvsnStatCd"), record.get("PRVSN_STAT_CD"));
                    AssertionUtility.equals("FPAN_SRC_CD", excelRowStr.get("expPRVRQST.FpanSrcCd"), record.get("FPAN_SRC_CD"));
                    AssertionUtility.equals("LANG_CD", excelRowStr.get("expPRVRQST.LangCd"), record.get("LANG_CD"));
                    break;
                case "AD":
                    AssertionUtility.equals("PRVSN_TYPE_CD", excelRowStr.get("expPRVRQST.PrvsnTypeCd.ADRow"), record.get("PRVSN_TYPE_CD"));
                    AssertionUtility.equals("PRVSN_STAT_CD", excelRowStr.get("expPRVRQST.PrvsnStatCd.ADRow"), record.get("PRVSN_STAT_CD"));
                    break;
                case "SD":
                    AssertionUtility.equals("PRVSN_TYPE_CD", excelRowStr.get("expPRVRQST.PrvsnTypeCd.SDRow"), record.get("PRVSN_TYPE_CD"));
                    AssertionUtility.equals("PRVSN_STAT_CD", excelRowStr.get("expPRVRQST.PrvsnStatCd.SDRow"), record.get("PRVSN_STAT_CD"));
                    break;
                default:
                    LogHandler.debugPrint("Prvsn Type Code is different from PR,AD and SD");
            }

                AssertionUtility.notNull("PRVSN_RQST_ID", record.get("PRVSN_RQST_ID"));
                AssertionUtility.notNull("API_RQST_ID", record.get("API_RQST_ID"));
                AssertionUtility.notNull("API_CNVRSTN_ID", record.get("API_CNVRSTN_ID"));
                AssertionUtility.equals("ASYNC_TAM_SENT_SW", excelRowStr.get("expPRVRQST.AsyncTamSentSw"), record.get("ASYNC_TAM_SENT_SW"));
                AssertionUtility.equals("SRC_APPL_NAM", excelRowStr.get("expPRVRQST.SrcApplNam"), record.get("SRC_APPL_NAM"));
                AssertionUtility.equals("MAP_ID", crteTknMiscMap.get("dbMapId"), record.get("MAP_ID"));
                AssertionUtility.jdbcDateGreaterThan("PRVSN_STAT_DT", crteTknMiscMap.get("BEFORE.SYSDATETIME"), record.get("PRVSN_STAT_DT"));
                AssertionUtility.jdbcDateGreaterThan("CRTE_DT", crteTknMiscMap.get("BEFORE.SYSDATETIME"), record.get("CRTE_DT"));


        }
        return record;
    }

    private void validatePanDataEnc(String encId) throws Exception{

        LogHandler.debugPrint("Validating PanDataEnc Table ");

        List<Map<String, Object>> panDataEncRecList = DataUtils.getPanDataEncListByPanDataEncId(encId,LOG_TRUE);
        int count =panDataEncRecList.size();
        LogHandler.debugPrint("Numnber of records Based on encid : "+Integer.toString(count));


        if (count == 1) {
            Map<String, String> record =JsonObjectMapper.createStringStringMap(panDataEncRecList.get(0));
            AssertionUtility.notNull("ENCRYPT_PAN_DATA",record.get("ENCRYPT_PAN_DATA"));
            AssertionUtility.equals("PAN_DATA_ENC_ID",encId,record.get("PAN_DATA_ENC_ID"));
            AssertionUtility.equals("RECYCLE_SW",excelRowStr.get("expPDE.RecycleSw"),record.get("RECYCLE_SW"));


        }
    }

    private void validateMqPerformdp() throws Exception {
        MqPerformdpTool dpCompare = new MqPerformdpTool();
        final String EXP_PREFIX  = "expDp.";

        //retrieve record:
        int count = dpCompare.retrieveMsgsBySuidAndStartTime(
                crteTknMiscMap.get("suid"),
                crteTknMiscMap.get("BEFORE.SYSDATETIME"),
                LOG_TRUE);
        AssertionUtility.equals("count", excelRowStr.get("expCntDP.MsgCount"), count);

        //validate record:
        if (count == 1) {
            excelRow.put(EXP_PREFIX + "requestId", crteTknMiscMap.get("dbPrvsnRqstId"));
            excelRow.put(EXP_PREFIX + "pan", crteTknMiscMap.get("tokenPan"));
            excelRow.put(EXP_PREFIX + "suid", crteTknMiscMap.get("suid"));
            excelRow.put(EXP_PREFIX + "sendToObp", "false");

            dpCompare.validateInsertLite(EXP_PREFIX, excelRow);
        }
    }

    public static List getClob(String queueMgrName, String queueName) throws Exception {
        List messageList = new ArrayList();


        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql = "SELECT * FROM MOCK_SERV_ACTVY WHERE REF_ID=? AND SERV_SYS_UNQ_ID=? ";
        List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql, queueMgrName, queueName);

        for (int i = 0; i < resultList.size(); i++) {
            Map m = resultList.get(i);
            messageList.add(m.get("MSG").toString());
        }

        return messageList;
    }


    private void validateMckServActv() throws Exception {

        MockServiceUtility mockService=new MockServiceUtility();

        Map<Integer, Map<String, String>> tstHarnessData = mockService.getMultiTstHarnessData(excelRowStr.get("expMSA.ServCd"), excelRowStr.get("expMSA.ServOperCd"), crteTknMiscMap.get("BEFORE.SYSTIMEDATETIMEMS"), crteTknMiscMap.get("AFTER.SYSTIMEDATETIMEMS"));

        LogHandler.debugPrint(tstHarnessData.toString());

        //Table Assertions
        // AssertionUtility.equals("SysUniqId",PDMrecord.get("DVC_PAN_UNQ_ID") , tstHarnessData.get(1).get(""));
        AssertionUtility.equals("count",excelRowStr.get("expCnt.MSA"),tstHarnessData.size());

            AssertionUtility.equals("ServCd", excelRowStr.get("expMSA.ServCd"), tstHarnessData.get(1).get("SERV_CD"));
            AssertionUtility.equals("ServOperCd", excelRowStr.get("expMSA.ServOperCd"), tstHarnessData.get(1).get("SERV_OPER_CD"));
            AssertionUtility.equals("ClntSysUniqId", crteTknRspMap.get("Hdr.System-Unique-Id"), tstHarnessData.get(1).get("CLNT_SYS_UNQ_ID"));
            AssertionUtility.equals("REF_ID", crteTknMiscMap.get("tokenPan"), tstHarnessData.get(1).get("REF_ID"));
            AssertionUtility.equals("RESP_STAT_NUM", null, tstHarnessData.get(1).get("RESP_STAT_NUM"));

    }


    private void printPDMSPND() throws Exception {


        List<Map<String, Object>> pdmSpndData = DataUtils.getPanDvcMapSpndList(crteTknMiscMap.get("dbMapId"),LOG_TRUE);
        AssertionUtility.equals("No of records Returned are more than one",1,pdmSpndData.size());
        AssertionUtility.equals("PDMSPND.SPND_RQSTR_CD","12",pdmSpndData.get(0).get("SPND_RQSTR_CD").toString());

    }


}
