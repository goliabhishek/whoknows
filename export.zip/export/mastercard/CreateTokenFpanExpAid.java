
package com.mastercard.mdes.automation.manitoba_regression.tests.functional.createToken;

import com.mastercard.mdes.automation.manitoba_regression.support.Constants;
import com.mastercard.mdes.automation.manitoba_regression.tests.FunctionalTests;
import com.mastercard.mdes.test.automation.core.*;
import com.mastercard.mdes.test.automation.core.db_comparison.ExcelHandler;
import com.mastercard.mdes.test.automation.core.db_comparison.MiscUtilties;
import com.mastercard.mdes.test.automation.core.request_builder.JsonObjectMapper;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenParser;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenUtil;
import org.easetech.easytest.annotation.DataLoader;
import org.easetech.easytest.annotation.Param;
import org.easetech.easytest.loader.LoaderType;
import org.easetech.easytest.runner.DataDrivenTestRunner;
import org.junit.Assume;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertTrue;

/**
 * Created by E055798 on 9/2/2016.
 */





@Category(FunctionalTests.class)
@RunWith(DataDrivenTestRunner.class)
@DataLoader(filePaths={Constants.PATH_FUNCTIONAL_CREATETOKEN+"/testCreateTokenFpanExpAid.xls"}, loaderType= LoaderType.EXCEL, writeData=false)

public class CreateTokenFpanExpAid {

//    static private String wltPrdvrId;
//    static private String storageTypeCd;
//    static private String tknTypeCd;

    //standard definitions (tester to update):
    static private String RELATIVE_PATH = Constants.PATH_FUNCTIONAL_CREATETOKEN;
    static private String TEST_METHOD_NAME = "testCreateTokenFpanExpAid";

    //standard definitions (do not update):
    static private String DATASOURCE_PATH = Constants.PATH_RESOURCES + "/" + RELATIVE_PATH + "/" + TEST_METHOD_NAME + ".xls";


    static private Map fullDataMap;

    //testcase specific definitions:
    private final boolean LOG_YES = true;
    private static final boolean LOG_TRUE = true;
    private Map<String, Object> excelRow;
    private Map<String, String> excelRowStr;

    private CreateTokenUtil crteTknUtil;
    private Map<String, String> crteTknReqMap;
    private Map<String, String> crteTknRspMap;
    private Map<String, String> crteTknMiscMap;
    static private String rowNumToBeExcecuted;


    @BeforeClass
    public static void setUp() throws Exception {
        LogHandler.debugPrint(DATASOURCE_PATH);
        fullDataMap = ExcelHandler.generateFullRecordMapFromExcel(DATASOURCE_PATH);
        ReportLogUtils.logTestName(Constants.PROJECT, RELATIVE_PATH, TEST_METHOD_NAME);
    }

    @Test
    public void testCreateTokenFpanExpAid(@Param(name = "inTestNbr") String inTestNbr) throws Exception   {

        loadExcelRow(inTestNbr,TEST_METHOD_NAME);


        if(excelRowStr.get("UpdCardLenNum").equals("Y")) {
            UpdAcctRngMdesParm();
        }
        if(excelRowStr.get("UpdLuhnchkReqd").equals("Y")) {
            UpdAcctRngMdesParm();
        }
        if(excelRowStr.get("UpdExpDtPrsntOnCardSw").equals("Y")) {
            UpdAcctRngMdesParm();
        }
        PrintAcctRngMdesParm();
        createTokenRestCall();
        validateCreateTokenRsp();
        ChkDVCCount();
        ChkPanDvcMapCnt();
        if(excelRowStr.get("ValidatePDM").equals("Y")) {
            ValidatePDM();
        }


    }

    @Test


    private void loadExcelRow(String inTestNbr,String testMethodName) {
        excelRow = MiscUtilties.createExcelRowMap(fullDataMap, testMethodName, inTestNbr);
        Assume.assumeTrue(TestUtils.isTestRunnable(inTestNbr, excelRow.get("inExec"), rowNumToBeExcecuted));
        excelRowStr = JsonObjectMapper.createStringStringMap(excelRow);
        LogHandler.debugPrint("excelRowStr=" + excelRowStr.toString());
        ReportLogUtils.logTestRowDesc(excelRowStr);
    }


    private void createTokenRestCall() throws Exception {
        crteTknUtil = new CreateTokenUtil();

        //setters:
        crteTknUtil.setInHttpHdrXPod(excelRowStr.get("inHttpHdrXPod"));
        crteTknUtil.setInDbResetIndicator("Y");
        crteTknUtil.setInDbResetFpan(excelRowStr.get("inFpanCardDescDataFpan"));
        crteTknUtil.setinFpanCardDescDataFpan(excelRowStr.get("inFpanCardDescDataFpan"));
        crteTknUtil.setinFpanCardDescDataExpiry(excelRowStr.get("inFpanCardDescDataExpiry"));
        crteTknUtil.setInHttpHdrSysUserId(excelRowStr.get("inHttpHdrSysUserId"));
       // crteTknUtil.setInDeviceType(excelRowStr.get("inDVcTypeCode"));
        crteTknUtil.setInSeid(excelRowStr.get("inSeid"));
        crteTknUtil.setInGetSysdateBefore("Y");


        //send:
        crteTknUtil.run();

        //getters:
        crteTknReqMap = crteTknUtil.getOutRequestMap();
        crteTknRspMap = crteTknUtil.getOutResponseMap();
        crteTknMiscMap = crteTknUtil.getOutMiscellaneousMap();
    }

    private void validateCreateTokenRsp() throws Exception {
        final String EXP_PREFIX = "expRsp.";
        Map<String, String> expectedMap = MiscUtilties.extractByPrefix(excelRow, EXP_PREFIX);


        CreateTokenParser.validateResponse(
                EXP_PREFIX,
                expectedMap,
                crteTknRspMap);
    }



}














