package com.mastercard.mdes.test.automation.core.mdes_utilities;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.mastercard.mdes.test.automation.core.PropertyHandler;

import static com.jayway.restassured.RestAssured.given;

/**
 * Created by e062683 on 3/3/2016.
 */
public class ParseUtil {
    private String mdesUtilitiesBaseUrl;
    private String baseUrl;
    ParseUtil() {
        try {
            mdesUtilitiesBaseUrl = PropertyHandler.getEnvironmentProperty("mdesUtilitiesEndpoint");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            baseUrl = PropertyHandler.getEnvironmentProperty("baseUrl");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String createTav(String type, String value) {
        RestAssured.baseURI = mdesUtilitiesBaseUrl;

        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .queryParam("type", type)
                .queryParam("value", value)



                .when()
                .post("/dataElement/parse");

        RestAssured.reset();
        RestAssured.baseURI = baseUrl;

        return response.asString();
    }


}
