package com.mastercard.mdes.test.automation.core;

import org.apache.commons.configuration.PropertiesConfiguration;

import java.io.FileInputStream;
import java.util.Properties;

/**
 * Created by E055238 on 7/27/2015.
 */

public class PropertyHandler {

    public static String getEnvironmentProperty(String key) throws Exception {
        /**
         *   Returns a value from the environment-specific property file.
         */

        // First get the environment from global.properties
        String environment = getGlobalProperty("environment");

        // Now retrieve the environment-specific property
        Properties prop = new Properties();
        FileInputStream fileInputStream = new FileInputStream("configuration/environments/" + environment + ".properties");
        prop.load(fileInputStream);
        String value = prop.getProperty(key);
        fileInputStream.close();

        return value;
    }

    public static String getGlobalProperty(String key) throws Exception {
        /**
         *   Returns a value from the global file given a key.
         */

        Properties prop = new Properties();
        FileInputStream fileInputStream = new FileInputStream("configuration/global.properties");
        prop.load(fileInputStream);
        String value = prop.getProperty(key);
        fileInputStream.close();

        return value;
    }

    public static String getBaseUrl() throws Exception {
        String baseUrl = null;
        String developerMode = getGlobalProperty("developerMode");

        if (developerMode.equalsIgnoreCase("true")) {
            baseUrl = "http://localhost:8080" + getEnvironmentProperty("tokenizationApiPath");
        } else {
            baseUrl = getEnvironmentProperty("baseUrl") + getEnvironmentProperty("tokenizationApiPath");
        }

        return baseUrl;
    }

    public static String getBaseUrlMock() throws Exception {
        String baseUrlMock = null;
        String developerMode = getGlobalProperty("developerMode");

        if (developerMode.equalsIgnoreCase("true")) {
            baseUrlMock = "http://localhost:8080" + getEnvironmentProperty("tokenizationApiPathMock");
        } else {
            baseUrlMock = getEnvironmentProperty("baseUrl") + getEnvironmentProperty("tokenizationApiPathMock");
        }

        return baseUrlMock;
    }

    public static String getBaseUrlOpenApi() throws Exception {
        String baseUrlOpenApi = null;
        String developerMode = getGlobalProperty("developerMode");

        if (developerMode.equalsIgnoreCase("true")) {
            baseUrlOpenApi = "http://localhost:8080" + getEnvironmentProperty("tokenizationApiPath");
        } else {
            baseUrlOpenApi = getEnvironmentProperty("baseUrlOpenApi") + getEnvironmentProperty("tokenizationApiPath");
        }

        return baseUrlOpenApi;
    }

    public static String getBaseUrlMockOpenApi() throws Exception {
        String baseUrlMockOpenApi = null;
        String developerMode = getGlobalProperty("developerMode");

        if (developerMode.equalsIgnoreCase("true")) {
            baseUrlMockOpenApi = "http://localhost:8080" + getEnvironmentProperty("tokenizationApiPathMock");
        } else {
            baseUrlMockOpenApi = getEnvironmentProperty("baseUrlOpenApi") + getEnvironmentProperty("tokenizationApiPathMock");
        }

        return baseUrlMockOpenApi;
    }

    public static void setGlobalProperty(String key, String value) throws Exception {

        /**
         *  Sets a key/value pair in the global.properties file. This is useful for setting the environment
         *  variable programmatically. Apache Commons Configuratin is used here since it overwrites
         *  properties without removing commments within the file.
         */

        PropertiesConfiguration props = new PropertiesConfiguration("configuration/global.properties");
        props.setProperty(key, value);
        props.save();
    }

    public static void setEnvironmentProperty(String key, String value) throws Exception {

        /**
         *  Sets a key/value pair in the environment properties file.
         */

        // First get the environment from global.properties
        String environment = getGlobalProperty("environment");

        // Now set the environment-specific property
        PropertiesConfiguration props = new PropertiesConfiguration("configuration/environments/" + environment + ".properties");
        props.setProperty(key, value);
        props.save();
    }

    public static String getManitobaNccProperty(String key) throws Exception {
        String environment = getEnvironmentProperty("nccDefaultPropertyFileName");

        // Now retrieve the environment-specific property
        Properties prop = new Properties();
        FileInputStream fileInputStream = new FileInputStream("configuration/environments/" + environment + ".properties");
        prop.load(fileInputStream);
        String value = prop.getProperty(key);
        fileInputStream.close();
        return value;
    }

}
