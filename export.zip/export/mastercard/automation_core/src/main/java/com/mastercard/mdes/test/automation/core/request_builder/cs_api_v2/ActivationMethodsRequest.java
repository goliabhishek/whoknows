package com.mastercard.mdes.test.automation.core.request_builder.cs_api_v2;

/**
 * Created by John Kalbac E055238 on 1/25/2016.
 */
public class ActivationMethodsRequest {

    private String tokenUniqueReference;
    private String userId;
    private String userName;
    private String organization;
    private String phone;

    public ActivationMethodsRequest tokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
        return this;
    }

    public ActivationMethodsRequest userId(String userId) {
        this.userId = userId;
        return this;
    }

    public ActivationMethodsRequest userName(String userName) {
        this.userName = userName;
        return this;
    }

    public ActivationMethodsRequest organization(String organization) {
        this.organization = organization;
        return this;
    }

    public ActivationMethodsRequest phone(String phone) {
        this.phone = phone;
        return this;
    }


    public ActivationMethodsRequest allDefaults() {
        tokenUniqueReference = "tokenUniqueReference";
        userId = "AutomatedTest";
        userName = "AutomatedTest";
        organization = "MasterCard";
        phone = "5551234567";
        return this;
    }


    public String build() {
        return "<TokenActivationMethodsRequest>" +
                "    <TokenUniqueReference>" + tokenUniqueReference + "</TokenUniqueReference>" +
                "    <AuditInfo>" +
                "        <UserId>" + userId + "</UserId>" +
                "        <UserName>" + userName + "</UserName>" +
                "        <Organization>" + organization + "</Organization>" +
                "        <Phone>" + phone + "</Phone>" +
                "    </AuditInfo>" +
                "</TokenActivationMethodsRequest>";
    }

}
