package com.mastercard.mdes.test.automation.core.request_builder.tokenization_api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mastercard.mdes.test.automation.core.TestUtils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by John Kalbac e055238 on 1/22/2016.
 */

public class UnsuspendRequest {

    private String requestId;
    private String tokenUniqueReference;
    private String reason;

    public UnsuspendRequest requestId(String requestId) {
        this.requestId = requestId;
        return this;
    }

    public UnsuspendRequest tokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
        return this;
    }

    public UnsuspendRequest reason(String reason) {
        this.reason = reason;
        return this;
    }

    public UnsuspendRequest allDefaults() {
        requestId = TestUtils.generateRequestId();
        tokenUniqueReference = "12345";
        reason = "OTHER";
        return this;
    }


    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("requestId", requestId);
        jsonObject.put("tokenUniqueReference", tokenUniqueReference);
        jsonObject.put("reason", reason);

        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }

}