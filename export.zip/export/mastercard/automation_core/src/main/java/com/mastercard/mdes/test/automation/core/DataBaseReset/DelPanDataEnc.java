package com.mastercard.mdes.test.automation.core.DataBaseReset;

import com.mastercard.mdes.test.automation.core.DatabaseHandler;
import com.mastercard.mdes.test.automation.core.LogHandler;
import com.mastercard.mdes.test.automation.core.PropertyHandler;
import com.mastercard.mdes.test.automation.core.mdes_utilities.MDESUtilities;
import junit.framework.Assert;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotSame;
import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertTrue;

/**
 * Created by e062684 on 3/15/2016.
 */
public class DelPanDataEnc {
    private  Connection con = null;
    private String tcDvcPan;
    private String tcPanDataEncId;
    private String tcEncryptPanData;
    protected DelPanDataEnc(String tcDvcPan, String tcPanDataEncId, String tcEncryptPanData) throws Exception {
        DatabaseHandler db = new DatabaseHandler();
        con=db.getDbConnection();
    }

/*

    private static void checkCassAvailability() throws Exception {
        String gbCaasAvailable = PropertyHandler.getEnvironmentProperty("gbCaasAvailable");
        assertFalse("global property 'gbCaasAvailable' not defined or has empty value",gbCaasAvailable.isEmpty());
    }


    private static void checkAmsMckAvailable() throws Exception {
        String gbAmsMckMapAvailable = PropertyHandler.getEnvironmentProperty("gbAmsMckMapAvailable");
        assertFalse("global property 'gbAmsMckMapAvailable' not defined or has empty value",gbAmsMckMapAvailable.isEmpty());
    }
*/
    protected  void dbDelPanDataEnc() {
        String message;
        String tcKey="tcDvcPan";
        message="Must provide an override value for '"+tcKey+"' property";

        assertFalse(message,tcDvcPan.equalsIgnoreCase(DatabaseResetUtils.NODEFAULT));

        message="  Invalid override value for '" + tcKey + "' property\n";
        message+="  Value = [" + tcDvcPan + "]\n";
        message+="  Must be 'Y' or 'N' ...";

        assertTrue(message,! ((tcDvcPan.equalsIgnoreCase("Y")) || (tcDvcPan.equalsIgnoreCase("N"))));
        tcKey="tcPanDataEncId";

        assertFalse(message,tcPanDataEncId.equalsIgnoreCase(DatabaseResetUtils.NODEFAULT));

        message="  Invalid override value for '" + tcKey + "' property\n";
        message+="  Value = [" + tcPanDataEncId + "]\n";

        assertTrue(message,tcPanDataEncId.isEmpty());
        tcKey="tcEncryptPanData";

        assertFalse(message,tcEncryptPanData.equalsIgnoreCase(DatabaseResetUtils.NODEFAULT));

        message="  Invalid override value for '" + tcKey + "' property\n";
        message+="  Value = [" + tcEncryptPanData + "]\n";

        assertTrue(message,tcEncryptPanData.isEmpty());

        delePanDataEncRow();
        String bcDecryptedDpan = getDecryptedDpan();
        addSiteDpanCycle(bcDecryptedDpan);
        delAmsMckMapRow(bcDecryptedDpan);
    }
    /**
     *
     *
     */
    private  void delePanDataEncRow()
    {
        String sqlText = "DELETE FROM PAN_DATA_ENC WHERE PAN_DATA_ENC_ID = " + tcPanDataEncId;
        try (Statement stmt = con.createStatement()) {
            stmt.executeUpdate(sqlText);
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @return
     */
    private  String getDecryptedDpan()
    {
        return MDESUtilities.caasDecrypt(tcEncryptPanData);
    }

    /**
     *
     * @param bcDecryptedDpan
     * @return
     */
    private  Map getDpanAcctRangeInfo(String bcDecryptedDpan)
    {
        Map<String,String> strtNum=new HashMap<>();
        LogHandler.print("  >> finding RNG_STRT_NUM for [" + bcDecryptedDpan + "] ...");
        String str = bcDecryptedDpan + "0000000000000000000";
        String bcDecryptedDpanPadded = str.substring(0,19);
        String sqlText = "SELECT RNG_STRT_NUM, " +
                " FPAN_RNG_STRT_NUM " +
                "FROM   DPAN_ACCT_RNG " +
                "WHERE '" + bcDecryptedDpanPadded + "' BETWEEN RNG_STRT_NUM AND RNG_END_NUM";
        try (Statement stmt = con.createStatement()) {
            ResultSet results=stmt.executeQuery(sqlText);

            while (results.next())
            {
                strtNum.put("cnstBcDpanDpanRngStrtNum",results.getString("RNG_STRT_NUM"));
                strtNum.put("cnstBcDpanFpanRngStrtNum",results.getString("FPAN_RNG_STRT_NUM"));
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return strtNum;
    }
    private  void addSiteDpanCycle(String bcDecryptedDpan)  {
        int bcDecryptedDpanLen   = bcDecryptedDpan.length();
        Map<String,String> StrtNum=getDpanAcctRangeInfo(bcDecryptedDpan);
        String bcDpanDpanRngStrtNum = StrtNum.get("cnstBcDpanDpanRngStrtNum");
        String bcDpanFpanRngStrtNum = StrtNum.get("cnstBcDpanFpanRngStrtNum");
        String sqlText1 = "SELECT COUNT(*) \"COUNT\" FROM SITE_DPAN_RECYCLE WHERE DVC_PAN = '" + bcDecryptedDpan + "'";

        LogHandler.print("EXECUTING " + sqlText1);
        try {
            Statement stmt = con.createStatement();
            ResultSet results=stmt.executeQuery(sqlText1);
            long cnt = 0;
            while (results.next()) {
                cnt=results.getLong("COUNT");
            }
            results.close();
            stmt.close();
            stmt = con.createStatement();
            if (cnt > 0) {
                LogHandler.print(" WARNING: DVC_PAN '" + bcDecryptedDpan + "' already exists SITE_DPAN_RECYCLE " +
                        "so bypassing the remainder of this teststep ...");
            }
                String sqlText2 = "INSERT INTO SITE_DPAN_RECYCLE " +
                        "  (CNSM_SITE_CD, CREATE_TIMESTAMP, DPAN_RNG_STRT_NUM, DVC_PAN, DVC_PAN_LEN_NUM, FPAN_RNG_STRT_NUM, ORIG_SITE_CD, POOL_ID) " +
                        "VALUES " +
                        "('1', SYSDATE, " + bcDpanDpanRngStrtNum + ", " + bcDecryptedDpan + ", " + bcDecryptedDpanLen + ", " + bcDpanFpanRngStrtNum + ", NULL, NULL)";
                stmt.executeUpdate(sqlText2);
            stmt.close();
            stmt = con.createStatement();
            results=stmt.executeQuery(sqlText1);
            LogHandler.print("COMPLETED " + sqlText1 );
            cnt = 0;
            while (results.next()) {
                cnt=results.getLong("COUNT");
            }
            assertTrue("COUNT",cnt==1);
            results.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param bcDecryptedDpan
     * @throws Exception
     */
    private  void delAmsMckMapRow(String bcDecryptedDpan)
    {
        LogHandler.print("  >> deleting AMS mapping for [" + bcDecryptedDpan + "] ...");

        String sqlText = "DELETE FROM AMS_MOCK_EVENT WHERE DVC_PAN = '" + bcDecryptedDpan + "'";
        LogHandler.print("EXECUTING " + sqlText );
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate(sqlText);
            stmt.close();
            LogHandler.print("COMPLETED " + sqlText);

            sqlText = "DELETE FROM AMS_MCK_MAP WHERE DVC_PAN = '" + bcDecryptedDpan + "'";
            LogHandler.print("EXECUTING 'dbUtilExecute.execute(" + sqlText + ")'");
            stmt = con.createStatement();
            stmt.executeUpdate(sqlText);
            stmt.close();
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        LogHandler.print("COMPLETED " + sqlText );
    }
    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        con.close();
    }

}
