package com.mastercard.mdes.test.automation.core.request_builder.cs_api_v2;

/**
 * Created by John Kalbac E055238 on 1/25/2016.
 */
public class UnsuspendRequest {

    private String tokenUniqueReference;
    private String reasonCode;
    private String commentText;
    private String userId;
    private String userName;
    private String organization;
    private String phone;

    public UnsuspendRequest tokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
        return this;
    }

    public UnsuspendRequest reasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
        return this;
    }

    public UnsuspendRequest commentText(String commentText) {
        this.commentText = commentText;
        return this;
    }

    public UnsuspendRequest userId(String userId) {
        this.userId = userId;
        return this;
    }

    public UnsuspendRequest userName(String userName) {
        this.userName = userName;
        return this;
    }

    public UnsuspendRequest organization(String organization) {
        this.organization = organization;
        return this;
    }

    public UnsuspendRequest phone(String phone) {
        this.phone = phone;
        return this;
    }


    public UnsuspendRequest allDefaults() {
        tokenUniqueReference = "tokenUniqueReference";
        reasonCode = "T";
        commentText = "AutomatedTest";
        userId = "AutomatedTest";
        userName = "AutomatedTest";
        organization = "MasterCard";
        phone = "5551234567";
        return this;
    }


    public String build() {
        return "<TokenUnsuspendRequest>" +
                "    <TokenUniqueReference>" + tokenUniqueReference + "</TokenUniqueReference>" +
                "    <ReasonCode>" + reasonCode + "</ReasonCode>" +
                "    <CommentText>" + commentText + "</CommentText>" +
                "    <AuditInfo>" +
                "        <UserId>" + userId + "</UserId>" +
                "        <UserName>" + userName + "</UserName>" +
                "        <Organization>" + organization + "</Organization>" +
                "        <Phone>" + phone + "</Phone>" +
                "    </AuditInfo>" +
                "</TokenUnsuspendRequest>";
    }

}