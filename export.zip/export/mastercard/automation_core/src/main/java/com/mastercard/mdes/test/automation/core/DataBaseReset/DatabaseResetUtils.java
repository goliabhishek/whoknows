package com.mastercard.mdes.test.automation.core.DataBaseReset;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.msg.client.commonservices.Log.Log;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.mastercard.mdes.test.automation.core.DatabaseHandler;
import com.mastercard.mdes.test.automation.core.LogHandler;
import com.mastercard.mdes.test.automation.core.PropertyHandler;
import jdk.nashorn.internal.parser.JSONParser;

import java.sql.*;
import java.util.*;

import static com.jayway.restassured.RestAssured.given;
import static org.junit.Assert.*;

/**
 * Created by e062684 on 3/7/2016.
 */
public class DatabaseResetUtils {

    static Connection con = null;
    static List<Long> mapIdList = new ArrayList<>();
    static List<String> dpanList = new ArrayList<>();
    public final static String cnstByMapId = "BYMAPID";
    public final static String cnstByTranId = "BYTRANID";
    public final static String NODEFAULT="NODEFAULT";

    /**
     *
     * @param pan
     * @param tridFpan
     */
    public static void resetDatabaseByTRIDFPANAndHashFPAN(String pan,String tridFpan )
    {
        RestAssured.baseURI = "http://ech-10-157-130-245.mastercard.int";
        String str="{\r\n\t\"pan\" : \""+pan+"\"\r\n}";
        Response response = given()
                .contentType(ContentType.JSON)
                .body(str)
                .when()
                .post("/mdesweb/api/v1/caas_hashPan");
        JsonPath responseJson=new JsonPath(response.asString());
        String whereText = "WHERE PDM.HASH_FUND_PAN = '" + responseJson.getString("hashValue") + "' AND TOKEN_RQSTR_ID = " + tridFpan;
        String sqlQuery = "SELECT" + " " +
                "NVL(TO_CHAR(PDM.DVC_PAN_DATA_ENC_ID),'NULL') \"DVC_PAN_DATA_ENC_ID\", " +
                "NVL(TO_CHAR(PDM.MAP_ID),'NULL') \"MAP_ID\"  " +
                "FROM DVC DVC, PAN_DVC_MAP PDM " +
                whereText +
                "AND DVC.SEC_ELMT_ID = PDM.SEC_ELMT_ID ";
        resetDbByMapIdListAndDpanList(sqlQuery);
    }

    /**
     *
     * @param fpan
     */
    public static void resetDatabaseByFPAN(String fpan )
    {
        String whereText = "WHERE PDM.HASH_FUND_PAN = '" + fpan + "' ";
        String sqlQuery = "SELECT" + " " +
                "NVL(TO_CHAR(PDM.DVC_PAN_DATA_ENC_ID),'NULL') \"DVC_PAN_DATA_ENC_ID\", " +
                "NVL(TO_CHAR(PDM.MAP_ID),'NULL') \"MAP_ID\"  " +
                "FROM DVC DVC, PAN_DVC_MAP PDM " +
                whereText +
                "AND DVC.SEC_ELMT_ID = PDM.SEC_ELMT_ID ";
        resetDbByMapIdListAndDpanList(sqlQuery);
    }


    /**
     *
     * @param fpanId
     */
    public static void resetDatabaseByFPANID(String fpanId )
    {
        String whereText = "WHERE PDM.FUND_PAN_UNQ_ID = '" + fpanId + "' ";
        String sqlQuery = "SELECT" + " " +
                "NVL(TO_CHAR(PDM.DVC_PAN_DATA_ENC_ID),'NULL') \"DVC_PAN_DATA_ENC_ID\", " +
                "NVL(TO_CHAR(PDM.MAP_ID),'NULL') \"MAP_ID\"  " +
                "FROM DVC DVC, PAN_DVC_MAP PDM " +
                whereText +
                "AND DVC.SEC_ELMT_ID = PDM.SEC_ELMT_ID ";
        resetDbByMapIdListAndDpanList(sqlQuery);
    }


    /**
     *
     * @param seid
     * @param fpanId
     */

    public static void resetDatabaseBySEIDAndFPANID(String seid, String fpanId )
    {

        //define base WHERE clause (matching by SEID):
        String whereText1 = "WHERE (( DVC.SEC_ELMT_ID = '" + seid + "' ) OR ( DVC.PAYMT_APPL_INSTNCE_ID = '" + seid + "' ))";
        //append matching on HASH_FUND_PAN (if applicable):
        String   whereText2 = whereText1 + "AND PDM.FUND_PAN_UNQ_ID = '" + fpanId + "'";
        String sqlQuery=
                "SELECT DISTINCT" + " " +
                        "NVL(TO_CHAR(PDM.DVC_PAN_DATA_ENC_ID),'NULL') \"DVC_PAN_DATA_ENC_ID\", " +
                        "NVL(TO_CHAR(PDM.MAP_ID),'NULL') \"MAP_ID\"  " +
                        "FROM DVC DVC, PAN_DVC_MAP PDM " +
                        whereText2 +
                        "AND (DVC.SEC_ELMT_ID = PDM.SEC_ELMT_ID or DVC.PAYMT_APPL_INSTNCE_ID = PDM.PAYMT_APPL_INSTNCE_ID) ";

        resetDbByMapIdListAndDpanList(sqlQuery);
    }

    /**
     * Reset Database by SEID and FPAN(HASH_FUND_PAN)
     * @param seid
     * @param fpan
     */
    public static void resetDatabaseBySEIDAndFPAN(String seid, String fpan )
    {
        //define base WHERE clause (matching by SEID):
        String whereText1 = "WHERE (( DVC.SEC_ELMT_ID = '" + seid + "' ) OR ( DVC.PAYMT_APPL_INSTNCE_ID = '" + seid + "' ))";
        //append matching on HASH_FUND_PAN (if applicable):
        String   whereText2 = whereText1 + "AND PDM.HASH_FUND_PAN = '" +fpan+ "'";
        String sqlQuery=
        "SELECT DISTINCT" + " " +
                "NVL(TO_CHAR(PDM.DVC_PAN_DATA_ENC_ID),'NULL') \"DVC_PAN_DATA_ENC_ID\", " +
                "NVL(TO_CHAR(PDM.MAP_ID),'NULL') \"MAP_ID\"  " +
                "FROM DVC DVC, PAN_DVC_MAP PDM " +
                whereText2 +
                "AND (DVC.SEC_ELMT_ID = PDM.SEC_ELMT_ID or DVC.PAYMT_APPL_INSTNCE_ID = PDM.PAYMT_APPL_INSTNCE_ID) ";
        resetDbByMapIdListAndDpanList(sqlQuery);

    }
    /**
     * Reset Database by SEID
     * @param seid
     */
    public static void resetDatabaseBySEID(String seid )
    {
        //define base WHERE clause (matching by SEID):
        String whereText1 = "WHERE (( DVC.SEC_ELMT_ID = '" + seid + "' ) OR ( DVC.PAYMT_APPL_INSTNCE_ID = '" + seid + "' ))";
        //append matching on HASH_FUND_PAN (if applicable):
        String sqlQuery=
                "SELECT DISTINCT" + " " +
                        "NVL(TO_CHAR(PDM.DVC_PAN_DATA_ENC_ID),'NULL') \"DVC_PAN_DATA_ENC_ID\", " +
                        "NVL(TO_CHAR(PDM.MAP_ID),'NULL') \"MAP_ID\"  " +
                        "FROM DVC DVC, PAN_DVC_MAP PDM " +
                        whereText1 +
                        "AND (DVC.SEC_ELMT_ID = PDM.SEC_ELMT_ID or DVC.PAYMT_APPL_INSTNCE_ID = PDM.PAYMT_APPL_INSTNCE_ID) ";
        resetDbByMapIdListAndDpanList(sqlQuery);

    }

    /**
     *
     * @param deleteIdType
     * @param deleteId
     */
    public static void deleteTranRows(String deleteIdType,String deleteId)
    {
        String sqlText = "DELETE FROM TRAN WHERE ";

        switch ( deleteIdType ) {

            case cnstByMapId:
                sqlText = sqlText + "MAP_ID = " + deleteId;
                break;

            case cnstByTranId:
                sqlText = sqlText + "TRAN_ID = " + deleteId;
                break;
        }
        establishConnection();
//        Statement stmt;
        try(Statement stmt=con.createStatement()) {
            LogHandler.print("EXECUTING 'dbUtilExecute.execute(" + sqlText + ")'");
            stmt.executeUpdate(sqlText);
            LogHandler.print("COMPLETED 'dbUtilExecute.execute(" + sqlText + ")'");

            stmt.close();
        } catch (SQLException e) {
            assertNull(e.getMessage(),e);
        }

        closeConnection();

    }

    public static void dbResetDelDvc(String dvcId)
    {
        establishConnection();

        try(Statement stmt=con.createStatement()) {
//            Fetch Results

            String sqlText = "SELECT COUNT(*) \"COUNT\" FROM PAN_DVC_MAP WHERE DVC_ID = " + dvcId;
            ResultSet results = stmt.executeQuery(sqlText);
            int cntPanDvcMap = 0;
            while (results.next())
            {
                cntPanDvcMap=results.getInt("COUNT");
            }
            results.close();

            sqlText = "SELECT COUNT(*) \"COUNT\" FROM DVC_NOTIF WHERE DVC_ID = " + dvcId;
            results = stmt.executeQuery(sqlText);
            int cntDvcNotif = 0;
            while (results.next())
            {
                cntPanDvcMap=results.getInt("COUNT");
            }
            results.close();
//            Don Fetching Results
            if ( (cntPanDvcMap == 0) && (cntDvcNotif == 0) ) {

                // delete device-level API_ACTVTY rows:
                LogHandler.print("  >> deleting API_ACTVTY ...");
                sqlText = "DELETE FROM API_ACTVTY WHERE DVC_ID = " + dvcId;
                LogHandler.print("EXECUTING 'dbUtilExecute.execute(" + sqlText + ")'");
                stmt.executeUpdate(sqlText);
                LogHandler.print("COMPLETED 'dbUtilExecute.execute(" + sqlText + ")'");

                //now delete the DVC parent:
                LogHandler.print("  >> deleting DVC ...");
                sqlText = "DELETE FROM DVC WHERE DVC_ID = " + dvcId;
                LogHandler.print("EXECUTING 'dbUtilExecute.execute(" + sqlText + ")'");
                stmt.executeUpdate(sqlText);
                LogHandler.print("COMPLETED 'dbUtilExecute.execute(" + sqlText + ")'");
            }
            else {
                LogHandler.print("  >> DVC still has children ... record not deleted ...");
            }
            stmt.close();
        } catch (SQLException e) {
            assertNull(e.getMessage(),e);
        }
        closeConnection();
    }

    /**
     *
     * @param dvcNotifId
     * @throws Exception
     */
    public static void delDvcNotiRow(String dvcNotifId) throws Exception {
        establishConnection();
        int pdmCount= getCountPdmByDvcNotifId(dvcNotifId);
        assertTrue(" DVC_NOTIF_ID still has [" + pdmCount + "] PAN_DVC_MAP child rows so bypassing this testtep ...",pdmCount > 0);

//delete DVC_NOTIF:
        LogHandler.print("  >> deleting DVC_NOTIF ...");
        String sqlText = "DELETE FROM DVC_NOTIF WHERE DVC_NOTIF_ID = " + dvcNotifId;
        LogHandler.print("EXECUTING 'dbUtilExecute.execute(" + sqlText + ")'");
        try(Statement stmt=con.createStatement()) {
            stmt.executeUpdate(sqlText);
            stmt.close();
        } catch (SQLException e) {
            assertNull(e.getMessage(),e);
        }
        LogHandler.print("COMPLETED 'dbUtilExecute.execute(" + sqlText + ")'");

        closeConnection();
    }

    public static void dbResetDelPanDvcMap(String tcMapid)
    {
        try {
            DelPanDvcMap delpdm=new DelPanDvcMap(tcMapid);
            delpdm.dbDelPanDvcMap();

        } catch (Exception e) {
            assertNull(e.getMessage(),e);
        }
    }

    public static void dbResetDelPanDataEnc(String tcDvcPan, String tcPanDataEncId, String tcEncryptPanData)
    {
        try {
            DelPanDataEnc dpde=new DelPanDataEnc( tcDvcPan,  tcPanDataEncId,  tcEncryptPanData);
            dpde.dbDelPanDataEnc();

        } catch (Exception e) {
            assertNull(e.getMessage(),e);
        }
    }

    /**
     *
     */
    private static void establishConnection()
    {
        DatabaseHandler db = new DatabaseHandler();
        try {
            con = db.getDbConnection();
        } catch (Exception e) {
            assertNull(e.getMessage(),e);
        }
    }

    /**
     *
     */
    private static void closeConnection()
    {
        try {
            con.close();
        } catch (Exception e) {
            assertNull(e.getMessage(),e);
        }
    }

    /**
     *
     * @param dvcNotifId
     * @return
     */
    private static int getCountPdmByDvcNotifId(String dvcNotifId)
    {
        int count=0;
        String sqlText = "SELECT COUNT(*) \"COUNT\" FROM PAN_DVC_MAP_DVC_NOTIF WHERE DVC_NOTIF_ID = " + dvcNotifId;
        try(Statement stmt=con.createStatement()) {
            ResultSet result = stmt.executeQuery(sqlText);

            while (result.next())
            {
                count=result.getInt("COUNT");
            }

            result.close();
            stmt.close();
        } catch (SQLException e) {
            assertNull(e.getMessage(),e);
        }
        return count;
    }
    /**
     * Excecute an sql querey and get mapIdList and dpanList from results
     * @param sqlQuery
     */
    private static void resetDbByMapIdListAndDpanList(String sqlQuery)
    {


        Statement stmt=null;
        ResultSet results =null;
        try{
            establishConnection();
            stmt = con.createStatement();
            results = stmt.executeQuery(sqlQuery);
            assertFalse("No records available",results.getRow()>0);
            while (results.next())
            {
                dpanList.add(results.getString("DVC_PAN_DATA_ENC_ID"));
                mapIdList.add(results.getLong("MAP_ID"));
            }
            deleteMapping();
        }catch (Exception e)
        {
            LogHandler.print(e.getMessage());
        }finally {
            try {
                if(results!=null)
                    results.close();
                stmt.close();
                con.close();
            } catch (SQLException e) {
                assertNull(e.getMessage(),e);
            }

        }
    }

    /**
     * Reset database
     */
    private static void deleteMapping()  {
        assertEquals("Dpan list size is not equal to Map_id lis",dpanList.size(),mapIdList.size());

        CallableStatement callableStatement = null;


        String procName = "{call PKG_FT1.PRC_DELETE_MAPPING(?, ?, ?, ?)}";
        for (int i = 0; i < mapIdList.size(); i++) {
            try {
                long m_id=mapIdList.get(i);
                String d_pan= dpanList.get(i);

                callableStatement = con.prepareCall(procName);
                callableStatement.setLong(1, m_id);
                callableStatement.setString(2, d_pan);
                callableStatement.registerOutParameter(3, Types.BIGINT);
                callableStatement.registerOutParameter(4, Types.VARCHAR);
                callableStatement.executeUpdate();
                int rtn_cd = callableStatement.getInt(3);
                String rtn_msg = callableStatement.getString(4);
                if (rtn_cd==0) {
                    LogHandler.print("COMPLETED SUCCESSFULLY EXECUTING PROCEDURE PKG_FT1.PRC_DELETE_MAPPING");
                    LogHandler.print("Input params : ["+m_id+","+d_pan+"]");
                    LogHandler.print("PKG_FT1.PRC_DELETE_MAPPING.rtn_msg = [" + rtn_msg + "]");
                }
                else {
                    LogHandler.print("Failed CALLING PROCEDURE EXECUTING PKG_FT1.PRC_DELETE_MAPPING");
                    LogHandler.print("Input params : ["+m_id+","+d_pan+"]");
                    LogHandler.print("PKG_FT1.PRC_DELETE_MAPPING.rtn_msg = [" + rtn_msg + "]");
                }
            }catch (Exception e){
                LogHandler.print("Failed CALLING PROCEDURE EXECUTING PKG_FT1.PRC_DELETE_MAPPING");

                LogHandler.print(e.getMessage());
            }
            finally {
                try {
                    callableStatement.close();
                } catch (SQLException e) {
                    assertNull(e.getMessage(),e);
                }
            }
        }
    }
}
