package com.mastercard.mdes.test.automation.core.comparison_tool_new;

import com.mastercard.mdes.test.automation.core.DataUtils;

/**
 * Created by e062684 on 3/2/2016.
 */
public class PrvsnRqstComparisonTool extends ComparisonTool {

    private String paramType;
    private String queryParam;

    public void getBeforeRecordUsingTokenUniqueReference(String param) throws Exception {
        // TODO
    }

    public void getAfterRecordUsingTokenUniqueReference(String param) throws Exception {
        // TODO
    }

    public void getBeforeRecordUsingMapId(String param) throws Exception {
        beforeResult=DataUtils.getPrvsnRqstRecordsUsingMapId(param);
    }

    public void getAfterRecordUsingMapId(String param) throws Exception {
        afterResult=DataUtils.getPrvsnRqstRecordsUsingMapId(param);
    }

}
