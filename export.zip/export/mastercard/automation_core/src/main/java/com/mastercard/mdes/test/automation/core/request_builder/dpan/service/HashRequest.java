package com.mastercard.mdes.test.automation.core.request_builder.dpan.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by E055238 on 3/4/2016.
 */
public class HashRequest {

    private String value;

    public HashRequest value (String value) {
        this.value = value;
        return this;
    }

    public HashRequest allDefaults() {
        value = null;
        return this;
    }

    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("value", value);

        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }

}
