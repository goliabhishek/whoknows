package com.mastercard.mdes.test.automation.core;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by E055238 on 8/6/2015.
 */

public class DataUtils {

    public static Map<String, String> getPanDvcMapRecordUsingTokenUniqueReference(String tokenUniqueReference) throws Exception {
        Map<String, String> resultMap = new LinkedHashMap<>();

        PreparedStatement ps = null;
        Connection con = null;
        try {
            con = DatabaseHandler.getDbConnection();
            ps = con.prepareStatement(
                    "SELECT * FROM PAN_DVC_MAP WHERE DVC_PAN_UNQ_ID=?");
            ps.setString(1, tokenUniqueReference);

            ResultSet results = ps.executeQuery();
            ResultSetMetaData md = results.getMetaData();

            if (results.next()) {
                for (Integer i = 1; i <=  md.getColumnCount(); i++) {
                    resultMap.put(md.getColumnName(i), results.getString(i));
                }
            } else {
                assert false : (" Unable to find record for TokenUniqueReference: " + tokenUniqueReference);
            }
        } finally {
            con.close();
            ps.close();
        }

        return resultMap;
    }

    public static Map<Integer, Map> getPrvsnRqstRecordsUsingMapId(String mapId) throws Exception {

        Map<Integer, Map> resultMap = new LinkedHashMap<>();

        PreparedStatement ps = null;
        Connection con = null;
        try {
            con = DatabaseHandler.getDbConnection();
            ps = con.prepareStatement(
                    "SELECT * FROM PRVSN_RQST WHERE MAP_ID=?");
            ps.setString(1, mapId);

            ResultSet results = ps.executeQuery();
            ResultSetMetaData md = results.getMetaData();
            Integer recordCount = 0;

            while (results.next()) {
                recordCount++;
                Map<String, String> recordMap = new HashMap<>();
                for (Integer i = 1; i <=  md.getColumnCount(); i++) {
                    recordMap.put(md.getColumnName(i), results.getString(i));
                }
                resultMap.put(recordCount, recordMap);
            }

        } finally {
            con.close();
            ps.close();
        }

        return resultMap;
    }


}