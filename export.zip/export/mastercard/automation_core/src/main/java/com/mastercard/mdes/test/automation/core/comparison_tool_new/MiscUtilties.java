package com.mastercard.mdes.test.automation.core.comparison_tool_new;

import com.mastercard.mdes.test.automation.core.LogHandler;
import org.apache.commons.lang.StringUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by e062684 on 3/2/2016.
 */
public class MiscUtilties {

    public static Map createExcelRowMap(Map<String, List<Map<String, Object>>> fullDataMap, String methodName, String inTestNbr) {
        Map<String, Object> recordMap = fullDataMap.get(methodName).get(Integer.parseInt(inTestNbr)-1);
        return recordMap;
    }

    public static Map<String, Object> createFilteredMapUsingPrefix(Map<String, Object> fullRecordMap, String prefix) throws Exception{
        Map<String, Object> filteredMap = new LinkedHashMap<>();

        for (Map.Entry<String, Object> entry : fullRecordMap.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (StringUtils.containsIgnoreCase(key, prefix)) {
                String str = key.replace(prefix,"");
                String[] str1 = str.split("(?<=.)(?=\\p{Lu})");
                StringJoiner finalKey = new StringJoiner("_");
                for (String s:str1) {
                    finalKey.add(s.toUpperCase());
                }
                filteredMap.put(finalKey.toString(), value);
            }

        }

        return filteredMap;
    }

    public static String clobStringConversion(Clob clb) throws IOException, SQLException {

        StringBuffer str = new StringBuffer();
        String strng;

        BufferedReader bufferRead = new BufferedReader(clb.getCharacterStream());

        while ((strng=bufferRead .readLine())!= null) {
            str.append(strng);
        }
        return str.toString();
    }
}
