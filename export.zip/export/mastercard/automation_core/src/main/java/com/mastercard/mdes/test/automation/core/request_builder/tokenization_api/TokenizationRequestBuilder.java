package com.mastercard.mdes.test.automation.core.request_builder.tokenization_api;

/**
 * Created by John Kalbac e055238 on 1/22/2016.
 */

public class TokenizationRequestBuilder {

    public static CardInfoObject cardInfoObject() {
        return new CardInfoObject();
    }

    public static DeleteRequest deleteRequest() {
        return new DeleteRequest();
    }

    public static GetStatusRequest getStatusRequest() {
        return new GetStatusRequest();
    }

    public static SuspendRequest suspendRequest() {
        return new SuspendRequest();
    }

    public static TokenizeByTURRequest tokenizeByTURRequest() {
        return new TokenizeByTURRequest();
    }

    public static TokenizeRequest tokenizeRequest() {
        return new TokenizeRequest();
    }

    public static UnsuspendRequest unsuspendRequest() {
        return new UnsuspendRequest();
    }
}
