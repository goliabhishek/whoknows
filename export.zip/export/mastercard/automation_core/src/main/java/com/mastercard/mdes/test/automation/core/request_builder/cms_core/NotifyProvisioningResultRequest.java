package com.mastercard.mdes.test.automation.core.request_builder.cms_core;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mastercard.mdes.test.automation.core.TestUtils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by John Kalbac E055238 on 1/25/2016.
 */
public class NotifyProvisioningResultRequest {

    private String requestId;
    private String result;
    private String tokenUniqueReference;

    public NotifyProvisioningResultRequest requestId(String requestId) {
        this.requestId = requestId;
        return this;
    }

    public NotifyProvisioningResultRequest result(String result) {
        this.result = result;
        return this;
    }

    public NotifyProvisioningResultRequest tokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
        return this;
    }

    public NotifyProvisioningResultRequest allDefaults() {
        requestId = TestUtils.generateRequestId();
        result = "SUCCESS";
        tokenUniqueReference = "12345";
        return this;
    }


    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("requestId", requestId);
        jsonObject.put("result", result);
        jsonObject.put("tokenUniqueReference", tokenUniqueReference);

        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }
}
