package com.mastercard.mdes.test.automation.core.mdes_utilities;

//import com.mastercard.mdes.common.tlv.BerTlv;
import com.mastercard.mdes.utility.common.util.encoding.Utf8CharacterEncodingUtil;
import com.mastercard.mdes.utility.common.util.format.FormatUtil;

import java.util.List;

/**
 * Created by E055238 on 3/1/2016.
 */
public class MDESUtilities {

    /**
     * Encoding Utils
     */

    public static String base64Encode(String text) {
        return Utf8CharacterEncodingUtil.base64Encode(text);
    }

    public static String base64Decode(String text) {
        return Utf8CharacterEncodingUtil.base64Decode(text);
    }

    public static String hexEncode(String text) {
        return Utf8CharacterEncodingUtil.hexEncode(text);
    }

    public static String hexDecode(String text) {
        return Utf8CharacterEncodingUtil.hexDecode(text);
    }

    public static String hexToBase64(String text) {
        return Utf8CharacterEncodingUtil.hexToBase64(text);
    }

    public static String base64ToHex(String text) {
        return Utf8CharacterEncodingUtil.base64ToHex(text);
    }


    /**
     * Format Utils
     */

    public static String formatJson(String jsonPayload) {
        return FormatUtil.formatJson(jsonPayload);
    }

    public static String formatXml(String xmlPayload) {
        return FormatUtil.formatXml(xmlPayload);
    }


    /**
     * CaaS Wrapper Utils
     */

    public static String caasEncrypt(String unencryptedText) {
        return new CaasServiceUtil().encrypt(unencryptedText);
    }

    public static String caasDecrypt(String encryptedText) {
        return new CaasServiceUtil().decrypt(encryptedText);
    }

    public static String wrappedEncrypt(CaasServiceUtil.EncodingType encodingType, String cardInfo, String iv,
                                        CaasServiceUtil.HashingAlgorithm hashingAlgorithm, String certString) {
        return new CaasServiceUtil().wrappedEncrypt(encodingType, cardInfo, iv,
                hashingAlgorithm, certString);
    }

    public static String wrappedDecryptUsingEncryptedPrivateKey(CaasServiceUtil.EncodingType encodingType, String encryptedData,
                                                                String encryptedKey, String encryptedPrivateKey,
                                                                String iv, CaasServiceUtil.HashingAlgorithm hashingAlgorithm) {
        return new CaasServiceUtil().wrappedDecryptUsingEncryptedPrivateKey(encodingType, encryptedData,
                encryptedKey, encryptedPrivateKey, iv, hashingAlgorithm);
    }

    public static String wrappedDecryptUsingFingerprint(CaasServiceUtil.EncodingType encodingType, String encryptedData,
                                                        String encryptedKey, String unwrappingKeyFingerprint,
                                                        String iv, CaasServiceUtil.HashingAlgorithm hashingAlgorithm) {
        return new CaasServiceUtil().wrappedDecryptUsingFingerprint(encodingType, encryptedData,
                encryptedKey, unwrappingKeyFingerprint, iv, hashingAlgorithm);
    }

    public static String hash(String value) {
        return new CaasServiceUtil().hash(value);
    }


    /**
     *  Data Element Parsing
     */

    public static java.util.Set<com.mastercard.mdes.utility.common.util.iso.SubfieldParseResult> parseDataElement(String type, String value) {
        return com.mastercard.mdes.utility.common.util.iso.DataElementParseUtil.parseRawDataElement(type, value);
    }

    public static java.util.Set<com.mastercard.mdes.utility.common.util.iso.DataElementTypeUtil.DataElementType> getDataElementTypes(String type, String value) {
        return com.mastercard.mdes.utility.common.util.iso.DataElementTypeUtil.getDataElementTypes();
    }


    /**
     *  Wrapped Encrypt Util
     */


    public static String applePayWrappedEncrypt(String fpan, String expiryMonth, String expiryYear, String cvc2, String fpanId, String devicenumber,String certString) {
        return new WrappedEncryptUtil().applePayWrappedEncrypt(fpan, expiryMonth, expiryYear, cvc2, fpanId, devicenumber,certString);
    }

    public static String mcbpWrappedEncrypt(String hexinitializationVector, String hashingAlgorithm, String fpan, String expiryMonth, String expiryYear, String cardHolderName, String source, String securityCode, String expirationTimeStamp, String addressLine1, String addressLine2, String city, String countrySubdivision, String postalCode, String country,String certString) {
        return new WrappedEncryptUtil().mcbpWrappedEncrypt(hexinitializationVector, hashingAlgorithm, fpan, expiryMonth, expiryYear, cardHolderName, source, securityCode, expirationTimeStamp, addressLine1, addressLine2, city, countrySubdivision, postalCode, country,certString);
    }

    /**
     *  TLV Parser (PBS)
     */

   /* public static List<BerTlv> parseUsingBerTlv(String value) {
        return com.mastercard.mdes.common.tlv.BerTlvParser.parse(value);
    }*/


}

