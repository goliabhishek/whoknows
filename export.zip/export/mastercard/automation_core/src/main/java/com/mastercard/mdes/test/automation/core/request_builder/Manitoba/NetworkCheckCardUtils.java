package com.mastercard.mdes.test.automation.core.request_builder.Manitoba;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;
import com.mastercard.mdes.test.automation.core.DataBaseLookUp.DBLookUpUtils;
import com.mastercard.mdes.test.automation.core.DataBaseReset.DatabaseResetUtils;
import com.mastercard.mdes.test.automation.core.DateUtils;
import com.mastercard.mdes.test.automation.core.LogHandler;
import com.mastercard.mdes.test.automation.core.PropertyHandler;
import com.mastercard.mdes.test.automation.core.TestUtils;
import com.mastercard.mdes.test.automation.core.mdes_utilities.CaasServiceUtil;
import com.mastercard.mdes.test.automation.core.mdes_utilities.MDESUtilities;
import com.mastercard.mdes.test.automation.core.request_builder.JsonObjectMapper;

import java.util.*;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.path.json.JsonPath.with;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static junit.framework.TestCase.assertTrue;

//import com.mastercard.mdes.test.automation.core.PropertyHandler;
//import junit.framework.Assert;

/**
 * Created by e062684 on 3/17/2016.
 */
@SuppressWarnings("all")
public class NetworkCheckCardUtils {
    private static final String intializationVector="00000000000000000000000000000000";
    private static final String inExpirationDateJson="\"expirationDate\" : { \"month\" : \"MONTH\", \"year\": \"YEAR\"} ";

    private String gbHttpHdrAuthorization="REQUIRED";

    private static final String prWspId_103="H4sIAAAAAAAAA51XWZOiShN9v7+iw3k0HDb3mO4IVkUFG0EEXiZYikU2pUCEX/8V2uPt7tvf3MUIQzIrOZUnK6vq+APaaTKnIQRFGeXZk8g99x7WoKoibzwDtk165AAnhsMBQUzJwZSwwcDFRzY+xCnSGzu9JxHCCogZLO2sfO6RKHaAkwNypBHjOTWbD6dW70kHBUSoaPg73nu6pkkG5930z72qyOa5DSM4z+wUwHnpzlVa2sxR4Nz+lU3v5cct2dtUxZOQF6ld/v7dzhN5A/8WOgdZGZVN70WyYQkK1i68H9g7xJcfHpyrUZDZZVWAJ9FD2H/yp974k7PRwB4Op5/439l48LkXluVpjmF1XX+vqe95EWAkjuMYPsNQjAej4FvvMRPwxMzPbyZrZ3kWuXYStXbHVgJlmHtPdBLkRVSG6f8BJjAC74AH4OoOXGKYfethH4n8Q6APGRbQHsDQJt6wdsAHBchc8LTfic+9b/+hQW44WmFnsFsM+NH8d8mB7AKS/AS8AfzF8S3Pfw74Rdlefly7h7mYuUkFowuQu3Y62S6AT68F8KPrJoKo37qO+bXetzf+1cpg79P8ZN6rwkUBgOV/WbV3K3YH0e2kAi+6SBaLLLBWgTuNnVmCv1JqNC6Oxal+viXwPvjmeKz33fzUqY/Our+xtwoysuuyPTdptAaWbZKmLmq6MtMznHD1/tRWTpFMea50VveAcKpD0jYJnktptFuBrNBHfpglm5aXdtO9dRG3k4Mgq1kQlda+Mj0G9P2RUW+lRnYmS21b4cPkdZJbpVJHjD/lNOXYjsdyf52sS7jYpLVXZNWBpgjXm8hjazlbwwkHXmuLE58fdN7l31Fag+ZBzxjhM84u7YfBdr3uo61ZghdJFLkrx7L0uQnoWmToQNzR0toqfcwVJ1PV3QXuUZ2tTkJec4q5WueWGF5cmVZ4gVHoOrCHV76ld0yQr+LIXsWYCC2at4RAPjokfl0cafOvY6fSNGTcMlZH01jF0g6vF7XJ6Yqy5q87+W2M68ZEwbu46TXWySS2ND6WWHFBE3uevUrOjrxezFSAIp9UVjprnIOA24dZJQpyYlJ6Yxu7kaSZtUzfsDm+IVY6bwbaXgr2y9XFWupHb5FcnIjZWsaOcqhVIfJC7S6uJ5O8Y7kN03oHMVBwvl6GrixpfC1rNCFpYt19DzffvvPhaKzdavv2cGQZyPEbiY5vuTKhxOq6dOU1+pUJZB0VWWN54uRS8sUzVidpp9R8cMtxydelZh6SymMZyaH0k9vyuMS9cQ6lQjsIrbfQG4UUGotlDJQztATvZC32wUZlOIckSocc3vl1dclWIaqHpnF8JrH7X7UDe2KniXxoIL6tS+rNWx00++BVliGWJjkrHcRf2sW1UL/V78po3kLILJXRdAHVkEwyJ9UbSVz4Eo0vWPW8UEWH4hSeoZU9TQ8XMs2xTKSsmUBhsbZagGXLTIU21CZx31DOm3qrhJvdpdAX+pU6HGzlQNWRbeYcvzfPhl6gam8jJyMO9iYzBIiJp/AwI4fWwlptOZ8dMnVgcJAI6WA0kuyRmZ9mtpGxKa4n9clklkfQpBJerMwjUDZWSG7aqNEk8/zKh3VJFZForlUjA+1Y2TuEXa0NtB37m1rkaIVmcgKvDy3td2u2VCV+wdGHgFHYsp/onOZmStlv1/ZEYaIhFvKRvm/p1S12J/H0kaYlVABUb4+reQarFR7tr2XA0d4tRhnyQqCgEq5TMk6wCkwzdqKL/nH0mhXHYd3Cr/YbFwSotov9JBa1qSuMGnG7XE0X8nIm9PvnyfBsQXNyNYG3JGJGDTj1umv6zimWdFFejSdsiK1qZ+XyDR7rkyWBi4amFMTIp1ai7WsXYx1rlGxKYRiqZcUbylo66e3ktOH7KXcqQHLE2f1+PT0wkeij41YtxDrMqHPDSjOn79JRY/nJyN/ErxFRjMbV0IvxXcxwJeGHR2HqnvcGT5oBdGCDtpkYLCpjSXsbV+daypH8K5Sdiix3tQSG2pG4+gTR1EGRtBwBHerEjH17DGZq20w5o6wuU3dKVadNI/CjUasek9TzRyrEMiZfX4QgaFxBx7bHKjqkEZucs3FtXsbZmh/lYi6rbRSXW4WylIk1O++JqRbfD9PPB+TDeT9CsfeH64fD903MqZVzBG75ZnVXrsj9rbQj3svCbyC1o4T2vAJA2HtBl2FQ/3STCKm9n6kH4M8IPXjg8pPAqTe9d5/mYwZsnvlRN22ngu+37++1pZvOHWAXoLhd61+QQYhe1MHBJzkvGYCuePAXaTy9S2MUsM22Be0jYfo5ZjS8xbyh0pUXdVfzDl3ZReR2+J9GXjqlAJFUQGI8AN9r+D29CV4XCd7vbp7e/Rg8ORiB4RgqTYQ0DlIrHz4Ehb7dLzlhbvZkxI/5IZaBss6LmA2BG7+T0I/JP9kf0sQ+1eWReBlmaonaJ0WL9nQzf/9X4v2LCK4E1/ILF5ugJkFa5uW3fy/cudvFIfcr+kHc/qT0BdQXYx98DxoP768+ffnjfyyuzG1sDQAA";

    private	int	inWspId;	                            //	DEFAULT
    private	String[] inWrappedEncryptAlgorithm;	        //	DEFAULT
    private	String[] inUnencryptedJson;	                //	DEFAULT
    private	String[] inSsdSpsdCertificateSerialNumber;	//	DEFAULT
    private	String[] inSsdMcpkKeyIdentifier;	        //	DEFAULT
    private	String[] inSsdMcpkKey;	                    //	DEFAULT
    private	String[] inSsdMcpkCertificate;	            //	DEFAULT
    private	String[] inSsdDescriptor;	                //	DEFAULT
    private	String[] inSsdCounter;	                    //	DEFAULT
    private	String[] inSsdCasdCertificate;	            //	DEFAULT
    private	String[] inSsdAppletVersionNumber;	        //	DEFAULT
    private	String[] inSsdAppletInstanceAid;	        //	DEFAULT
    private	String[] inSsdApduResponse;	                //	DEFAULT
    private	String[] inSsdAid;	                        //	DEFAULT
    private	String[] inSignatureAlgInfo;	            //	DEFAULT
    private	String inSeid;	                            //	NODEFAULT
    private	String inRptHttpHeaders;	                //	DEFAULT
    private	String inRequestId;	                        //	DEFAULT
    private	String[] inPkcs7Signature;	                //	DEFAULT
    private	String[] inJsonToEncrypt;	                //	CONDITIONAL
    private	String inHttpHdrXpod;	                    //	DEFAULT
    private	String[] inGenerateJsonToEncrypt;	        //	DEFAULT
    private	String[] inFpanSource;	                    //	DEFAULT
    private	String[] inFpanId;	                        //	NODEFAULT-CONDITIONAL
    private	String[] inFpan;	                        //	NODEFAULT-CONDITIONAL
    private	String[] inForceBadWrappedKey;	            //	DEFAULT
    private	String[] inExp;	                            //	OPTIONAL
    private	int[] inDeviceType;	                        //	DEFAULT
    private	String[] inDeviceAcceptLanguage;	        //	DEFAULT
    private	String inDbReset;	                        //	DEFAULT
    private	String inConversationId;	                //	DEFAULT
    private	String[] inCardIdentifier;	                //	DEFAULT
    private int	inArrayCnt;	                            //	DEFAULT
    private	String[] inAllowUnencryptedFallback;	    //	DEFAULT

    //**********************Derived Member Variables*****************************
    private String[] expMM ; //Derived from inExp ref seperateExpireIntoMaonthAndYear()
    private String[] expYY ; //Derived from inExp seperateExpireIntoMaonthAndYear()
    private String[] bcFpanKey ;//Derived from inFpan and inFpanId
    private String[] bcSsdDescriptor;//Derived from setSsdDescriptor()
    private String[] bcWrappedKey;//Derived from forcedBadWrappedKey()
    private String[] bcPublicKeyFingerprint;
    private String[] bcAsymmetricAlgorithmIdentifier;
    private String[] bcSymmetricAlgorithmIdentifier;
    private String[] bcUnencryptedData;
    private String[] bcEncryptedData;
    private String[] bcFpanCardDescriptor;
    private String[] bcNetworkCheckCardRequest;
    //************************ OUTPUT Member Variables **************************
    private String[] outAsymmetricAlgorithmIdentifier;
    private String[] outEncryptedData;
    private String[] outPublicKeyFingerPrint;
    private String[] outSymmetricAlgorithmIdentifier;
    private String[] outWrappedKey;
    private String[] outJsonThatWasEncrypted;
    private int outHttpStatusCode;
    private Map<String, String> outRspHttpHeaders;
    private String outReqJson;
    private String outRspJson;
    private String outEndpoint;
    private String outReqHdrRequestId;
    private String outReqHdrConversationId;
    private String[] outReqWrappedKey;
    private String[] outReqPublicKeyFingerPrint;
    private String[] outReqAsymmetricAlgorithmIdentifier;
    private String[] outReqSymmetricAlgorithmIdentifier;
    private String[] outReqEncryptedData;
    private String[] outReqCardIdentifier;
    private int[] outReqDeviceType;
    private String[] outReqAppletInstanceAid;
    private String[] outReqAppletVersionNumber;
    private String outSuid;

    private String[] outRspStatusCode;
    private String[] outRspTokenValue;

    private String[] outDpan;

    private String[] outTRID;
    private String[] outPrvsnRqstId;
    private String[] outMapId;
    private String[] outPanDataEncId;
    private String[] outPAID;
    private String[] outWltPrvdrId;
    private String[] outHash;
    private String[] outEncryptPanDataDecrypted;
    private String[] outRspStatusMessage;
    private String[] outRspNetworkSubStatusCode;
    private String[] outRspProductType;
    private String[] outRspIssuerAppStoreIdentifier;
    private int[] outRspTokenTTLInMinutes;
    private String[] outRspCardHomeCountry;
    private List<String>[] outRspCardArtManifest;
    private String[] outRspCardIdentifier;
    private String[] outRspCardIssuer;
    private String outDttmBefore;
    private String outDttmMsBefore;
    private String outDttmAfter;
    private String outDttmMsAfter;

    private String outHttpHdrXPod;

    private String outRspHdrConversationId;
    private String outRspHdrResponseId;
    private String outRspHdrStatusCode;
    private String outRspHdrStatusMessage;



    public NetworkCheckCardUtils() throws Exception {
        //All the defaults get initialized
        this.inArrayCnt=1;
        setInAllDefaults();
        //refer setTcArrayCnt(int inArrayCnt)
        //if the user wants to change the inArrayCnt
        //by setter method setInAllDefaults(); will be called and
        //all the values get reset
    }

    public NetworkCheckCardUtils runNetworkCheckCard() throws Exception {

        runDBReset();
        getWrappedKey();
        forcedBadWrappedKey();

        //Set request method calls

        setSsdDescriptor();
        setUnencryptedData();
        setFpanCardDescriptor();
        setRequestArray();
        setHttpHeaderXpod();

        //Get Response Methods calls

        getSysDateBefore();
        delay();
        getSysDateAfter();
        getHttpStatusCode();
        getReqTags();
        getRspTags();
        getDBkeyIds();
        getFpanHash();
        getDecryptedDpan();
        getDpanHash();
        return this;
    }

    //******************** SETTERS START HERE *********************************


    public void setInWspId(int inWspId) {
        this.inWspId = inWspId;
    }

    public void setInWrappedEncryptAlgorithm(String[] inWrappedEncryptAlgorithm) {
        assertTrue("inWrappedEncryptAlgorithm array should be of size "+inArrayCnt,inWrappedEncryptAlgorithm.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inWrappedEncryptAlgorithm[i].equalsIgnoreCase("NULL"))
//            this.inWrappedEncryptAlgorithm[i] = inWrappedEncryptAlgorithm[i];
//        }
        this.inWrappedEncryptAlgorithm = inWrappedEncryptAlgorithm;
    }

    public void setInUnencryptedJson(String[] inUnencryptedJson) {
        assertTrue("inUnencryptedJson array should be of size "+inArrayCnt,inUnencryptedJson.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inUnencryptedJson[i].equalsIgnoreCase("NULL"))
//            this.inUnencryptedJson[i] = inUnencryptedJson[i];
//        }
        this.inUnencryptedJson = inUnencryptedJson;
    }

    public void setInSsdSpsdCertificateSerialNumber(String[] inSsdSpsdCertificateSerialNumber) {
        assertTrue("inSsdSpsdCertificateSerialNumber array should be of size "+inArrayCnt,inSsdSpsdCertificateSerialNumber.length==inArrayCnt);
        for (int i = 0; i < inArrayCnt ; i++) {
            if(!inSsdSpsdCertificateSerialNumber[i].equalsIgnoreCase("NULL"))
                this.inSsdSpsdCertificateSerialNumber[i] = inSsdSpsdCertificateSerialNumber[i];
        }
        this.inSsdSpsdCertificateSerialNumber = inSsdSpsdCertificateSerialNumber;
    }

    public void setInSsdMcpkKeyIdentifier(String[] inSsdMcpkKeyIdentifier) {
        assertTrue("inSsdMcpkKeyIdentifier array should be of size "+inArrayCnt,inSsdMcpkKeyIdentifier.length==inArrayCnt);
        for (int i = 0; i < inArrayCnt ; i++) {
            if(!inSsdMcpkKeyIdentifier[i].equalsIgnoreCase("NULL"))
                this.inSsdMcpkKeyIdentifier[i] = inSsdMcpkKeyIdentifier[i];
        }
        this.inSsdMcpkKeyIdentifier = inSsdMcpkKeyIdentifier;
    }

    public void setInSsdMcpkKey(String[] inSsdMcpkKey) {
        assertTrue("inSsdMcpkKey array should be of size "+inArrayCnt,inSsdMcpkKey.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inSsdMcpkKey[i].equalsIgnoreCase("NULL"))
//                this.inSsdMcpkKey[i] = inSsdMcpkKey[i];
//        }
        this.inSsdMcpkKey = inSsdMcpkKey;
    }

    public void setInSsdMcpkCertificate(String[] inSsdMcpkCertificate) {
        assertTrue("inSsdMcpkCertificate array should be of size "+inArrayCnt,inSsdMcpkCertificate.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inSsdMcpkCertificate[i].equalsIgnoreCase("NULL"))
//                this.inSsdMcpkCertificate[i] = inSsdMcpkCertificate[i];
//        }
        this.inSsdMcpkCertificate = inSsdMcpkCertificate;
    }

    public void setInSsdDescriptor(String[] inSsdDescriptor) {
        assertTrue("inSsdMcpkCertificate array should be of size "+inArrayCnt,inSsdDescriptor.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt; i++) {
//            assertTrue(" Provided an override value for 'inSsdDescriptor' property but 'inArrayCnt' = [" + inArrayCnt + "]",
//                    (inSsdDescriptor[i].equalsIgnoreCase("PRESENT") || inSsdDescriptor[i].equalsIgnoreCase("NOT-PRESENT")));
//            this.inSsdDescriptor[i] = inSsdDescriptor[i];
//        }
        this.inSsdDescriptor = inSsdDescriptor;
    }

    public void setInSsdCounter(String[] inSsdCounter) {
        assertTrue("inSsdCounter array should be of size "+inArrayCnt,inSsdCounter.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inSsdCounter[i].equalsIgnoreCase("NULL"))
//                this.inSsdCounter[i] = inSsdCounter[i];
//        }
        this.inSsdCounter = inSsdCounter;
    }

    public void setInSsdCasdCertificate(String[] inSsdCasdCertificate) {
        assertTrue("inSsdCasdCertificate array should be of size "+inArrayCnt,inSsdCasdCertificate.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inSsdCasdCertificate[i].equalsIgnoreCase("NULL"))
//                this.inSsdCasdCertificate[i] = inSsdCasdCertificate[i];
//        }
        this.inSsdCasdCertificate = inSsdCasdCertificate;
    }

    public void setInSsdAppletVersionNumber(String[] inSsdAppletVersionNumber) {
        assertTrue("inSsdAppletVersionNumber array should be of size "+inArrayCnt,inSsdAppletVersionNumber.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inSsdAppletVersionNumber[i].equalsIgnoreCase("NULL"))
//                this.inSsdAppletVersionNumber[i] = inSsdAppletVersionNumber[i];
//        }
        this.inSsdAppletVersionNumber = inSsdAppletVersionNumber;
    }

    public void setInSsdAppletInstanceAid(String[] inSsdAppletInstanceAid) {
        assertTrue("inSsdAppletVersionNumber array should be of size "+inArrayCnt,inSsdAppletInstanceAid.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inSsdAppletInstanceAid[i].equalsIgnoreCase("NULL"))
//                this.inSsdAppletInstanceAid[i] = inSsdAppletInstanceAid[i];
//        }
        this.inSsdAppletInstanceAid = inSsdAppletInstanceAid;
    }

    public void setInSsdApduResponse(String[] inSsdApduResponse) {
        assertTrue("inSsdApduResponse array should be of size "+inArrayCnt,inSsdApduResponse.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inSsdApduResponse[i].equalsIgnoreCase("NULL"))
//                this.inSsdApduResponse[i] = inSsdApduResponse[i];
//        }
        this.inSsdApduResponse = inSsdApduResponse;
    }

    public void setInSsdAid(String[] inSsdAid) {
        assertTrue("inSsdAid array should be of size "+inArrayCnt,inSsdAid.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inSsdAid[i].equalsIgnoreCase("NULL"))
//                this.inSsdAid[i] = inSsdAid[i];
//        }
        this.inSsdAid = inSsdAid;
    }

    public void setInSignatureAlgInfo(String[] inSignatureAlgInfo) {
        assertTrue("inSignatureAlgInfo array should be of size "+inArrayCnt,inSignatureAlgInfo.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inSignatureAlgInfo[i].equalsIgnoreCase("NULL"))
//                this.inSignatureAlgInfo[i] = inSignatureAlgInfo[i];
//        }
        this.inSignatureAlgInfo = inSignatureAlgInfo;
    }

    public void setInSeid(String inSeid) {
        this.inSeid = inSeid;
    }

    public void setInRptHttpHeaders(String inRptHttpHeaders) {
        assertTrue(" property 'inRptHttpHeaders' = [" + inRptHttpHeaders + "] ... but must be 'Y' or 'N'",
                (inRptHttpHeaders.equalsIgnoreCase("Y") && inRptHttpHeaders.equalsIgnoreCase("N")));
        this.inRptHttpHeaders = inRptHttpHeaders;
    }

    public void setInRequestId(String inRequestId) {
        assertTrue("inWspId array should be of size "+inArrayCnt,inSsdApduResponse.length==inArrayCnt);
        this.inRequestId = inRequestId;
    }

    public void setInPkcs7Signature(String[] inPkcs7Signature) {
        assertTrue("inPkcs7Signature array should be of size "+inArrayCnt,inPkcs7Signature.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inPkcs7Signature[i].equalsIgnoreCase("NULL"))
//                this.inPkcs7Signature[i] = inPkcs7Signature[i];
//        }
        this.inPkcs7Signature = inPkcs7Signature;
    }

    public void setInJsonToEncrypt(String[] inJsonToEncrypt) {
        assertTrue("inJsonToEncrypt array should be of size "+inArrayCnt,inJsonToEncrypt.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inJsonToEncrypt[i].equalsIgnoreCase("NULL"))
//                this.inJsonToEncrypt[i] = inJsonToEncrypt[i];
//        }
        this.inJsonToEncrypt = inJsonToEncrypt;
    }

    public void setInHttpHdrXpod(String inHttpHdrXpod) {
        this.inHttpHdrXpod = inHttpHdrXpod;
    }

    public void setInGenerateJsonToEncrypt(String[] inGenerateJsonToEncrypt) {
        assertTrue("inGenerateJsonToEncrypt array should be of size "+inArrayCnt,inGenerateJsonToEncrypt.length==inArrayCnt);
        this.inGenerateJsonToEncrypt = inGenerateJsonToEncrypt;
    }

    public void setInFpanSource(String[] inFpanSource) {
        assertTrue("inFpanSource array should be of size "+inArrayCnt,inFpanSource.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inFpanSource[i].equalsIgnoreCase("NULL"))
//                this.inFpanSource[i] = inFpanSource[i];
//        }
        this.inFpanSource = inFpanSource;
    }

    public void setInFpanId(String[] inFpanId) {
        assertTrue("inFpanId array should be of size "+inArrayCnt,inFpanId.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inFpanId[i].equalsIgnoreCase("NULL"))
//                this.inFpanId[i] = inFpanId[i];
//        }
        this.inFpanId = inFpanId;
    }

    public void setInFpan(String[] inFpan) {
        assertTrue("inFpan array should be of size "+inArrayCnt,inFpan.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            assertTrue("inFpan["+i+"] value is null ",!inFpan[i].equalsIgnoreCase("NULL"));
//            this.inFpan[i] = inFpan[i];
//        }
        this.inFpan = inFpan;
    }

    public void setInForceBadWrappedKey(String[] inForceBadWrappedKey) {
        assertTrue("inForceBadWrappedKey array should be of size "+inArrayCnt,inForceBadWrappedKey.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inForceBadWrappedKey[i].equalsIgnoreCase("NULL"))
//                this.inForceBadWrappedKey[i] = inForceBadWrappedKey[i];
//        }
        this.inForceBadWrappedKey = inForceBadWrappedKey;
    }

    public void setInExp(String[] inExp) {
        assertTrue("inExp array should be of size "+inArrayCnt,inExp.length==inArrayCnt);

        seperateExpireIntoMonthAndYear(inExp);
//        this.inExp = inExp;
    }

    public void setInDeviceType(int[] inDeviceType) {
        assertTrue("inDeviceType array should be of size "+inArrayCnt,inDeviceType.length==inArrayCnt);
        this.inDeviceType = inDeviceType;
    }

    public void setInDeviceAcceptLanguage(String[] inDeviceAcceptLanguage) {
        assertTrue("inDeviceAcceptLanguage array should be of size "+inArrayCnt,inDeviceAcceptLanguage.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inDeviceAcceptLanguage[i].equalsIgnoreCase("NULL"))
//                this.inDeviceAcceptLanguage[i] = inDeviceAcceptLanguage[i];
//        }
        this.inDeviceAcceptLanguage = inDeviceAcceptLanguage;
    }

    public void setInDbReset(String inDbReset) {
        this.inDbReset = inDbReset;
    }

    public void setInConversationId(String inConversationId) {
        this.inConversationId = inConversationId;
    }

    public void setInCardIdentifier(String[] inCardIdentifier) {
        assertTrue("inCardIdentifier array should be of size "+inArrayCnt,inCardIdentifier.length==inArrayCnt);
//        for (int i = 0; i < inArrayCnt ; i++) {
//            if(!inCardIdentifier[i].equalsIgnoreCase("NULL"))
//                this.inCardIdentifier[i] = inCardIdentifier[i];
//        }
        this.inCardIdentifier = inCardIdentifier;
    }

    public void setInArrayCnt(int inArrayCnt) throws Exception {
        this.inArrayCnt = inArrayCnt;
        setInAllDefaults();
    }

    public void setInAllowUnencryptedFallback(String[] inAllowUnencryptedFallback) {
        this.inAllowUnencryptedFallback = inAllowUnencryptedFallback;
    }
    //******************** SETTERS END HERE *********************************

    //******************** SET ALL DEFAULT VALUES ***************************
    private void setInAllDefaults() throws Exception {
        // All values are set as per DEV-TEST environment
        this.inConversationId=(UUID.randomUUID().toString() + "=" + UUID.randomUUID().toString()).substring(1,64);
        this.inDbReset=PropertyHandler.getManitobaNccProperty("nccDfltDbReset");
        inHttpHdrXpod="Test Harness";
        inRptHttpHeaders=PropertyHandler.getManitobaNccProperty("nccDfltRptHttpHeaders");

        this.inWspId=Integer.parseInt(PropertyHandler.getManitobaNccProperty("nccDfltWspId"));
        int stackCount=Thread.currentThread().getStackTrace().length;
        inRequestId="networkCheckCard"+ TestUtils.generateUniqueRequestId("");


        inAllowUnencryptedFallback = new String[inArrayCnt];
        inCardIdentifier = new String[inArrayCnt];
        inDeviceType = new int[inArrayCnt];
        inDeviceAcceptLanguage = new String[inArrayCnt];
        inExp = new String[inArrayCnt];
        inForceBadWrappedKey = new String[inArrayCnt];
        inFpanSource = new String[inArrayCnt];
        inGenerateJsonToEncrypt = new String[inArrayCnt];
        inPkcs7Signature = new String[inArrayCnt];
        inSignatureAlgInfo = new String[inArrayCnt];
        inSsdDescriptor = new String[inArrayCnt];
        inSsdAid = new String[inArrayCnt];
        inSsdApduResponse = new String[inArrayCnt];
        inSsdAppletInstanceAid = new String[inArrayCnt];
        inSsdAppletVersionNumber = new String[inArrayCnt];
        inSsdCasdCertificate = new String[inArrayCnt];
        inSsdCounter = new String[inArrayCnt];
        inSsdMcpkCertificate = new String[inArrayCnt];
        inSsdMcpkKey = new String[inArrayCnt];
        inSsdMcpkKeyIdentifier = new String[inArrayCnt];
        inSsdSpsdCertificateSerialNumber = new String[inArrayCnt];
        inWrappedEncryptAlgorithm = new String[inArrayCnt];

        for (int i = 0; i < inArrayCnt; i++) {

            inAllowUnencryptedFallback[i]=PropertyHandler.getManitobaNccProperty("nccDfltAllowUnencryptedFallback");
            inCardIdentifier[i]=PropertyHandler.getManitobaNccProperty("nccDfltCardIdentifier");
            inDeviceType[i]=Integer.parseInt(PropertyHandler.getManitobaNccProperty("nccDfltDeviceType"));
            inDeviceAcceptLanguage[i]=PropertyHandler.getManitobaNccProperty("nccDfltDeviceAcceptLanguage");
            inForceBadWrappedKey[i]=PropertyHandler.getManitobaNccProperty("nccDfltForceBadWrappedKey");
            inFpanSource[i]=PropertyHandler.getManitobaNccProperty("nccDfltFpanSource");
            inGenerateJsonToEncrypt[i]=PropertyHandler.getManitobaNccProperty("nccDfltGenerateJsonToEncrypt");
            inPkcs7Signature[i]=PropertyHandler.getManitobaNccProperty("nccDfltPkcs7Signature");
            inSignatureAlgInfo[i]=PropertyHandler.getManitobaNccProperty("nccDfltSignatureAlgInfo");
            inSsdDescriptor[i]=PropertyHandler.getManitobaNccProperty("nccDfltSsdDescriptor");
            inSsdAid[i]=PropertyHandler.getManitobaNccProperty("nccDfltSsdAid");
            inSsdApduResponse[i]=PropertyHandler.getManitobaNccProperty("nccDfltSsdApduResponse");
            inSsdAppletInstanceAid[i]=PropertyHandler.getManitobaNccProperty("nccDfltSSdAppletInstanceAid");
            inSsdAppletVersionNumber[i]=PropertyHandler.getManitobaNccProperty("nccDfltSsdAppletVersionNumber");
            inSsdCasdCertificate[i]=PropertyHandler.getManitobaNccProperty("nccDfltSsdCasdCertificate");
            inSsdCounter[i]=PropertyHandler.getManitobaNccProperty("nccDfltSsdCounter");
            inSsdMcpkCertificate[i]=PropertyHandler.getManitobaNccProperty("nccDfltSsdMcpkCertificate");
            inSsdMcpkKey[i]=PropertyHandler.getManitobaNccProperty("nccDfltSsdMcpkKey");
            inSsdMcpkKeyIdentifier[i]=PropertyHandler.getManitobaNccProperty("nccDfltSsdMcpkKeyIdentifier");
            inSsdSpsdCertificateSerialNumber[i]=PropertyHandler.getManitobaNccProperty("nccDfltSsdSpsdCertificateSerialNumber");
            inWrappedEncryptAlgorithm[i]=PropertyHandler.getManitobaNccProperty("nccDfltWrappedEncryptAlgorithm");

        }

        setBcFpanKey();
//        seperateExpireIntoMonthAndYear(inExp);


    }
    //*********** END SETTING ALL DEFAULT VALUES *****************

    //*********** SET ALL DERIVED MEMBER VARIABLES *******************
    private void seperateExpireIntoMonthAndYear(String[] inExp)
    {

        this.inExp = new String[inArrayCnt];
        LogHandler.print("Size of array :"+inArrayCnt);
        expMM = new String[inArrayCnt];
        expYY = new String[inArrayCnt];
        for (int i = 0; i < inArrayCnt; i++) {
//            if(!inExp[i].equalsIgnoreCase("NULL"))
                this.inExp[i]= inExp[i];
                String message=" 'inExp["+i+"]' = [" + inExp[i] + "] is invalid"+
                        " must be in either MMYY or MMYYYY format";
                assertTrue(message,inExp[i].length()==4 || inExp[i].length()==6);
                if (inExp[i].length() == 4) {
                    expMM[i]=inExp[i].substring(0,2);
                    expYY[i]=inExp[i].substring(2,4);
                } else if (inExp[i].length() == 6) {
                    expMM[i]=inExp[i].substring(0,2);
                    expYY[i]=inExp[i].substring(2,6);
                }
                LogHandler.print("Month :"+expMM[i] +","+"Year :"+expYY[i]);
            }
    }

    private void setBcFpanKey()
    {
        bcFpanKey=new String[inArrayCnt];
        for (int i = 0; i < inArrayCnt; i++) {
            bcFpanKey[i]="BYFPANEXP";
        }
    }


    //**************** END SETTING ALL DERIVED MEMBER VARIABLES **********

    //********************* General Method Calls **************************

    private String getGBCretFileLocation(String algorithm) throws Exception {
        assertTrue("invalid override value for 'inAlgorithm' property; must be RSA or ECIES",algorithm.equals("RSA")|| algorithm.equals("ECIES"));
        String gbCertFileKey = "";
        String gbCertFileString="";
        switch (algorithm) {

            case "RSA":
                gbCertFileKey = "gbWrappedEncryptRsaCertFile";
                gbCertFileString="-----BEGIN CERTIFICATE-----" +
                        "MIIEyDCCA7CgAwIBAgIQZIu6CiTy25HWG0aHsduumTANBgkqhkiG9w0BAQU" +
                        "FADCBgDELMAkGA1UEBhMCQkUxHTAbBgNVBAoMFE1hc3RlckNhcmQgV29ybGRXaWRlMSkwJwYDVQQLDCBHbG9iYWwgVGVjaG" +
                        "5vbG9neSBhbmQgT3BlcmF0aW9uczEnMCUGA1UEAwweTWFzdGVyQ2FyZCBERVYgR2VuZXJpYyBTdWIgQ0ExMB4XDTE0MDEwO" +
                        "TEyNTExMFoXDTIwMDgyNzA5MDEzOVowgY4xJDAiBgNVBAMTG2Rldi1jYWFzLXdzcC5tYXN0ZXJjYXJkLmludDERMA8GA1UE" +
                        "CxMIQ2xpZW50MDAxHTAbBgNVBAoTFE1hc3RlckNhcmQgV29ybGR3aWRlMRQwEgYDVQQHEwtTYWludCBMb3VpczERMA8GA1U" +
                        "ECBMITWlzc291cmkxCzAJBgNVBAYTAlVTMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArKUJF+e7Klm48QVoIw" +
                        "FAajSBXCJaCjug3fkqBs4OjbRjRfoqLjONEKTwCCSrM8c/XxAbwbjIsj6G+zB3hVqCxmDEXc7JBF2dwUzBxkAu4u0JOGB/d" +
                        "/kxnWU+pTC2glds97/6kZMk4ts5QeqO4QebyunjMYpGE35blAiT2xNsyOHEAKwj+JByZPVWBJwpYwbywy0hOXw1eEPpsVLh" +
                        "uiOIFubxEzV9A/4YFDXTEjpFcs4rFG9N2hHIopSMVT6DiU0CCmCMvGoqxGVTHTH13/pDloXGHZ2FS4HKCExyi+yW1J87FfE" +
                        "cZ07Ypk4Gvq/CnrSDOfho+nzgRDxOWlAzaebMNQIDAQABo4IBLDCCASgwDgYDVR0PAQH/BAQDAgWgMBEGCWCGSAGG+EIBAQ" +
                        "QEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAjAPBgNVHRMBAf8EBTADAgEAMIG9BgNVHSMEgbUwgbKAFBmZVL+q/nch15a6v" +
                        "NtX7meUY3z6oYGHpIGEMIGBMQswCQYDVQQGEwJCRTEdMBsGA1UECgwUTWFzdGVyQ2FyZCBXb3JsZFdpZGUxKTAnBgNVBAsM" +
                        "IEdsb2JhbCBUZWNobm9sb2d5IGFuZCBPcGVyYXRpb25zMSgwJgYDVQQDDB9NYXN0ZXJDYXJkIERFViBHZW5lcmljIFJvb3Q" +
                        "gQ0ExghASsTD6fACR+7HvY3JLzI94MB0GA1UdDgQWBBRf/snx0sYrPa6SvSGxU/r7uOy8NTANBgkqhkiG9w0BAQUFAAOCAQ" +
                        "EABtaGSku3gwspy3n2lQbqm/otZvxGhBvB5ra8nbl5ED4wJd4cunnalEsn3kOyDWxpLtnEczwh7wa+bqvT3d4Hmeklh4Zoc" +
                        "Doty4BPOAM+n5DvVqXMSG+aWFIyfADPoWduVmg7ZDNA7qR9A5/5BDaOor8dRrzrUqd3mz0RM4nQnGz12qLLKjEsG65TPaku" +
                        "fKTMtHQae+8PqEbJoabSJLhMGpx5SHX43wPhqzkBW55TWHdUDyyYV3xYpsdyzLRE8R7ShwQbNCcsKyiVWFShVdgcyjnGeLK" +
                        "772JGxGoX6WyaMB8H/FHF2x2zoWq6OLZRau/ifd9M1NA3FZQBL1KqPnW35A==" +
                        "-----END CERTIFICATE-----";
                break;

            case "ECIES":
                gbCertFileKey = "gbWrappedEncryptEciesCertFile";
                break;


        }

        return gbCertFileString;
    }
    private void runDBReset()
    {
        assertNotNull("SEID value is not set ",inSeid);
        String inDeleteById = "BYSEIDFPAN";
        for (int i = 0; i <inArrayCnt ; i++) {
            if(bcFpanKey[i].equalsIgnoreCase("BYFPANID"))
            {
                inDeleteById="BYSEIDFPANID";
            }
            if (inDeleteById.equalsIgnoreCase("BYSEIDFPAN")) {
                assertNotNull("Fpan values are not set ",inFpan);
                DatabaseResetUtils.resetDatabaseBySEIDAndFPAN(inSeid, inFpan[i]);
            }
            else {
                assertNull("FpanId values are not set ",inFpanId);
                DatabaseResetUtils.resetDatabaseBySEIDAndFPANID(inSeid,inFpanId[i]);
            }
        }
    }
    private void getWrappedKey() throws Exception {

        outJsonThatWasEncrypted=new String[inArrayCnt];

        outAsymmetricAlgorithmIdentifier=new String[inArrayCnt];
        outEncryptedData=new String[inArrayCnt];
        outPublicKeyFingerPrint=new String[inArrayCnt];
        outSymmetricAlgorithmIdentifier=new String[inArrayCnt];
        outWrappedKey=new String[inArrayCnt];

        bcAsymmetricAlgorithmIdentifier=new String[inArrayCnt];
        bcEncryptedData=new String[inArrayCnt];
        bcPublicKeyFingerprint=new String[inArrayCnt];
        bcSymmetricAlgorithmIdentifier=new String[inArrayCnt];
        bcWrappedKey=new String[inArrayCnt];

        Map<Integer,Map> finalResultMap=new LinkedHashMap<>();
        String generatedJson;
        String json;
        for (int i = 0; i <inArrayCnt ; i++) {
            Map<String, Object> resultMap=new HashMap<>();
            if (bcFpanKey[i].equalsIgnoreCase("BYFPANEXP")) {
                String inFpanValue = inFpan[i];

                //expiry is now optional so:
                String inExpValue = inExp[i];
                if (inExp[i].isEmpty()) {
                    generatedJson = "{ \"fpan\": \"" + inFpanValue + "\" }";
                }
                else {
                    String inExpirationDateJsonNew = inExpirationDateJson.replaceAll("MONTH", expMM[i]);
                    inExpirationDateJsonNew = inExpirationDateJsonNew.replaceAll("YEAR", expYY[i]);
                    generatedJson = "{ \"fpan\":\"" + inFpanValue + "\" ," + inExpirationDateJsonNew + "}";
                }

            }
            else {
                String inFpanIdValue = inFpanId[i];
                generatedJson = "{ \"fpanId\": \"" + inFpanIdValue + "\" }";
            }
            String inGenerateJsonToEncryptValue=inGenerateJsonToEncrypt[i];
            if (inGenerateJsonToEncryptValue.equalsIgnoreCase("Y")) {
                json = generatedJson;
            }
            else {
                String inJsonToEncryptValue = inJsonToEncrypt[i];
                json = inJsonToEncryptValue;
            }

            String response=MDESUtilities.wrappedEncrypt(CaasServiceUtil.EncodingType.HEX,json,intializationVector
                    , CaasServiceUtil.HashingAlgorithm.SHA256
                    ,getGBCretFileLocation(inWrappedEncryptAlgorithm[i]));

            JsonPath jp = new JsonPath(response);
            outAsymmetricAlgorithmIdentifier[i]=jp.getString("asymmetricAlgorithmId");
            bcAsymmetricAlgorithmIdentifier[i]=outAsymmetricAlgorithmIdentifier[i];
            outEncryptedData[i]=jp.getString("encryptedText");
            bcEncryptedData[i]=outEncryptedData[i];
            outPublicKeyFingerPrint[i]=jp.getString("wrappingKeyFingerprint");
            bcPublicKeyFingerprint[i]=outPublicKeyFingerPrint[i];
            outSymmetricAlgorithmIdentifier[i]=jp.getString("symmetricAlgorithmId");
            bcSymmetricAlgorithmIdentifier[i]=outSymmetricAlgorithmIdentifier[i];
            outWrappedKey[i]=jp.getString("wrappedKey");
            bcWrappedKey[i]=outWrappedKey[i];
            outJsonThatWasEncrypted[i]=json;


        }
    }

    private void forcedBadWrappedKey()
    {
        String[] bcWrappedKey = new String[inArrayCnt];
        for (int i = 0; i <inArrayCnt ; i++) {
            if(inForceBadWrappedKey[i].equalsIgnoreCase("Y")){
                bcWrappedKey[i]="badWrappedKeyValue";
            }
        }
    }

    private void setSsdDescriptor()
    {
        bcSsdDescriptor=new String[inArrayCnt];
        String ssdDescriptor;
        for (int i = 0; i <inArrayCnt ; i++) {
            bcSsdDescriptor[i]="";
            if(!inSsdDescriptor[i].isEmpty())
            {
                if(inSsdDescriptor[i].equalsIgnoreCase("PRESENT")){
                    ssdDescriptor = "\"ssdDescriptor\" : { \n" +
                            "                \"apduResponse\" : \"" + inSsdApduResponse[i] + "\", \n" +
                            "                \"counter\" : \"" + inSsdCounter[i] + "\", \n" +
                            "                \"aid\" : \"" + inSsdAid[i] + "\", \n" +
                            "                \"appletInstanceAid\" : \"" + inSsdAppletInstanceAid[i] + "\", \n";
                    if (!inSsdSpsdCertificateSerialNumber[i].isEmpty()) {
                        ssdDescriptor = ssdDescriptor + "                \"spsdCertificateSerialNumber\" :" +
                                "\"" + inSsdSpsdCertificateSerialNumber[i] + "\",\n";
                    }
                    ssdDescriptor 	= ssdDescriptor + "                \"appletVersionNumber\" : \""
                            + inSsdAppletVersionNumber[i] + "\", \n" +
                            "                \"casdCertificate\" : \"" + inSsdCasdCertificate[i] + "\", \n" +
                            "                \"mobileCommercePublicKeyInfo\" : { \n" +
                            "                \"keyIdentifier\" : \"" + inSsdMcpkKeyIdentifier[i] + "\", \n" +
                            "                \"key\" : \"" + inSsdMcpkKey[i] + "\"";
                    if (!inSsdMcpkCertificate[i].isEmpty()) {
                        ssdDescriptor = ssdDescriptor + ",\n                \"certificate\" : \""
                                + inSsdMcpkCertificate[i] + "\"\n";
                    }
                    ssdDescriptor = ssdDescriptor + "                 }\n" +
                            "            }, ";

                    bcSsdDescriptor[i]=ssdDescriptor;
                }
            }
            else {

                ssdDescriptor = "\"ssdDescriptor\" : " + inSsdDescriptor[i] + ", ";
                bcSsdDescriptor[i]=ssdDescriptor;

            }
        }
    }
    private void setUnencryptedData()
    {
        // Currently working
        bcUnencryptedData=new String[inArrayCnt];
        for (int i = 0; i <inArrayCnt ; i++) {
            String json = outJsonThatWasEncrypted[i];
            if (inAllowUnencryptedFallback[i].equalsIgnoreCase("Y")) {
                json = json.replaceAll("\"", "\\\\\"");
            }
            else {
                json = "{xxx}";
            }
            bcUnencryptedData[i] = "                \"unencryptedData\" : \"" + json + "\",";
        }
    }
    private void setFpanCardDescriptor()
    {
        bcFpanCardDescriptor=new String[inArrayCnt];
        for (int i = 0; i <inArrayCnt ; i++) {
            String fpanCardDescriptor =	"\"fpanCardDescriptor\" : { \n" +
                    "                \"keyInfo\" : { \n" +
                    "                \"wrappedKey\" : \"" + bcWrappedKey[i] + "\", \n" +
                    "                \"publicKeyFingerprint\" : \"" + bcPublicKeyFingerprint[i] + "\", \n" +
                    "                \"asymmetricAlgorithmIdentifier\" : \"" + bcAsymmetricAlgorithmIdentifier[i] + "\", \n" +
                    "                \"symmetricAlgorithmIdentifier\" : \"" + bcSymmetricAlgorithmIdentifier[i] + "\"";
            if(!inSignatureAlgInfo[i].isEmpty())
            {
                fpanCardDescriptor = fpanCardDescriptor + ",\n                 " +
                        "\"signatureAlgInfo\" : \"" + inSignatureAlgInfo[i] + "\"";
            }
            fpanCardDescriptor = 	fpanCardDescriptor + "\n                }, \n";
            if (!bcUnencryptedData[i].isEmpty()) {
                fpanCardDescriptor =	fpanCardDescriptor + " " + bcUnencryptedData[i] + " \n";
            }
            fpanCardDescriptor = 	fpanCardDescriptor + "                \"encryptedData\" : \"" + bcEncryptedData[i] + "\"";
            if (!inPkcs7Signature[i].isEmpty()) {
                fpanCardDescriptor = fpanCardDescriptor + ",\n                \"pkcs7Signature\" : \"" + inPkcs7Signature[i] + "\"";
            }
            fpanCardDescriptor = 	fpanCardDescriptor + "\n }, ";

            bcFpanCardDescriptor[i]=fpanCardDescriptor;

        }
    }
    public void setRequestArray()
    {
        bcNetworkCheckCardRequest=new String[inArrayCnt];
        for (int i = 0; i <inArrayCnt ; i++) {
            String json = "        {\n            " + bcFpanCardDescriptor[i];
            if (!bcSsdDescriptor[i].isEmpty()) {
                json = json + "\n            " + bcSsdDescriptor[i] + "\n";
            }

            json = json + "            \"cardIdentifier\" : \"" + inCardIdentifier[i] + "\",\n";
            json = json + "            \"fpanSource\" : \"" + inFpanSource[i] + "\",\n";
            //May be modification required here
            if (inDeviceType[i]!=0)
            {
                json = json + "            \"deviceType\" : \"" + inDeviceType[i] + "\",\n";
            }
            json = json + "            \"deviceAcceptLanguage\" : \"" + inDeviceAcceptLanguage[i] + "\"\n";
            json = json + "        }";

            if (i < inArrayCnt-1) {
                json = json + ",";
            }
            else {
                json = json + "";
            }

            bcNetworkCheckCardRequest[i]=json;
        }
    }
    private void setHttpHeaderXpod()
    {
        if (inHttpHdrXpod.equalsIgnoreCase("NOT-PRESENT")) {
            LogHandler.print(" tcHttpHdrXpod = [" + inHttpHdrXpod + "] ... so not inserting [X-Pod] http header");
        }
        else {
            LogHandler.print(" tcHttpHdrXpod = [" + inHttpHdrXpod + "] ... so inserting [X-Pod] http header");
            outHttpHdrXPod=inHttpHdrXpod;
        }
    }

    //************************************* End of all general Methods ***************************
    //************************************ GET RESPONSE CALL METHODS *****************************

    private void getSysDateBefore()
    {
        Map<String,String > timeMap=DateUtils.getSysDate();
        outDttmBefore=timeMap.get("SYSDATETIME");
        outDttmMsBefore=timeMap.get("SYSTIMEDATETIMEMS");
    }

    private void delay() throws InterruptedException {
        Thread.currentThread().sleep(1200);
    }

    private void getSysDateAfter()
    {
        Map<String,String > timeMap=DateUtils.getSysDate();
        outDttmAfter=timeMap.get("SYSDATETIME");
        outDttmMsAfter=timeMap.get("SYSTIMEDATETIMEMS");
    }
    private void getHttpStatusCode() throws Exception {
//        String seid="1404250BE62780014200075520931290BB08825050BD5498";
        RestAssured.baseURI=PropertyHandler.getBaseUrl()+"/devices/";
        String bodyString="";
        for (int i = 0; i < inArrayCnt; i++) {
            bodyString=bcNetworkCheckCardRequest[i]+" ";
        }
        inSeid=inSeid.isEmpty()?"/":inSeid+"/";
        outEndpoint=RestAssured.baseURI+inSeid+"networkCheckCard";

        LogHandler.print("End Point : "+outEndpoint);
        String requestBody = "{\n" +
                "    \"requestHeader\" : {\n" +
                "        \"requestId\" : \""+inRequestId+"\",\n" +
                "        \"conversationId\" : \""+inConversationId+"\"\n" +
                "    },\n" +
                "    \"networkCheckCardRequest\": \n" +
                "    [\n" +
                bodyString+
                "    ]\n" +
                "}\n" +
                "\n";

        LogHandler.prettyPrintRequest(requestBody);
        Map jsonMap=new com.fasterxml.jackson.databind.ObjectMapper().readValue(requestBody, HashMap.class);

        JsonObjectMapper.writeMapAsJson(JsonObjectMapper.evaluateMapForKeywords(jsonMap));
        //****************Setting header
        Response response =    given()
                .headers("Content-Type", "application/json",
                        "X-Pod", outHttpHdrXPod,
                        "Authorization",prWspId_103
                )
                .body(requestBody)
                .when()
                .post(outEndpoint);

        LogHandler.prettyPrintResponse(response);

        LogHandler.printTestFinishedHeader();
        outHttpStatusCode=response.getStatusCode();
        outRspHttpHeaders=new LinkedHashMap<>();
        for (Header header:response.getHeaders()) {
            outRspHttpHeaders.put(header.getName(),header.getValue());
        }

        outReqJson = requestBody.replaceAll("[\n\r]", "");
        outRspJson = response.asString().replaceAll("[\n\r]", "");
        // get SUID
        String suid = response.getHeader("System-Unique-Id");
        outSuid = suid.replaceAll("\\[","").replaceAll("\\]","");
//extract ENDPOINT:

    }

    private void getReqTags()
    {
        outReqWrappedKey=new String[inArrayCnt];
        outReqPublicKeyFingerPrint=new String[inArrayCnt];
        outReqAsymmetricAlgorithmIdentifier=new String[inArrayCnt];
        outReqSymmetricAlgorithmIdentifier=new String[inArrayCnt];
        outReqEncryptedData=new String[inArrayCnt];
        outReqEncryptedData=new String[inArrayCnt];
        outReqCardIdentifier=new String[inArrayCnt];
        outReqDeviceType=new int[inArrayCnt];
        outReqAppletInstanceAid=new String[inArrayCnt];
        outReqAppletVersionNumber=new String[inArrayCnt];

        outReqHdrRequestId=inRequestId;
        outReqHdrConversationId=inConversationId;
        for (int i = 0; i <inArrayCnt ; i++) {

            outReqWrappedKey[i] = bcWrappedKey[i];
            outReqPublicKeyFingerPrint[i] = bcPublicKeyFingerprint[i];
            outReqAsymmetricAlgorithmIdentifier[i] = bcAsymmetricAlgorithmIdentifier[i];
            outReqSymmetricAlgorithmIdentifier[i] = bcSymmetricAlgorithmIdentifier[i];
            outReqEncryptedData[i] = bcEncryptedData[i];
            outReqCardIdentifier[i] = inCardIdentifier[i];
            outReqDeviceType[i] = inDeviceType[i];
            JsonPath jp = new JsonPath(outReqJson);
            if(!bcSsdDescriptor[i].isEmpty()) {
                outReqAppletInstanceAid[i] = with(outReqJson).get("networkCheckCardRequest.ssdDescriptor[" + i + "].appletInstanceAid");
                outReqAppletVersionNumber[i] = with(outReqJson).get("networkCheckCardRequest.ssdDescriptor[" + i + "].appletVersionNumber");
            }
        }

    }
    private void getRspTags()
    {
        outRspStatusCode=new String[inArrayCnt];
        outRspStatusMessage=new String[inArrayCnt];
        outRspNetworkSubStatusCode=new String[inArrayCnt];
        outRspProductType=new String[inArrayCnt];
        outRspIssuerAppStoreIdentifier=new String[inArrayCnt];
        outRspTokenValue=new String[inArrayCnt];
        outRspTokenTTLInMinutes=new int[inArrayCnt];
        outRspCardHomeCountry=new String[inArrayCnt];
        outRspCardArtManifest=new List[inArrayCnt];
        outRspCardIdentifier=new String[inArrayCnt];
        outRspCardIdentifier=new String[inArrayCnt];
        outRspCardIssuer=new String[inArrayCnt];

        if(outRspJson.isEmpty() || outRspJson.equals(null))
        {
            LogHandler.print("rspJson is empty so bypassing this teststep ...");
            return;
        }

        String rspHeader=with(outRspJson).get("responseHeader").toString();
        if(rspHeader.isEmpty())
        {
            LogHandler.print(" rspJson is null so bypassing this teststep ...");
            return;
        }
        String conversationId=with(outRspJson).get("responseHeader.conversationId");
        outRspHdrConversationId=conversationId!=null?conversationId:"";
        String responseId=with(outRspJson).get("responseHeader.responseId");
        outRspHdrResponseId=responseId!=null?responseId:"";
        String statusCode=with(outRspJson).get("responseHeader.statusCode");
        outRspHdrStatusCode=statusCode!=null?statusCode:"";
        String statusMessage=with(outRspJson).get("responseHeader.statusMessage");
        outRspHdrStatusMessage=statusMessage!=null?statusMessage:"";

        for (int i = 0; i < inArrayCnt; i++) {
             statusCode=with(outRspJson).get("networkCheckCardResponse.statusCode["+i+"]");
            outRspStatusCode[i]=statusCode!=null?statusCode:"";

             statusMessage=with(outRspJson).get("networkCheckCardResponse.statusMessage["+i+"]");
            outRspStatusMessage[i]=statusMessage!=null?statusMessage:"";

            String subStatusCode=with(outRspJson).get("networkCheckCardResponse.networkSubStatusCode["+i+"]");
            outRspNetworkSubStatusCode[i]=subStatusCode!=null?subStatusCode:"";

            String productType=with(outRspJson).get("networkCheckCardResponse.productType["+i+"]");
            outRspProductType[i]=productType!=null?productType:"";

            String issuerAppStoreIdentifier=with(outRspJson).get("networkCheckCardResponse.issuerAppStoreIdentifier["+i+"]");
            outRspIssuerAppStoreIdentifier[i]=issuerAppStoreIdentifier!=null?issuerAppStoreIdentifier:"";

            String tokenValue=with(outRspJson).get("networkCheckCardResponse.nextStepToken.tokenValue["+i+"]");
            outRspTokenValue[i]=tokenValue!=null?tokenValue:"";

            Integer tokenTTLInMinutes=with(outRspJson).get("networkCheckCardResponse.nextStepToken.tokenTTLInMinutes["+i+"]");
            outRspTokenTTLInMinutes[i]=tokenTTLInMinutes!=null?tokenTTLInMinutes:-1;

            String cardHomeCountry=with(outRspJson).get("networkCheckCardResponse.cardHomeCountry["+i+"]");
            outRspCardHomeCountry[i]=cardHomeCountry!=null?cardHomeCountry:"";

            List cardArtManifest=with(outRspJson).get("networkCheckCardResponse.cardArtManifest["+i+"]");
            outRspCardArtManifest[i]=cardArtManifest!=null?cardArtManifest:null;

            String cardIdentifier=with(outRspJson).get("networkCheckCardResponse.cardIdentifier["+i+"]");
            outRspCardIdentifier[i]=cardIdentifier!=null?cardIdentifier:"";

            String cardIssuer=with(outRspJson).get("networkCheckCardResponse.cardIssuer["+i+"]");
            outRspCardIssuer[i]=cardIssuer!=null?cardIssuer:"";


        }

    }
    private void getDBkeyIds()
    {
        outPrvsnRqstId=new String[inArrayCnt];
        outMapId=new String[inArrayCnt];
        outPanDataEncId=new String[inArrayCnt];
        outPAID=new String[inArrayCnt];
        outWltPrvdrId=new String[inArrayCnt];
        outTRID=new String[inArrayCnt];

        for (int i = 0; i < inArrayCnt; i++) {
            outPrvsnRqstId[i]="";
            outMapId[i] ="";
            outPanDataEncId[i] ="";
            outPAID[i] ="";
            outWltPrvdrId[i] ="";
            outTRID[i] ="";
            if(!outRspStatusCode[i].equalsIgnoreCase("200"))
            {
                LogHandler.print(" 'outRspStatusCode' = [" + outRspStatusCode[i] + "] ... bypassing call to 'Database.GetKeysIds' ...");
                continue;
            }
            if(outRspTokenValue[i].isEmpty() || outRspTokenValue[i].equalsIgnoreCase("null"))
            {
                LogHandler.print(" 'outRspTokenValue' = [" + outRspTokenValue[i] + "] ... bypassing 'Database.GetKeysIds' ...");
                continue;
            }
            Map<Integer, Map> dataMap=DBLookUpUtils.getKeyIds("TKNID",outRspTokenValue[i]);
            if(dataMap.size()>0) {
                Map<String, String> resultMap = dataMap.get(1);
                outPrvsnRqstId[i] = resultMap.get("tcxPrvsnRqstId");
                outMapId[i] = resultMap.get("tcxMapId");
                outPanDataEncId[i] = resultMap.get("tcxPanDataEncId");
                outPAID[i] = resultMap.get("tcxPaymtApplInstnceId");
                outWltPrvdrId[i] = resultMap.get("tcxWltPrvdrId");
                outTRID[i] = resultMap.get("tcxTokenRqstrId");
            }
        }
    }
    private void getFpanHash() {
        outHash=new String[inArrayCnt];
        for (int i = 0; i < inArrayCnt; i++) {


            if (!bcFpanKey[i].equalsIgnoreCase("BYFPANEXP")) {
                LogHandler.print(" 'bcFpanKey' = [" + bcFpanKey[i] + "] ... bypassing call to 'Mdes-Caas.hash' ...");
                continue;
            }
            //execute the external tesinase to get hash value ... and load its output properties into
            //this tesinase's output properties:
            outHash[i] = MDESUtilities.hash(inFpan[i]);
        }
    }
    private void getDecryptedDpan()
    {
        outEncryptPanDataDecrypted=new String[inArrayCnt];
        outDpan=new String[inArrayCnt];
        for (int i = 0; i < inArrayCnt; i++) {
            outDpan[i]="";

            if (outPanDataEncId[i].isEmpty()) {
                LogHandler.print(" 'bcFpanKey' = [" + bcFpanKey[i] + "] ... bypassing call to 'Mdes-Caas.hash' ...");
                continue;
            }
            Map<String,String> resultMap=DBLookUpUtils.getEncryptedPanDataCol(outPanDataEncId[i]);
            //execute the external tesinase to get hash value ... and load its output properties into
            //this tesinase's output properties:
            outEncryptPanDataDecrypted[i]=resultMap.get("tcxEncryptPanData");
            outDpan[i]=outEncryptPanDataDecrypted[i];
        }
    }

    private void getDpanHash() {
        for (int i = 0; i < inArrayCnt; i++) {


            if (!bcFpanKey[i].equalsIgnoreCase("BYFPANEXP")) {
                LogHandler.print(" 'bcFpanKey' = [" + bcFpanKey[i] + "] ... bypassing call to 'Mdes-Caas.hash' ...");
                continue;
            }
            //execute the external tesinase to get hash value ... and load its output properties into
            //this tesinase's output properties:
            if(outDpan==null || outDpan[i].isEmpty())
                continue;
            outHash[i] = MDESUtilities.hash(outDpan[i]);
        }
    }

    //************************************ END OF RESPONSE CALL METHODS **************************
    
    //************************************ ALL RESPONSE GETTERS **********************************

    public String getOutRspHdrStatusMessage() {
        return outRspHdrStatusMessage;
    }

    public String getOutRspHdrStatusCode() {
        return outRspHdrStatusCode;
    }

    public String getOutRspHdrResponseId() {
        return outRspHdrResponseId;
    }

    public String getOutRspHdrConversationId() {
        return outRspHdrConversationId;
    }

    public String getOutHttpHdrXPod() {
        return outHttpHdrXPod;
    }

    public String getOutDttmMsAfter() {
        return outDttmMsAfter;
    }

    public String getOutDttmAfter() {
        return outDttmAfter;
    }

    public String getOutDttmBefore() {
        return outDttmBefore;
    }

    public String getOutDttmMsBefore() {
        return outDttmMsBefore;
    }

    public String[] getOutRspCardIssuer() {
        return outRspCardIssuer;
    }

    public List<String>[] getOutRspCardArtManifest() {
        return outRspCardArtManifest;
    }

    public String[] getOutRspCardIdentifier() {
        return outRspCardIdentifier;
    }

    public String[] getOutRspCardHomeCountry() {
        return outRspCardHomeCountry;
    }

    public int[] getOutRspTokenTTLInMinutes() {
        return outRspTokenTTLInMinutes;
    }

    public String[] getOutRspIssuerAppStoreIdentifier() {
        return outRspIssuerAppStoreIdentifier;
    }

    public String[] getOutRspProductType() {
        return outRspProductType;
    }

    public String[] getOutRspNetworkSubStatusCode() {
        return outRspNetworkSubStatusCode;
    }

    public String[] getOutEncryptPanDataDecrypted() {
        return outEncryptPanDataDecrypted;
    }

    public String[] getOutRspStatusMessage() {
        return outRspStatusMessage;
    }

    public String[] getOutHash() {
        return outHash;
    }

    public String[] getOutWltPrvdrId() {
        return outWltPrvdrId;
    }

    public String[] getOutPAID() {
        return outPAID;
    }

    public String[] getOutPanDataEncId() {
        return outPanDataEncId;
    }

    public String[] getOutMapId() {
        return outMapId;
    }

    public String[] getOutPrvsnRqstId() {
        return outPrvsnRqstId;
    }

    public String[] getOutTRID() {
        return outTRID;
    }

    public String[] getOutDpan() {
        return outDpan;
    }

    public String[] getOutRspTokenValue() {
        return outRspTokenValue;
    }

    public String[] getOutRspStatusCode() {
        return outRspStatusCode;
    }

    public String getOutSuid() {
        return outSuid;
    }

    public String[] getOutReqAppletVersionNumber() {
        return outReqAppletVersionNumber;
    }

    public String[] getOutReqAppletInstanceAid() {
        return outReqAppletInstanceAid;
    }

    public int[] getOutReqDeviceType() {
        return outReqDeviceType;
    }

    public String[] getOutReqCardIdentifier() {
        return outReqCardIdentifier;
    }

    public String[] getOutReqEncryptedData() {
        return outReqEncryptedData;
    }

    public String[] getOutReqSymmetricAlgorithmIdentifier() {
        return outReqSymmetricAlgorithmIdentifier;
    }

    public String[] getOutReqAsymmetricAlgorithmIdentifier() {
        return outReqAsymmetricAlgorithmIdentifier;
    }

    public String[] getOutReqPublicKeyFingerPrint() {
        return outReqPublicKeyFingerPrint;
    }

    public String[] getOutReqWrappedKey() {
        return outReqWrappedKey;
    }

    public String getOutReqHdrConversationId() {
        return outReqHdrConversationId;
    }

    public String getOutReqHdrRequestId() {
        return outReqHdrRequestId;
    }

    public String getOutEndpoint() {
        return outEndpoint;
    }

    public String getOutRspJson() {
        return outRspJson;
    }

    public String getOutReqJson() {
        return outReqJson;
    }

    public Map<String, String> getOutRspHttpHeaders() {
        return outRspHttpHeaders;
    }

    public int getOutHttpStatusCode() {
        return outHttpStatusCode;
    }

    public String[] getOutJsonThatWasEncrypted() {
        return outJsonThatWasEncrypted;
    }

    public String[] getOutWrappedKey() {
        return outWrappedKey;
    }

    public String[] getOutSymmetricAlgorithmIdentifier() {
        return outSymmetricAlgorithmIdentifier;
    }

    public String[] getOutPublicKeyFingerPrint() {
        return outPublicKeyFingerPrint;
    }

    public String[] getOutEncryptedData() {
        return outEncryptedData;
    }

    public String[] getOutAsymmetricAlgorithmIdentifier() {
        return outAsymmetricAlgorithmIdentifier;
    }

    //************************************ END RESPONSE GETTERS **********************************

}
