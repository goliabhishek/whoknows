package com.mastercard.mdes.test.automation.core.request_builder.dpan.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mastercard.mdes.test.automation.core.TestUtils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by E055238 on 3/4/2016.
 */
public class ConfigureRequest {

    private String fpanRange;
    private String dpanCount;
    private String minimumPools;
    private String suid;

    public ConfigureRequest fpanRange (String fpanRange) {
        this.fpanRange = fpanRange;
        return this;
    }

    public ConfigureRequest dpanCount (String dpanCount) {
        this.dpanCount = dpanCount;
        return this;
    }

    public ConfigureRequest minimumPools (String minimumPools) {
        this.minimumPools = minimumPools;
        return this;
    }

    public ConfigureRequest suid (String suid) {
        this.suid = suid;
        return this;
    }

    public ConfigureRequest allDefaults() {
        fpanRange = null;
        dpanCount = "5" ;
        minimumPools = "1";
        suid = TestUtils.generateRequestId();
        return this;
    }

    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("fpanRange", fpanRange);
        jsonObject.put("dpanCount", dpanCount);
        jsonObject.put("minimumPools", minimumPools);
        jsonObject.put("suid", suid);

        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }

}
