package com.mastercard.mdes.test.automation.core.comparison_tool_new;

import com.mastercard.mdes.test.automation.core.LogHandler;
import org.apache.commons.lang.StringUtils;
import org.easetech.easytest.loader.ExcelDataLoader;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

/**
 * Created by e055238 on 2/29/2016.
 */
public class ExcelHandler {

    public static Map<String, Object> generateRecordMapFromExcel(Map<String, List<Map<String, Object>>> fullDataMap, String inTestNbr) throws Exception{
        LinkedHashMap<String, Object> recordMap = (LinkedHashMap<String, Object>) fullDataMap.get("testExampleDataDrivenMethod").get(Integer.parseInt(inTestNbr)-1);
        return recordMap;
    }

    public static Map generateFullRecordMapFromExcel(String datasourcePath) throws IOException {
        FileInputStream file = new FileInputStream(datasourcePath);
        ExcelDataLoader dataLoader = new ExcelDataLoader(file);

        Map<String, List<Map<String, Object>>> fullDataMap = dataLoader.getData();
        file.close();
        return fullDataMap;
    }
}
