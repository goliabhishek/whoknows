package com.mastercard.mdes.test.automation.core.request_builder.tokenization_api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mastercard.mdes.test.automation.core.TestUtils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by John Kalbac e055238 on 1/22/2016.
 */

public class GetStatusRequest {

    private String requestId;
    private String tokenUniqueReference;

    public GetStatusRequest requestId(String requestId) {
        this.requestId = requestId;
        return this;
    }

    public GetStatusRequest tokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
        return this;
    }

    public GetStatusRequest allDefaults() {
        requestId = TestUtils.generateRequestId();
        tokenUniqueReference = "12345";
        return this;
    }


    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("requestId", requestId);
        jsonObject.put("tokenUniqueReference", tokenUniqueReference);

        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }

}