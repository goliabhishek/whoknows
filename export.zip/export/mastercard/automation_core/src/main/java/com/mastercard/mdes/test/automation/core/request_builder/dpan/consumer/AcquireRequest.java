package com.mastercard.mdes.test.automation.core.request_builder.dpan.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by E029380 on 3/4/2016.
 */
public class AcquireRequest {

    private String fpanRange;
    private String tokenServiceCode;

    public AcquireRequest fpanRange (String fpanRange) {
        this.fpanRange = fpanRange;
        return this;
    }

    public AcquireRequest tokenServiceCode (String tokenServiceCode) {
        this.tokenServiceCode = tokenServiceCode;
        return this;
    }

    public AcquireRequest allDefaults() {
        fpanRange = null;
        tokenServiceCode = "DEVICE";
        return this;
    }

    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("fpanRange", fpanRange);
        jsonObject.put("tokenServiceCode",tokenServiceCode);

        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }

}
