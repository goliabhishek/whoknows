package com.mastercard.mdes.test.automation.core.request_builder.dpan.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by E055238 on 3/4/2016.
 */
public class ConfirmRequest {

    private String fpanRange;
    private String dpan;
    private String dpanRange;
    private String tokenServiceCode;

    public ConfirmRequest fpanRange (String fpanRange) {
        this.fpanRange = fpanRange;
        return this;
    }

    public ConfirmRequest dpan (String dpan) {
        this.dpan = dpan;
        return this;
    }

    public ConfirmRequest dpanRange (String dpanRange) {
        this.dpanRange = dpanRange;
        return this;
    }

    public ConfirmRequest tokenServiceCode (String tokenServiceCode) {
        this.tokenServiceCode = tokenServiceCode;
        return this;
    }

    public ConfirmRequest allDefaults() {
        fpanRange = null;
        dpan = null;
        dpanRange = null;
        tokenServiceCode = null;
        return this;
    }

    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("fpanRange", fpanRange);
        jsonObject.put("dpan", dpan);
        jsonObject.put("dpanRange",dpanRange);
        jsonObject.put("tokenServiceCode",tokenServiceCode);

        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }

    }
