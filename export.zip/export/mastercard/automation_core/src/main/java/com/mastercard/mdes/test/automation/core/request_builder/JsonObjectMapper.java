package com.mastercard.mdes.test.automation.core.request_builder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.util.Iterator;
import java.util.Map;

/**
 * Created by E055238 on 3/30/2016.
 */
public class JsonObjectMapper {


    /**
     *  Method that iterates the jsonObject map and replaces values based on keywords
     */
    public static Map<String, Object> evaluateMapForKeywords(Map jsonObject) {

        Iterator it = jsonObject.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();

            // Break if a null value is encountered, which is valid
            if (pair.getValue() == null) {
                break;
            }

            if (pair.getValue().toString().equalsIgnoreCase("NOT-PRESENT")) {
                it.remove();
            } else if (pair.getValue().toString().equalsIgnoreCase("NULL")) {
                pair.setValue(null);
            }
        }

        return jsonObject;
    }


    /**
     *  Object Mapper used to build the JSON string
     */
    public static String writeMapAsJson(Map jsonObject) {
        try {
            return new com.fasterxml.jackson.databind.ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, true)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }

    public static String writeMapAsJson(Map jsonObject, Boolean writeNullMapValuesBool) {
        try {
            return new com.fasterxml.jackson.databind.ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, writeNullMapValuesBool)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }


}
