package com.mastercard.mdes.test.automation.core;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by e062684 on 3/4/2016.
 */
public class DateUtils {

    public enum TS_FORMAT{
        YYYYMMDDHH24MISS("YYYY/MM/DD HH24:MI:SS"),
        YYYYMMDDDD("YYYY/MM/DD"),
        HH24MISS("HH24:MI:SS"),
        HH24MISSFF3("HH24:MI:SS:FF3");

        private final String stringValue;
        private TS_FORMAT(final String s) { stringValue = s; }
        public String toString() { return stringValue; }



    }

    public static String getDbTimestamp(TS_FORMAT ts_format) throws Exception {


        String sqlSysdate="SYSDATE + INTERVAL '0' day";
        String sqlSystimestamp="SYSTIMESTAMP + INTERVAL '0' day";
        Statement statement = null;
        Connection con = null;
        String finalTimeStamp="";
        try {
            con = DatabaseHandler.getDbConnection();
            String sqlQuery="SELECT " +
                    "TO_CHAR(" + sqlSysdate + ", '"+ TS_FORMAT.YYYYMMDDHH24MISS.toString()+"') \"SYSDATETIME\", " +
                    "TO_CHAR(" + sqlSysdate + ", '"+ TS_FORMAT.YYYYMMDDDD.toString()+"') \"SYSDATE\", " +
                    "TO_CHAR(" + sqlSysdate + ", '"+ TS_FORMAT.HH24MISS.toString()+"') \"SYSTIME\", " +
                    "TO_CHAR(" + sqlSystimestamp + ", '"+ TS_FORMAT.HH24MISSFF3.toString()+"') \"SYSTIME2\" " +
                    "FROM DUAL";

            statement=con.createStatement();
            ResultSet results = statement.executeQuery(sqlQuery);


            while (results.next()) {
                switch (ts_format)
                {
                    case YYYYMMDDHH24MISS: finalTimeStamp=results.getString("SYSDATETIME");
                        break;
                    case YYYYMMDDDD:finalTimeStamp=results.getString("SYSDATE");
                        break;
                    case HH24MISS: finalTimeStamp=results.getString("SYSTIME");
                        break;
                    case HH24MISSFF3:finalTimeStamp=results.getString("SYSTIME2");
                        break;
                }
            }


        } finally {
            statement.close();
            con.close();
        }
        return finalTimeStamp;
    }

    public static Map<String , String> getAdjustedDate(String tcDttmToAdjust,String tcIntervalDirection,String tcIntervalValue,String tcIntervalType)
    {

        String sqlSysdate="SYSDATE + INTERVAL '0' day";
        String sqlSystimestamp="SYSTIMESTAMP + INTERVAL '0' day";
        Statement statement = null;
        Connection con = null;
        String finalTimeStamp="";
        Map<String , String> resultMap= new LinkedHashMap<>();
        try {
            con = DatabaseHandler.getDbConnection();
            String sqlQuery = "SELECT " +
                    "TO_CHAR(TO_DATE('" + tcDttmToAdjust + "', 'YYYY/MM/DD HH24;MI:SS') " +
                    tcIntervalDirection + " INTERVAL '" + tcIntervalValue + "' " + tcIntervalType + ", 'YYYY/MM/DD HH24:MI:SS') \"ADJUSTEDDTTM\" " +
                    "FROM DUAL";

            statement = con.createStatement();
            ResultSet results = statement.executeQuery(sqlQuery);

            while (results.next())
            {
                resultMap.put("tcxAdjustedDttm",results.getString("ADJUSTEDDTTM"));
                resultMap.put("tcxAdjustedDttmMs",results.getString("ADJUSTEDDTTM")+".000");
            }
            statement.close();
            results.close();
        }catch (Exception e)
        {e.printStackTrace();}
        return resultMap;

    }

    public static Map<String,String> getSysDate()
    {
        Map<String,String> timeMap=new HashMap<>();
        String sqlSysdate="SYSDATE + INTERVAL '0' day";
        String sqlSystimestamp="SYSTIMESTAMP + INTERVAL '0' day";
        Statement statement = null;
        Connection con = null;
        String finalTimeStamp="";
        try {
            con = DatabaseHandler.getDbConnection();
            String sqlQuery="SELECT " +
                    "TO_CHAR(" + sqlSysdate + ", '"+ TS_FORMAT.YYYYMMDDHH24MISS.toString()+"') \"SYSDATETIME\", " +
                    "TO_CHAR(" + sqlSysdate + ", '"+ TS_FORMAT.YYYYMMDDDD.toString()+"') \"SYSDATE\", " +
                    "TO_CHAR(" + sqlSysdate + ", '"+ TS_FORMAT.HH24MISS.toString()+"') \"SYSTIME\", " +
                    "TO_CHAR(" + sqlSystimestamp + ", '"+ TS_FORMAT.HH24MISSFF3.toString()+"') \"SYSTIME2\" " +
                    "FROM DUAL";

            statement=con.createStatement();
            ResultSet results = statement.executeQuery(sqlQuery);


            while (results.next()) {
                timeMap.put("SYSDATETIME", results.getString("SYSDATETIME"));
                timeMap.put("SYSDATE", results.getString("SYSDATE"));
                timeMap.put("SYSTIME", results.getString("SYSTIME"));
                timeMap.put("SYSTIMEMS", results.getString("SYSTIME2"));
                timeMap.put("SYSTIMEDATETIMEMS", results.getString("SYSDATE") + " " + results.getString("SYSTIME2"));

            }
            results.close();

        }catch (Exception e)
        {
            e.printStackTrace();
        }
         finally {
            try {
                statement.close();
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return timeMap;

    }
}
