/*
package com.mastercard.mdes.test.automation.core.request_builder.Mcbp;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.mastercard.mdes.test.automation.core.DataBaseReset.DatabaseResetUtils;
import com.mastercard.mdes.test.automation.core.LogHandler;
import com.mastercard.mdes.test.automation.core.PropertyHandler;
import com.mastercard.mdes.test.automation.core.TestUtils;
import com.mastercard.mdes.test.automation.core.mdes_utilities.CaasServiceUtil;
import com.mastercard.mdes.test.automation.core.mdes_utilities.MDESUtilities;
import junit.framework.Assert;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;


import static com.jayway.restassured.RestAssured.given;
import static junit.framework.TestCase.assertTrue;

*/
/**
 * Created by e062683 on 3/23/2016.
 *//*

public class CheckEligibilityUtils {

    private String inCardAccountNumber;
    private String inCardCardholderName;
    private String inCardDataValidUntilTimestamp;
    private String inCardEncryptedData;
    private String inCardExpiryDate;
    private String inCardInfo;
    private String inCardInfoObject;
    private String inCardletId;
    private String inCardOaepHashingAlgorithm;
    private String inCardPanUniqueReference;
    private String inCardSource;
    private String inCardUnencryptedData;
    private String inConsumerLanguage;
    private String inDbReset;
    private String inDeviceApplCertHash;
    private String inDeviceImei;
    private String inDeviceInfo;
    private String inDeviceMsisdn;
    private String inDeviceName;
    private String inDeviceNfcCapable;
    private String inDeviceOsName;
    private String inDeviceOsVersion;
    private String inDeviceSerialNumber;
    private String inDeviceTokenStorageType;
    private String inDeviceType;
    private String inForceDecryptionFailure;
    private String inPaymentAppId;
    private String inPaymentAppInstanceId;
    private String inRequestId;
    private String inResponseHost;
    private String inSeCapabilities;
    private String inSeid;
    private String inSeInfo;
    private String inSpsdAid;
    private String inSpsdAppletInstanceAid;
    private String inSpsdCasdPkCertificate;
    private String inSpsdCasdPkJwk;
    private String inSpsdInfo;
    private String inSpsdRgk;
    private String inSpsdSemsPkCertificate;
    private String inSpsdSequenceCounter;
    private String inStorageTechnology;
    private String inTokenType;
    private String inWalletIdFlag;
    private String inWspId;

    */
/*<-----------------------------------Output------------------------------------------->*//*


    private String outAccountNumberHash;
    private String outCardInfoThatWasEncrypted;
    private String outDbDvcId;
    private String outDbMapId;
    private String outDbPAID;
    private String outDbPanDataEncId;
    private String outDbPrvsnRqstId;
    private String outDbWltPrvdrId;
    private String outDpan;
    private String outDpanHash;
    private String outDttmAfter;
    private String outDttmBefore;
    private String outDttmMsAfter;
    private String outDttmMsBefore;
    private String outReqCardCertificateFingerprint;
    private String outReqCardUnencryptedDataValidUntilTimestamp;
    private String outReqCardEncryptedData;
    private String outReqCardEncryptedKey;
    private String outReqCardInfo;
    private String outReqCardlet;
    private String outReqCardOaepHashingAlgorithm;
    private String outReqCardPanUniqueReference;
    private String outReqCardUnencryptedAccountNumber;
    private String outReqCardUnencryptedCardholderName;
    private String outReqCardUnencryptedData;
    private String outReqCardUnencryptedExpiryMonth;
    private String outReqCardUnencryptedExpiryYear;
    private String outReqCardUnencryptedSource;
    private String outReqConsumerLanguage;
    private String outReqDeviceApplCertHash;
    private String outReqDeviceImei;
    private String outReqDeviceInfo;
    private String outReqDeviceMsisdn;
    private String outReqDeviceName;
    private String outReqDeviceNfcCapable;
    private String outReqDeviceOsName;
    private String outReqDeviceOsVersion;
    private String outReqDeviceSerialNumber;
    private String outReqDeviceType;
    private String outReqHttpHeaders;
    private String outReqJson;
    private String outReqPaymentAppId;
    private String outReqRequestId;
    private String outReqResponseHost;
    private String outReqSeCapabilities;
    private String outReqSeId;
    private String outReqSeInfo;
    private String outReqSpsdAid;
    private String outReqSpsdAppletInstanceAid;
    private String outReqSpsdCasdPkCertificate;
    private String outReqSpsdInfo;
    private String outReqSpsdRgk;
    private String outReqSpsdSequenceCounter;
    private String outReqTokenType;
    private String outReqUrl;
    private String outRspApplicableCardInfo;
    private String outRspdeviceNotEligibleReasonsArray;
    private String outRspDeviceNotEligibleReasonArrayCnt;
    private String outRspDeviceNotEligibleReasons;
    private String outRspEligReceipt;
    private String outRspEligReceiptValidForMin;
    private String outRspEligReceiptValue;
    private String outRspErrorCode;
    private String outRspErrorDescription;
    private String outRspHttpHeaders;
    private String outRspHttpStatusCode;
    private String outRspIsSecurityCodeApplicable;
    private String outRspJson;
    private String outRspResponseHost;
    private String outRspResponseId;
    private String outRspSuid;
    private String outRspTermsAndCondAssetId;



    public CheckEligibilityUtils()
    {
        //All the defaults get initialized
        //this.tcArrayCnt=1;
        setInAllDefaults();
        //refer setTcArrayCnt(int tcArrayCnt)
        //if the user wants to change the tcArrayCnt
        //by setter method setInAllDefaults(); will be called and
        //all the values get reset
    }
    private void setInAllDefaults()
    {
        // All values are set as per DEV-TEST environment
        this.tcConversationId=(UUID.randomUUID().toString() + "=" + UUID.randomUUID().toString()).substring(1,64);
        this.tcDbReset="Y";
        */
/*inHttpHdrXpod="Test Harness";
        inRptHttpHeaders="N";
        *//*

        inCardCardholderName="Joe Cloud";
        inCardEncryptedData="PRESENT";
        inCardInfo="PRESENT";
        inCardInfoObject="GENERATE";
        inCardOaepHashingAlgorithm="SHA256";
        inCardPanUniqueReference="NOT-PRESENT";
        inCardSource="CARD_ON_FILE";
        inCardUnencryptedData="NOT-PRESENT";
        inConsumerLanguage="en";
        inDbReset="Y";
        inDeviceApplCertHash="4DEAE10A1E4903A270DBE0BD";
        inDeviceInfo="PRESENT";
        inDeviceName="Joe's Phone";
        inDeviceNfcCapable="true";
        inDeviceOsName="ANDROID";
        inDeviceOsVersion="5.9";
        inDeviceTokenStorageType="NOT-PRESENT";
        inDeviceType="PHONE";
        inForceDecryptionFailure="N";
        inResponseHost="PRESENT";
        inSeCapabilities="NOT-PRESENT";
        inSpsdCasdPkCertificate="PRESENT";
        inSpsdCasdPkJwk="NOT-PRESENT";
        inSpsdSemsPkCertificate="NOT-PRESENT";
        inStorageTechnology="NOT-PRESENT";
        inTokenType="CLOUD";
        inWalletIdFlag="NOT-PRESENT";
        inCardDataValidUntilTimestamp="NOT-PRESENT";







    }


*/
/*---------------------------------------General Methods---------------------------------------*//*


    private void runDBReset() {
    }

    private void encryptCardObject() {

        LogHandler.print(" starting:");

//at this point ... "tcCardInfoObject" will contain the data to encrypt ... whether the caller
//passed in the data directly or this common testcase generated it.
//Example json:
//  {
//     "accountNumber":"5155000000004601",
//     "expiryMonth":"11",
//     "expiryYear":"17",
//     "source":"ON_FILE",
//     "cardholderName":"Sammy Snorks"
//  }


        //tweak the 'tcCardOaepHashingAlgorithm' property ... convert "NOT-PRESENT" to "NONE" if required
        String oaepHashingAlgorithm = inCardOaepHashingAlgorithm;
        if (oaepHashingAlgorithm == "NOT-PRESENT") {
            oaepHashingAlgorithm = "NONE";
        }


        //call common testcase:
        String extTestCaseId = "mdesExternalApiCommon.Crypto.wrappedMcbpEncrypt"
        RunExternalTestCase extTestCase = new RunExternalTestCase(log, context, testRunner, extTestCaseId)
        extTestCase.runWithTcDefaults(
                "tcJson:" + testRunner.testCase.getPropertyValue("tcCardInfoObject"),
                "tcOaepHashingAlgorithm:" + oaepHashingAlgorithm,
                //OUTPUTS:
                "tcxEncryptedData:" + "TC.tcCardEncryptedData",
                "tcxEncryptedKey:" + "PTS.scratchpad.cryptoEncryptedKey",
                "tcxCertificateAlias:" + "PTS.scratchpad.cryptoCertificateFingerprint",
                "tcxOaepHashingAlgorithm:" + "PTS.scratchpad.cryptoOaepHashingAlgorithm",
                )

//set output property so caller knows exactly what was encrytped:
       outCardInfoThatWasEncrypted = inCardInfoObject;


        //if the caller wants decryption to fail within MDES:

        if (inForceDecryptionFailure == "Y") {
            //Loghandler.print(" NOTE: 'tcForceDecryptionFailure' = [" + tcForceDecryptionFailure + "] so overriding 'encryptedKey' ...")
            //check
            String cryptoEncryptedKey="BadBadEncryptedKey!";
        }

        //Loghandler.print("");


    }
    private void getSysDateBefore()
    {
        Map<String,String > timeMap=DateUtils.getSysDate();
        outDttmBefore=timeMap.get("SYSDATETIME");
        outDttmMsBefore=timeMap.get("SYSTIMEDATETIMEMS");
    }

    private void delay() throws InterruptedException {
        Thread.currentThread().sleep(1200);
    }

    private void getSysDateAfter()
    {
        Map<String,String > timeMap=DateUtils.getSysDate();
        outDttmAfter=timeMap.get("SYSDATETIME");
        outDttmMsAfter=timeMap.get("SYSTIMEDATETIMEMS");
    }


}*/
