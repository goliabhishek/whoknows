package com.mastercard.mdes.test.automation.core.request_builder.cms_core;

/**
 * Created by John Kalbac E055238 on 1/25/2016.
 */
public class CMSCoreRequestBuilder {

    public static NotifyProvisioningResultRequest notifyProvisioningResultRequest() {
        return new NotifyProvisioningResultRequest();
    }

    public static NotifyMobilePinChangeResultRequest notifyMobilePinChangeResultRequest() {
        return new NotifyMobilePinChangeResultRequest();
    }

    public static ReplenishRequest replenishRequest() {
        return new ReplenishRequest();
    }

}
