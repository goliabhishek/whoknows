package com.mastercard.mdes.test.automation.core.mdes_utilities;

import java.util.List;

/**
 * Created by e055238 on 3/7/2016.
 */
public class SSHUtil {

    public static com.jcraft.jsch.Session createSession(String host, int port, String user, String password) {
        return com.mastercard.mdes.utility.common.util.ssh.SshUtil.createSession(host, port, user, password);
    }

    public static void closeSession(com.jcraft.jsch.Session session){
        com.mastercard.mdes.utility.common.util.ssh.SshUtil.closeSession(session);
    }

    public static List<String> executeCommand(com.jcraft.jsch.Session session, String command) {
        return com.mastercard.mdes.utility.common.util.ssh.SshUtil.executeCommand(session, command);
    }

    public static void uploadFile(com.jcraft.jsch.Session session, String localFileLocation, String remoteDestination) {
        com.mastercard.mdes.utility.common.util.ssh.SshUtil.uploadFile(session, localFileLocation, remoteDestination);
    }

    public static void downloadFile(com.jcraft.jsch.Session session, String remoteFileLocation, String localDestination) {
        com.mastercard.mdes.utility.common.util.ssh.SshUtil.uploadFile(session, remoteFileLocation, localDestination);
    }
}
