package com.mastercard.mdes.test.automation.core.request_builder.Manitoba;


import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.mastercard.mdes.test.automation.core.DataBaseReset.DatabaseResetUtils;
import com.mastercard.mdes.test.automation.core.LogHandler;
import com.mastercard.mdes.test.automation.core.PropertyHandler;
import com.mastercard.mdes.test.automation.core.TestUtils;
import com.mastercard.mdes.test.automation.core.mdes_utilities.CaasServiceUtil;
import com.mastercard.mdes.test.automation.core.mdes_utilities.MDESUtilities;
import junit.framework.Assert;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;


import static com.jayway.restassured.RestAssured.given;
import static junit.framework.TestCase.assertTrue;

/**
 * Created by e062684 on 3/17/2016.
 */
@SuppressWarnings("all")
public class NetworkCheckCardObjectInfo {

    private static final String  inExpirationDateJson="\"expirationDate\" : { \"month\" : \"MONTH\", \"year\": \"YEAR\"} ";

    private	int	tcWspId	;	//	DEFAULT
    private	String[]	tcWrappedEncryptAlgorithm	;	//	DEFAULT
    private	String[]	tcUnencryptedJson	;	//	DEFAULT
    private	String[]	tcSsdSpsdCertificateSerialNumber	;	//	DEFAULT
    private	String[]	tcSsdMcpkKeyIdentifier	;	//	DEFAULT
    private	String[]	tcSsdMcpkKey	;	//	DEFAULT
    private	String[]	tcSsdMcpkCertificate	;	//	DEFAULT
    private	String[]	tcSsdDescriptor	;	//	DEFAULT
    private	String[]	tcSsdCounter	;	//	DEFAULT
    private	String[]	tcSsdCasdCertificate	;	//	DEFAULT
    private	String[]	tcSsdAppletVersionNumber	;	//	DEFAULT
    private	String[]	tcSsdAppletInstanceAid	;	//	DEFAULT
    private	String[]	tcSsdApduResponse	;	//	DEFAULT
    private	String[]	tcSsdAid	;	//	DEFAULT
    private	String[]	tcSignatureAlgInfo	;	//	DEFAULT
    private	String	tcSeid	;	//	NODEFAULT
    private	String	tcRptHttpHeaders	;	//	DEFAULT
    private	String	tcRequestId	;	//	DEFAULT
    private	String[]	tcPkcs7Signature	;	//	DEFAULT
    private	String[]	tcJsonToEncrypt	;	//	CONDITIONAL
    private	String	tcHttpHdrXpod	;	//	DEFAULT
    private	String[]	tcGenerateJsonToEncrypt	;	//	DEFAULT
    private	String[]	tcFpanSource	;	//	DEFAULT
    private	String[]	tcFpanId	;	//	NODEFAULT-CONDITIONAL
    private	String[]	tcFpan	;	//	NODEFAULT-CONDITIONAL
    private	String[]	tcForceBadWrappedKey	;	//	DEFAULT
    private	String[]	tcExp	;	//	OPTIONAL
    private	int[]	tcDeviceType	;	//	DEFAULT
    private	String[]	tcDeviceAcceptLanguage	;	//	DEFAULT
    private	String	tcDbReset	;	//	DEFAULT
    private	String	tcConversationId	;	//	DEFAULT
    private	String[]	tcCardIdentifier	;	//	DEFAULT
    private int	tcArrayCnt	;	//	DEFAULT
    private	String[]	tcAllowUnencryptedFallback	;	//	DEFAULT

    //**********************Derived Member Variables*****************************
    private String[] expMM ; //Derived from tcExp ref seperateExpireIntoMaonthAndYear()
    private String[] expYY ; //Derived from tcExp seperateExpireIntoMaonthAndYear()
    private String[] bcFpanKey ;//Derived from tcFpan and tcFpanId
    private String[] bcSsdDescriptor;//Derived from setSsdDescriptor()
    private String[] bcWrappedKey;//Derived from forcedBadWrappedKey()
    private String[] bcPublicKeyFingerprint;
    private String[] bcAsymmetricAlgorithmIdentifier;
    private String[] bcSymmetricAlgorithmIdentifier;
    private String[] bcUnencryptedData;
    private String[] bcEncryptedData;
    private String[] bcFpanCardDescriptor;
    private String[] bcNetworkCheckCardRequest;
    //************************ OUTPUT Member Variables **************************
    private String[] tcxAsymmetricAlgorithmIdentifier;
    private String[] tcxEncryptedData;
    private String[] tcxPublicKeyFingerPrint;
    private String[] tcxSymmetricAlgorithmIdentifier;
    private String[] tcxWrappedKey;
    private String[] tcxJsonThatWasEncrypted;



    public NetworkCheckCardObjectInfo()
    {
        //All the defaults get initialized
        this.tcArrayCnt=1;
        setInAllDefaults();
        //refer setTcArrayCnt(int tcArrayCnt)
        //if the user wants to change the tcArrayCnt
        //by setter method setInAllDefaults(); will be called and
        //all the values get reset
    }

    //******************** SETTERS START HERE *********************************


    public void setTcWspId(int tcWspId) {
        this.tcWspId = tcWspId;
    }

    public void setTcWrappedEncryptAlgorithm(String[] tcWrappedEncryptAlgorithm) {
        this.tcWrappedEncryptAlgorithm = tcWrappedEncryptAlgorithm;
    }

    public void setTcUnencryptedJson(String[] tcUnencryptedJson) {
        this.tcUnencryptedJson = tcUnencryptedJson;
    }

    public void setTcSsdSpsdCertificateSerialNumber(String[] tcSsdSpsdCertificateSerialNumber) {
        this.tcSsdSpsdCertificateSerialNumber = tcSsdSpsdCertificateSerialNumber;
    }

    public void setTcSsdMcpkKeyIdentifier(String[] tcSsdMcpkKeyIdentifier) {
        this.tcSsdMcpkKeyIdentifier = tcSsdMcpkKeyIdentifier;
    }

    public void setTcSsdMcpkKey(String[] tcSsdMcpkKey) {
        this.tcSsdMcpkKey = tcSsdMcpkKey;
    }

    public void setTcSsdMcpkCertificate(String[] tcSsdMcpkCertificate) {
        this.tcSsdMcpkCertificate = tcSsdMcpkCertificate;
    }

    public void setTcSsdDescriptor(String[] tcSsdDescriptor) {
        for (int i = 0; i < tcArrayCnt; i++) {
            assertTrue(" Provided an override value for 'tcSsdDescriptor' property but 'tcArrayCnt' = [" + tcArrayCnt + "]",
                    (tcSsdDescriptor[i].equalsIgnoreCase("PRESENT") && tcSsdDescriptor[i].equalsIgnoreCase("NOT-PRESENT")));
            this.tcSsdDescriptor[i] = tcSsdDescriptor[i];
        }

    }

    public void setTcSsdCounter(String[] tcSsdCounter) {
        this.tcSsdCounter = tcSsdCounter;
    }

    public void setTcSsdCasdCertificate(String[] tcSsdCasdCertificate) {
        this.tcSsdCasdCertificate = tcSsdCasdCertificate;
    }

    public void setTcSsdAppletVersionNumber(String[] tcSsdAppletVersionNumber) {
        this.tcSsdAppletVersionNumber = tcSsdAppletVersionNumber;
    }

    public void setTcSsdAppletInstanceAid(String[] tcSsdAppletInstanceAid) {
        this.tcSsdAppletInstanceAid = tcSsdAppletInstanceAid;
    }

    public void setTcSsdApduResponse(String[] tcSsdApduResponse) {
        this.tcSsdApduResponse = tcSsdApduResponse;
    }

    public void setTcSsdAid(String[] tcSsdAid) {
        this.tcSsdAid = tcSsdAid;
    }

    public void setTcSignatureAlgInfo(String[] tcSignatureAlgInfo) {
        this.tcSignatureAlgInfo = tcSignatureAlgInfo;
    }

    public void setTcSeid(String tcSeid) {
        this.tcSeid = tcSeid;
    }

    public void setTcRptHttpHeaders(String tcRptHttpHeaders) {
        assertTrue(" property 'tcRptHttpHeaders' = [" + tcRptHttpHeaders + "] ... but must be 'Y' or 'N'",
                (tcRptHttpHeaders.equalsIgnoreCase("Y") && tcRptHttpHeaders.equalsIgnoreCase("N")));
        this.tcRptHttpHeaders = tcRptHttpHeaders;
    }

    public void setTcRequestId(String tcRequestId) {
        this.tcRequestId = tcRequestId;
    }

    public void setTcPkcs7Signature(String[] tcPkcs7Signature) {
        this.tcPkcs7Signature = tcPkcs7Signature;
    }

    public void setTcJsonToEncrypt(String[] tcJsonToEncrypt) {
        this.tcJsonToEncrypt = tcJsonToEncrypt;
    }

    public void setTcHttpHdrXpod(String tcHttpHdrXpod) {
        this.tcHttpHdrXpod = tcHttpHdrXpod;
    }

    public void setTcGenerateJsonToEncrypt(String[] tcGenerateJsonToEncrypt) {
        this.tcGenerateJsonToEncrypt = tcGenerateJsonToEncrypt;
    }

    public void setTcFpanSource(String[] tcFpanSource) {
        this.tcFpanSource = tcFpanSource;
    }

    public void setTcFpanId(String[] tcFpanId) {
        this.tcFpanId = tcFpanId;
    }

    public void setTcFpan(String[] tcFpan) {
        this.tcFpan = tcFpan;
    }

    public void setTcForceBadWrappedKey(String[] tcForceBadWrappedKey) {
        this.tcForceBadWrappedKey = tcForceBadWrappedKey;
    }

    public void setTcExp(String[] tcExp) {
        seperateExpireIntoMaonthAndYear(tcExp);
//        this.tcExp = tcExp;
    }

    public void setTcDeviceType(int[] tcDeviceType) {
        this.tcDeviceType = tcDeviceType;
    }

    public void setTcDeviceAcceptLanguage(String[] tcDeviceAcceptLanguage) {
        this.tcDeviceAcceptLanguage = tcDeviceAcceptLanguage;
    }

    public void setTcDbReset(String tcDbReset) {
        this.tcDbReset = tcDbReset;
    }

    public void setTcConversationId(String tcConversationId) {
        this.tcConversationId = tcConversationId;
    }

    public void setTcCardIdentifier(String[] tcCardIdentifier) {
        this.tcCardIdentifier = tcCardIdentifier;
    }

    public void setTcArrayCnt(int tcArrayCnt) {
        this.tcArrayCnt = tcArrayCnt;
        setInAllDefaults();
    }

    public void setTcAllowUnencryptedFallback(String[] tcAllowUnencryptedFallback) {
        this.tcAllowUnencryptedFallback = tcAllowUnencryptedFallback;
    }
    //******************** SETTERS END HERE *********************************

    //******************** SET ALL DEFAULT VALUES ***************************
    private void setInAllDefaults()
    {
        // All values are set as per DEV-TEST environment
        this.tcConversationId=(UUID.randomUUID().toString() + "=" + UUID.randomUUID().toString()).substring(1,64);
        this.tcDbReset="Y";
        tcHttpHdrXpod="Test Harness";
        tcRptHttpHeaders="N";

        //set fpan&exp or fpanId under progress

        this.tcWspId=103;

        tcRequestId=Thread.currentThread().getStackTrace()[2].getMethodName()+ TestUtils.generateUniqueRequestId("");


        tcAllowUnencryptedFallback = new String[tcArrayCnt];
        tcCardIdentifier = new String[tcArrayCnt];
        tcDeviceType = new int[tcArrayCnt];
        tcDeviceAcceptLanguage = new String[tcArrayCnt];
        tcExp = new String[tcArrayCnt];
        tcForceBadWrappedKey = new String[tcArrayCnt];
        tcFpanSource = new String[tcArrayCnt];
        tcGenerateJsonToEncrypt = new String[tcArrayCnt];
        tcPkcs7Signature = new String[tcArrayCnt];
        tcSignatureAlgInfo = new String[tcArrayCnt];
        tcSsdDescriptor = new String[tcArrayCnt];
        tcSsdAid = new String[tcArrayCnt];
        tcSsdApduResponse = new String[tcArrayCnt];
        tcSsdAppletInstanceAid = new String[tcArrayCnt];
        tcSsdAppletVersionNumber = new String[tcArrayCnt];
        tcSsdCasdCertificate = new String[tcArrayCnt];
        tcSsdCounter = new String[tcArrayCnt];
        tcSsdMcpkCertificate = new String[tcArrayCnt];
        tcSsdMcpkKey = new String[tcArrayCnt];
        tcSsdMcpkKeyIdentifier = new String[tcArrayCnt];
        tcSsdSpsdCertificateSerialNumber = new String[tcArrayCnt];
        tcWrappedEncryptAlgorithm = new String[tcArrayCnt];

        for (int i = 0; i < tcArrayCnt; i++) {

            tcAllowUnencryptedFallback[i]="y";
            tcCardIdentifier[i]="1a37a5b-ec77-4ce7-acad-5ff80f4689d9=97886d8f-95b9-4705-a1f4-e08";
            tcDeviceType[i]=1;
            tcDeviceAcceptLanguage[i]="eng";
            tcForceBadWrappedKey[i]="N";
            tcFpanSource[i]="on-file";
            tcGenerateJsonToEncrypt[i]="Y";
            tcPkcs7Signature[i]="MIAGCSqGST1ROlAA";
            tcSignatureAlgInfo[i]="SHA256withECDSA";
            tcSsdDescriptor[i]="PRESENT";
            tcSsdAid[i]="A00000015153504150534400";
            tcSsdApduResponse[i]="F6D95A3CBC31";
            tcSsdAppletInstanceAid[i]="A00000000410100100010001";
            tcSsdAppletVersionNumber[i]="1.6.05G";
            tcSsdCasdCertificate[i]="3027032FF8D16A1E44D8D";
            tcSsdCounter[i]="0001";
            tcSsdMcpkCertificate[i]="-BEGIN CERT-MIICtTCCA-END CERT-";
            tcSsdMcpkKey[i]="d32d196e04573b7d9296097df4f";
            tcSsdMcpkKeyIdentifier[i]="893ad8506107bb10b03f8630";
            tcSsdSpsdCertificateSerialNumber[i]="4775723981265824934";
            tcWrappedEncryptAlgorithm[i]="RSA";

        }

        setBcFpanKey();
        seperateExpireIntoMaonthAndYear(tcExp);


    }
    //*********** END SETTING ALL DEFAULT VALUES *****************

    //*********** SET ALL DERIVED MEMBER VARIABLES *******************
    private void seperateExpireIntoMaonthAndYear(String[] tcExp)
    {
        this.tcExp = new String[tcArrayCnt];
        for (int i = 0; i < tcArrayCnt; i++) {
            this.tcExp[i]= tcExp[i];
            String message=" 'tcExp["+i+"]' = [" + tcExp[i] + "] is invalid"+
                    " must be in either MMYY or MMYYYY format";
            assertTrue(message,tcExp[i].length()==4 || tcExp[i].length()==6);
            if (tcExp[i].length() == 4) {
                expMM[i]=tcExp[i].substring(0,1);
                expYY[i]=tcExp[i].substring(2,3);
            } else if (tcExp[i].length() == 6) {
                expMM[i]=tcExp[i].substring(0,1);
                expYY[i]=tcExp[i].substring(2,5);

            }

        }
    }

    private void setBcFpanKey()
    {
        for (int i = 1; i <= tcArrayCnt; i++) {
            bcFpanKey[i]="BYFPANEXP";
        }
    }


    //**************** END SETTING ALL DERIVED MEMBER VARIABLES **********





//for reporting:
            //LogHandler.printToReport(seid);"report: seid = [" + seid + "]")

    //********************* General Method Calls **************************

    private String getGBCretFileLocation(String algorithm) throws Exception {
        assertTrue("invalid override value for 'tcAlgorithm' property; must be RSA or ECIES",algorithm.equals("RSA")|| algorithm.equals("ECIES"));
        String gbCertFileKey = "";
        switch (algorithm) {

            case "RSA":
                gbCertFileKey = "gbWrappedEncryptRsaCertFile";
                break;

            case "ECIES":
                gbCertFileKey = "gbWrappedEncryptEciesCertFile";
                break;


        }
        String gbCertFileLoc= PropertyHandler.getGlobalProperty(gbCertFileKey);//get Lo
        return gbCertFileLoc;
    }
    private void runDBReset()
    {
        String tcDeleteById = "BYSEIDFPAN";
        for (int i = 0; i <tcArrayCnt ; i++) {
            if(bcFpanKey[i].equalsIgnoreCase("BYFPANID"))
            {
                tcDeleteById="BYSEIDFPANID";
            }
            if (tcDeleteById.equalsIgnoreCase("BYSEIDFPAN")) {
                DatabaseResetUtils.resetDatabaseBySEIDAndFPAN(tcSeid, tcFpan[i]);
            }
            else {
                DatabaseResetUtils.resetDatabaseBySEIDAndFPANID(tcSeid,tcFpanId[i]);
            }
        }
    }
    private void getWrappedKey() throws Exception {

        tcxJsonThatWasEncrypted=new String[tcArrayCnt];

        tcxAsymmetricAlgorithmIdentifier=new String[tcArrayCnt];
        tcxEncryptedData=new String[tcArrayCnt];
        tcxPublicKeyFingerPrint=new String[tcArrayCnt];
        tcxSymmetricAlgorithmIdentifier=new String[tcArrayCnt];
        tcxWrappedKey=new String[tcArrayCnt];

        Map<Integer,Map> finalResultMap=new LinkedHashMap<>();
        String generatedJson;
        String json;
        for (int i = 0; i <tcArrayCnt ; i++) {
            Map<String, Object> resultMap=new HashMap<>();
            if (bcFpanKey[i].equalsIgnoreCase("BYFPANEXP")) {
                String tcFpanValue = tcFpan[i];

                //expiry is now optional so:
                String tcExpValue = tcExp[i];
                if (tcExp[i].isEmpty()) {
                    generatedJson = "{\"fpan\":\"" + tcFpanValue + "\" }";
                }
                else {
                    String inExpirationDateJsonNew = inExpirationDateJson.replaceAll("MONTH", expMM[i]);
                    inExpirationDateJsonNew = inExpirationDateJson.replaceAll("YEAR", expYY[i]);
                    generatedJson = "{\"fpan\":\"" + tcFpanValue + "\"," + inExpirationDateJsonNew + "}";
                }

            }
            else {
                String tcFpanIdValue = tcFpanId[i];
                generatedJson = "{\"fpanId\":\"" + tcFpanIdValue + "\"}";
            }
            String tcGenerateJsonToEncryptValue=tcGenerateJsonToEncrypt[i];
            if (tcGenerateJsonToEncryptValue.equalsIgnoreCase("Y")) {
                LogHandler.print(" generatedJson = [" + generatedJson + "]");
                json = generatedJson;
            }
            else {
                String tcJsonToEncryptValue = tcJsonToEncrypt[i];
                json = tcJsonToEncryptValue;
            }

            String response=MDESUtilities.wrappedEncrypt(CaasServiceUtil.EncodingType.BASE64,json,"", CaasServiceUtil.HashingAlgorithm.SHA256
            ,getGBCretFileLocation(tcWrappedEncryptAlgorithm[i]));
            JsonPath jp = new JsonPath(response);
            tcxAsymmetricAlgorithmIdentifier[i]=jp.getString("asymmetricAlgorithmId");
            tcxEncryptedData[i]=jp.getString("encryptedText");
            tcxPublicKeyFingerPrint[i]=jp.getString("wrappingKeyFingerprint");
            tcxSymmetricAlgorithmIdentifier[i]=jp.getString("symmetricAlgorithmId");
            tcxWrappedKey[i]=jp.getString("wrappedKey");
            tcxJsonThatWasEncrypted[i]=json;

        }
    }

    private void forcedBadWrappedKey()
    {
        String[] bcWrappedKey = new String[tcArrayCnt];
        for (int i = 0; i <tcArrayCnt ; i++) {
            if(tcForceBadWrappedKey[i].equalsIgnoreCase("Y")){
                bcWrappedKey[i]="badWrappedKeyValue";
            }
        }
    }

    private void setSsdDescriptor()
    {
        String ssdDescriptor;
        for (int i = 0; i <tcArrayCnt ; i++) {
            if(!tcSsdDescriptor[i].isEmpty())
            {
                ssdDescriptor = "\"ssdDescriptor\" : { \n" +
                        "                \"apduResponse\" : \"" + tcSsdApduResponse[i] + "\", \n" +
                        "                \"counter\" : \"" + tcSsdCounter[i] + "\", \n" +
                        "                \"aid\" : \"" + tcSsdAid[i] + "\", \n" +
                        "                \"appletInstanceAid\" : \"" + tcSsdAppletInstanceAid[i] + "\", \n";
                if (!tcSsdSpsdCertificateSerialNumber[i].isEmpty()) {
                    ssdDescriptor = ssdDescriptor + " \"spsdCertificateSerialNumber\" :+" +
                            " \"" + tcSsdSpsdCertificateSerialNumber + "\",\n";
                }
                ssdDescriptor 	= ssdDescriptor + " \"appletVersionNumber\" : \""
                        + tcSsdAppletVersionNumber[i] + "\", \n" +
                        "  \"casdCertificate\" : \"" + tcSsdCasdCertificate[i] + "\", \n" +
                        "  \"mobileCommercePublicKeyInfo\" : { \n" +
                        "  \"keyIdentifier\" : \"" + tcSsdMcpkKeyIdentifier[i] + "\", \n" +
                        "  \"key\" : \"" + tcSsdMcpkKey[i] + "\"";
                if (tcSsdMcpkCertificate[i].isEmpty()) {
                    ssdDescriptor = ssdDescriptor + ",\n \"certificate\" : \""
                            + tcSsdMcpkCertificate + "\"\n";
                }
                ssdDescriptor = ssdDescriptor + "                 }\n" +
                        "            }, ";

                bcSsdDescriptor[i]=ssdDescriptor;

            }
            else {

                 ssdDescriptor = "\"ssdDescriptor\" : " + tcSsdDescriptor[i] + ", ";
                bcSsdDescriptor[i]=ssdDescriptor;

            }
        }
    }
    private void setUnencryptedData()
    {
        // Currently working
        bcUnencryptedData=new String[tcArrayCnt];
        for (int i = 0; i <tcArrayCnt ; i++) {
            String json = tcxEncryptedData[i];
            if (tcAllowUnencryptedFallback[i].equalsIgnoreCase("Y")) {
                json = json.replaceAll("\"", "\\\\\"");
            }
            else {
                json = "{xxx}";
            }
           bcUnencryptedData[i] = "\"unencryptedData\" : \"" + json + "\",";
        }
    }
    private void setFpanCardDescriptor()
    {
        for (int i = 0; i <tcArrayCnt ; i++) {
            String fpanCardDescriptor =	"\"fpanCardDescriptor\" : { \n" +
                    "                \"keyInfo\" : { \n" +
                    "                \"wrappedKey\" : \"" + bcWrappedKey[i] + "\", \n" +
                    "                \"publicKeyFingerprint\" : \"" + bcPublicKeyFingerprint[i] + "\", \n" +
                    "                \"asymmetricAlgorithmIdentifier\" : \"" + bcAsymmetricAlgorithmIdentifier[i] + "\", \n" +
                    "                \"symmetricAlgorithmIdentifier\" : \"" + bcSymmetricAlgorithmIdentifier[i] + "\"";
            if(!tcSignatureAlgInfo[i].isEmpty())
            {
                fpanCardDescriptor = fpanCardDescriptor + ",\n                    " +
                        "\"signatureAlgInfo\" : \"" + tcSignatureAlgInfo[i] + "\"";
            }
            fpanCardDescriptor = 	fpanCardDescriptor + "\n                }, \n";
            if (!bcUnencryptedData[i].isEmpty()) {
                fpanCardDescriptor =	fpanCardDescriptor + " " + bcUnencryptedData[i] + " \n";
            }
            fpanCardDescriptor = 	fpanCardDescriptor + "                \"encryptedData\" : \"" + bcEncryptedData[i] + "\"";
            if (!tcPkcs7Signature[i].isEmpty()) {
                fpanCardDescriptor = fpanCardDescriptor + ",\n                \"pkcs7Signature\" : \"" + tcPkcs7Signature[i] + "\"";
            }
            fpanCardDescriptor = 	fpanCardDescriptor + "\n }, ";

            bcFpanCardDescriptor[i]=fpanCardDescriptor;

        }
    }
    public void setRequestArray()
    {
        bcNetworkCheckCardRequest=new String[tcArrayCnt];
        for (int i = 0; i <tcArrayCnt ; i++) {
            String json = "        {\n            " + bcFpanCardDescriptor[i];
            if (bcSsdDescriptor[i].isEmpty()) {
                json = json + "\n            " + bcSsdDescriptor[i] + "\n";
            }

            json = json + "            \"cardIdentifier\" : \"" + tcCardIdentifier[i] + "\",\n";
            json = json + "            \"fpanSource\" : \"" + tcFpanSource[i] + "\",\n";
            //May be modification required here
            if (tcDeviceType[i]!=0)
            {
                json = json + "            \"deviceType\" : \"" + tcDeviceType[i] + "\",\n";
            }
            json = json + "            \"deviceAcceptLanguage\" : \"" + tcDeviceAcceptLanguage[i] + "\"\n";
            json = json + "        }";

            if (i < tcArrayCnt) {
                json = json + ",";
            }
            else {
                json = json + "";
            }

            bcNetworkCheckCardRequest[i]=json;
        }
    }

}
