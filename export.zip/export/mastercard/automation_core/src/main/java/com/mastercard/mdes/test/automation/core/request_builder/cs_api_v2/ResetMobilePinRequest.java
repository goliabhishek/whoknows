package com.mastercard.mdes.test.automation.core.request_builder.cs_api_v2;

/**
 * Created by John Kalbac E055238 on 1/25/2016.
 */
public class ResetMobilePinRequest {

    private String tokenUniqueReference;
    private String reasonCode;
    private String userId;
    private String userName;
    private String organization;
    private String phone;

    public ResetMobilePinRequest tokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
        return this;
    }

    public ResetMobilePinRequest reasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
        return this;
    }

    public ResetMobilePinRequest userId(String userId) {
        this.userId = userId;
        return this;
    }

    public ResetMobilePinRequest userName(String userName) {
        this.userName = userName;
        return this;
    }

    public ResetMobilePinRequest organization(String organization) {
        this.organization = organization;
        return this;
    }

    public ResetMobilePinRequest phone(String phone) {
        this.phone = phone;
        return this;
    }


    public ResetMobilePinRequest allDefaults() {
        tokenUniqueReference = "tokenUniqueReference";
        reasonCode = "N";
        userId = "AutomatedTest";
        userName = "AutomatedTest";
        organization = "MasterCard";
        phone = "5551234567";
        return this;
    }


    public String build() {
        return "<TokenResetMobilePinRequest>" +
                "    <TokenUniqueReference>" + tokenUniqueReference + "</TokenUniqueReference>" +
                "    <ReasonCode>" + reasonCode + "</ReasonCode>" +
                "    <AuditInfo>" +
                "        <UserId>" + userId + "</UserId>" +
                "        <UserName>" + userName + "</UserName>" +
                "        <Organization>" + organization + "</Organization>" +
                "        <Phone>" + phone + "</Phone>" +
                "    </AuditInfo>" +
                "</TokenResetMobilePinRequest>";
    }

}
