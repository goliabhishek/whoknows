package com.mastercard.mdes.test.automation.core.request_builder.cms_core;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mastercard.mdes.test.automation.core.TestUtils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by John Kalbac E055238 on 1/25/2016.
 */
public class NotifyMobilePinChangeResultRequest {

    private String responseHost;
    private String requestId;
    private String tokenUniqueReference;
    private String result;

    public NotifyMobilePinChangeResultRequest responseHost(String responseHost) {
        this.responseHost = responseHost;
        return this;
    }

    public NotifyMobilePinChangeResultRequest requestId(String requestId) {
        this.requestId = requestId;
        return this;
    }

    public NotifyMobilePinChangeResultRequest tokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
        return this;
    }

    public NotifyMobilePinChangeResultRequest result(String result) {
        this.result = result;
        return this;
    }

    public NotifyMobilePinChangeResultRequest allDefaults() {
        responseHost = null;
        requestId = TestUtils.generateRequestId();
        tokenUniqueReference = "12345";
        result = "SUCCESS";
        return this;
    }


    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("responseHost", responseHost);
        jsonObject.put("requestId", requestId);
        jsonObject.put("tokenUniqueReference", tokenUniqueReference);
        jsonObject.put("result", result);

        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }
}
