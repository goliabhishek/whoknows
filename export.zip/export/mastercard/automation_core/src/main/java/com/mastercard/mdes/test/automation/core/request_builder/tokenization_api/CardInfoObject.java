package com.mastercard.mdes.test.automation.core.request_builder.tokenization_api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by John Kalbac e055238 on 1/22/2016.
 */

public class CardInfoObject {

    private String accountNumber;
    private String expiryMonth;
    private String expiryYear;
    private String securityCode;
    private String line1;
    private String line2;
    private String city;
    private String countrySubdivision;
    private String postalCode;
    private String country;
    private String dataValidUntilTimestamp;

    public CardInfoObject accountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
        return this;
    }

    public CardInfoObject expiryMonth(String expiryMonth) {
        this.expiryMonth = expiryMonth;
        return this;
    }

    public CardInfoObject expiryYear(String expiryYear) {
        this.expiryYear = expiryYear;
        return this;
    }

    public CardInfoObject securityCode(String securityCode) {
        this.securityCode = securityCode;
        return this;
    }

    public CardInfoObject line1(String line1) {
        this.line1 = line1;
        return this;
    }

    public CardInfoObject line2(String line2) {
        this.line2 = line2;
        return this;
    }

    public CardInfoObject city(String city) {
        this.city = city;
        return this;
    }

    public CardInfoObject countrySubdivision(String countrySubdivision) {
        this.countrySubdivision = countrySubdivision;
        return this;
    }

    public CardInfoObject postalCode(String postalCode) {
        this.postalCode = postalCode;
        return this;
    }

    public CardInfoObject country(String country) {
        this.country = country;
        return this;
    }

    public CardInfoObject dataValidUntilTimestamp(String dataValidUntilTimestamp) {
        this.dataValidUntilTimestamp = dataValidUntilTimestamp;
        return this;
    }


    public CardInfoObject allDefaults() {
        accountNumber = "5000123412341234";
        expiryMonth = "12";
        expiryYear = "19";
        securityCode = "123";
        line1 = "100 1st Street";
        line2 = "Apt. 4B";
        city = "St. Louis";
        countrySubdivision = "MO";
        postalCode = "61000";
        country = "USA";
        dataValidUntilTimestamp = null;
        return this;
    }


    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("accountNumber", accountNumber);
        jsonObject.put("expiryMonth", expiryMonth);
        jsonObject.put("expiryYear", expiryYear);
        jsonObject.put("securityCode", securityCode);

        Map<String, Object> billingAddress = new LinkedHashMap<>();
        billingAddress.put("line1", line1);
        billingAddress.put("line2", line2);
        billingAddress.put("city", city);
        billingAddress.put("countrySubdivision", countrySubdivision);
        billingAddress.put("postalCode", postalCode);
        billingAddress.put("country", country);

        jsonObject.put("billingAddress", billingAddress);
        jsonObject.put("dataValidUntilTimestamp", dataValidUntilTimestamp);


        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }

}