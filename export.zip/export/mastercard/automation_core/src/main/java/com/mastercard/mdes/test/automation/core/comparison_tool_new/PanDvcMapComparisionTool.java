package com.mastercard.mdes.test.automation.core.comparison_tool_new;

import com.mastercard.mdes.test.automation.core.DataUtils;

/**
 * Created by e062684 on 2/25/2016.
 */
public class PanDvcMapComparisionTool extends ComparisonTool {

    public  void getBeforeRecordUsingTokenUniqueReference(String param) throws Exception {
        beforeResult=DataUtils.getPanDvcMapRecordUsingTokenUniqueReference(param);
    }

    public void getAfterRecordUsingTokenUniqueReference(String param) throws Exception {
        afterResult=DataUtils.getPanDvcMapRecordUsingTokenUniqueReference(param);
    }

    public void getBeforeRecordUsingMapId(String param) throws Exception {
        // TODO
    }

    public void getAfterRecordUsingMapId(String param) throws Exception {
        // TODO
    }

}
