package com.mastercard.mdes.test.automation.core;

import com.ibm.mq.*;
import com.jayway.restassured.path.json.JsonPath;

import java.io.BufferedReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by John Kalbac E055238 on 2/2/2016.
 */
public class MQHandler {

    public static void sendMQMessage(String queueManager, String queueName, String messageType, String messageBody) throws Exception {

        LogHandler.print("Sending MQ Message   (QueueManager: " + queueManager + ", QueueName: " + queueName + ")");

        MQEnvironment.hostname = PropertyHandler.getEnvironmentProperty("MQEnvironment.hostname");
        MQEnvironment.port = Integer.parseInt(PropertyHandler.getEnvironmentProperty("MQEnvironment.port"));
        MQEnvironment.channel = PropertyHandler.getEnvironmentProperty("MQEnvironment.channel");
        MQEnvironment.properties.put(MQC.TRANSPORT_PROPERTY, MQC.TRANSPORT_MQSERIES);

        MQQueueManager qm = new MQQueueManager(queueManager);
        MQQueue openapiQ = qm.accessQueue(queueName,
                MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT,
                null,
                null,
                null);

        MQMessage testMsg = new MQMessage();

        testMsg.setStringProperty("messageType", messageType);

        LogHandler.printMQMessageBody(messageBody);

        testMsg.writeString(messageBody);

        openapiQ.put(testMsg);

        qm.disconnect();
        LogHandler.print(" MQ Message Sent");

        // It may be necessary to add a short delay to allow processing of the message.

    }

    public static List getMessages(String queueMgrName, String queueName, String startTimestamp) throws Exception {
        List messageList = new ArrayList();

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
        Date parsedDate = dateFormat.parse(startTimestamp);
        Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
        //LogHandler.print("      Looking for records after timestamp: " + timestamp);

        Connection con = DatabaseHandler.getDbConnection();
        PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM QUEUE_MSG WHERE QUEUE_MGR_NAM=? AND QUEUE_NAM=? AND CRTE_TS>=? ORDER BY CRTE_TS ASC"
        );
        ps.setString(1, queueMgrName);
        ps.setString(2, queueName);
        ps.setString(3, String.valueOf(timestamp));
        ResultSet result = ps.executeQuery();

        while (result.next()) {
            StringBuffer strOut = new StringBuffer();
            String aux;
            BufferedReader br = new BufferedReader(result.getClob("MSG").getCharacterStream());
            while ((aux=br.readLine())!=null) {
                strOut.append(aux);
            }
            messageList.add(strOut.toString());
        }

        con.close();
        ps.close();

        return messageList;
    }

    public static String getCurrentDatabaseTimestamp() throws Exception {
        String dbTimestamp = null;
        Connection con = DatabaseHandler.getDbConnection();
        PreparedStatement ps = con.prepareStatement(
                "SELECT TO_CHAR(CURRENT_TIMESTAMP, 'MM/DD/YYYY HH:MI:SS PM')  AS SYSDATETIME FROM DUAL"
        );
        ResultSet result = ps.executeQuery();

        if (result.next()) {
            dbTimestamp = result.getString("SYSDATETIME");
        }

        con.close();
        ps.close();

        return dbTimestamp;
    }

    public static void verifyTokenizationCompleteMessages(String beforeTimestamp, String mapId) throws Exception {
        // Check if the environment has the queueRecorderEnabled property enabled
        String queueRecorderEnabled = PropertyHandler.getEnvironmentProperty("queueRecorderEnabled");
        if (!queueRecorderEnabled.equalsIgnoreCase("true")) {
            return;
        }

        List tcMessage = getMessages(PropertyHandler.getEnvironmentProperty("queueManagerName"), "DES.INTERNALMSG.REQ", beforeTimestamp);
        LogHandler.print("    TOKENIZATION_COMPLETE network messages");
        assert tcMessage.size() == 2;
        LogHandler.print("        Confirmed two messages found");
        for (Integer i = 0; i<tcMessage.size(); i++) {
            LogHandler.print("        Message body: " + tcMessage.get(i));
            JsonPath tcMsgJson = new JsonPath(tcMessage.toString());
            assertEquals("TOKENIZATION_COMPLETE_NOTIFICATION", tcMsgJson.get("outboundRequestType[0]").toString());
            assertEquals(mapId, tcMsgJson.get("payload.panDeviceMapId[0]").toString());
        }
        // Each message is identical except for the sendWebRequest value. One is true; one is false.
        assertTrue(tcMessage.toString().contains("\"sendWebRequest\":true"));
        assertTrue(tcMessage.toString().contains("\"sendWebRequest\":false"));
    }
}
