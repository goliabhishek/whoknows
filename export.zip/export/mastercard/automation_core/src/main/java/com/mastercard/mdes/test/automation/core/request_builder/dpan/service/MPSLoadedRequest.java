package com.mastercard.mdes.test.automation.core.request_builder.dpan.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mastercard.mdes.test.automation.core.TestUtils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by E055238 on 3/4/2016.
 */
public class MPSLoadedRequest {

    private String loadId;
    private String suid;

    public MPSLoadedRequest loadId (String loadId) {
        this.loadId = loadId;
        return this;
    }

    public MPSLoadedRequest suid (String suid) {
        this.suid = suid;
        return this;
    }

    public MPSLoadedRequest allDefaults() {
        loadId = null;
        suid = TestUtils.generateRequestId();
        return this;
    }

    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("loadId", loadId);
        jsonObject.put("suid", suid);

        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }

}
