package com.mastercard.mdes.test.automation.core.request_builder.tokenization_api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mastercard.mdes.test.automation.core.TestUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by John Kalbac e055238 on 1/22/2016.
 */

public class TokenizeByTURRequest {

    private String requestId;
    private String tokenRequestorId;
    private String useAccountPanFromTokenUniqueReference;

    public TokenizeByTURRequest requestId(String requestId) {
        this.requestId = requestId;
        return this;
    }

    public TokenizeByTURRequest tokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
        return this;
    }

    public TokenizeByTURRequest useAccountPanFromTokenUniqueReference(String useAccountPanFromTokenUniqueReference) {
        this.useAccountPanFromTokenUniqueReference = useAccountPanFromTokenUniqueReference;
        return this;
    }

    public TokenizeByTURRequest allDefaults() {
        requestId = TestUtils.generateRequestId();
        tokenRequestorId = "12345678901";
        useAccountPanFromTokenUniqueReference = "tokenUniqueReference";
        return this;
    }


    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("requestId", requestId);
        jsonObject.put("tokenRequestorId", tokenRequestorId);

        Map<String, Object> cardInfo = new HashMap<>();
        cardInfo.put("useAccountPanFromTokenUniqueReference", useAccountPanFromTokenUniqueReference);

        jsonObject.put("cardInfo", cardInfo);

        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }

}