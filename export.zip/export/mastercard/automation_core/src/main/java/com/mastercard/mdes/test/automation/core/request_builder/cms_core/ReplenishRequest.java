package com.mastercard.mdes.test.automation.core.request_builder.cms_core;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mastercard.mdes.test.automation.core.TestUtils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by John Kalbac E055238 on 1/25/2016.
 */
public class ReplenishRequest {

    private String requestId;
    private String tokenUniqueReference;
    private Integer numActiveAtcsRequired;
    private Integer startingAtcNum;

    /**
     * {
     "requestId":"350372991",
     "tokenUniqueReference":"DSHRMC000000000873c07667b8414e7f9ffb4de2558fe24d",
     "transactionCredentialsStatus":[
     {"atc" : 100, "status" : "UNUSED_ACTIVE", "timestamp" : "2015-03-10T12:10:14.123-06:00"},
     {"atc" : 101, "status" : "UNUSED_ACTIVE", "timestamp" : "2015-03-10T12:10:14.123-06:00"},
     {"atc" : 102, "status" : "UNUSED_ACTIVE", "timestamp" : "2015-03-10T12:10:14.123-06:00"}
     ]
     }
     */

    public ReplenishRequest requestId(String requestId) {
        this.requestId = requestId;
        return this;
    }

    public ReplenishRequest tokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
        return this;
    }

    public ReplenishRequest numActiveAtcsRequired (Integer numActiveAtcsRequired) {
        this.numActiveAtcsRequired = numActiveAtcsRequired;
        return this;
    }

    public ReplenishRequest startingAtcNum (Integer startingAtcNum) {
        this.startingAtcNum = startingAtcNum;
        return this;
    }

    public ReplenishRequest allDefaults() {
        requestId = TestUtils.generateRequestId();
        tokenUniqueReference = "12345";
        numActiveAtcsRequired = 0;
        startingAtcNum = 1;
        return this;
    }


    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("requestId", requestId);
        jsonObject.put("tokenUniqueReference", tokenUniqueReference);

        ArrayList a = new ArrayList();

        for (Integer i = 0; i < numActiveAtcsRequired; i++) {
            Map<String, Object> transactionCredentialsStatus = new LinkedHashMap<>();
            transactionCredentialsStatus.put("atc", startingAtcNum + i);
            transactionCredentialsStatus.put("status", "UNUSED_ACTIVE");
            transactionCredentialsStatus.put("timestamp", "2015-03-10T12:10:14.123-06:00");
            a.add(transactionCredentialsStatus);
        }

        jsonObject.put("transactionCredentialsStatus", a);


        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }
    }
}
