package com.mastercard.mdes.test.automation.core.request_builder.dpan.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mastercard.mdes.test.automation.core.TestUtils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by e029380 on 3/21/2016.
 */
public class ExhaustedRequest {

    private String siteOrigin;
    private String siteSource;
    private String suid;
    private String poolId;

    public ExhaustedRequest siteOrigin (String siteOrigin){
        this.siteOrigin = siteOrigin;
        return this;
    }

    public ExhaustedRequest siteSource (String siteSource){
        this.siteSource = siteSource;
        return this;
    }

    public ExhaustedRequest suid (String suid) {
        this.suid = suid;
        return  this;
    }

    public ExhaustedRequest poolId (String poolId){
        this.poolId = poolId;
        return  this;
    }

    public ExhaustedRequest allDefaults(){
        siteOrigin = "1";
        siteSource = "1";
        suid = TestUtils.generateRequestId();
        poolId = null;
        return  this;
    }

    public String build(){
        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("siteOrigin", siteOrigin);
        jsonObject.put("siteSource",siteSource);
        jsonObject.put("suid",suid);
        jsonObject.put("poolId",poolId);


        try {
            return new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new RuntimeException();
        }


    }
}
