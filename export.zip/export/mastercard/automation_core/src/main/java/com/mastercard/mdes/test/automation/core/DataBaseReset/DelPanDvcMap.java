package com.mastercard.mdes.test.automation.core.DataBaseReset;

import com.mastercard.mdes.test.automation.core.DatabaseHandler;
import com.mastercard.mdes.test.automation.core.LogHandler;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by e062684 on 3/15/2016.
 */
public class DelPanDvcMap {
   private  Connection con = null;
   private  String tcMapId;

    protected DelPanDvcMap(String tcMapId) throws Exception {
        DatabaseHandler db = new DatabaseHandler();
        con=db.getDbConnection();
        this.tcMapId=tcMapId;
    }

    protected  void dbDelPanDvcMap()
    {
        delPrvsnRqstChildRows();
        delPanDvcMapChildRows();
        getPanDataEncId();
        delPanDvcMapRow();
        delPanDataEncRows();

    }
    private  void delPrvsnRqstChildRows()  {

        try(Statement stmt=con.createStatement()) {
//            Fetch Results
            String sqlText = "SELECT PRVSN_RQST_ID FROM PRVSN_RQST WHERE MAP_ID = " + tcMapId;
            LogHandler.print("EXECUTING " + sqlText);
            ResultSet results = stmt.executeQuery(sqlText);
            while (results.next())
            {
                LogHandler.print("  >> deleting child rows of PRVSN_RQST.PRVSN_RQST_ID = [" + results.getString("PRVSN_RQST_ID") + "] ...");
                //SCHED_RETRY_TASK:
                LogHandler.print("  >> deleting SCHED_RETRY_TASK ...");
                sqlText = "DELETE FROM SCHED_RETRY_TASK WHERE PRVSN_RQST_ID = " + results.getString("PRVSN_RQST_ID");
                LogHandler.print("EXECUTING 'dbUtilExecute.execute(" + sqlText + ")'");
                stmt.executeUpdate(sqlText);
                LogHandler.print("COMPLETED " + sqlText );
            }
            results.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    private  void delPanDvcMapChildRows()  {
        String sqlTextArray[] = {"DELETE FROM API_ACTVTY WHERE MAP_ID = " + tcMapId,
                "DELETE FROM CUST_SERV_CMNT WHERE MAP_ID = " + tcMapId,
                "DELETE FROM PAN_DVC_MAP_ACTVTY WHERE MAP_ID = " + tcMapId,
                "DELETE FROM PAN_DVC_MAP_ACTV_CD_MTHD WHERE MAP_ID = " + tcMapId,
                "DELETE FROM PAN_DVC_MAP_SPND WHERE MAP_ID = " + tcMapId,
                "DELETE FROM PAN_DVC_MAP_DVC_NOTIF WHERE MAP_ID = " + tcMapId,
                "DELETE FROM PRVSN_RQST WHERE MAP_ID = " + tcMapId,
                "DELETE FROM RESRV_DPAN WHERE MAP_ID = " + tcMapId};
        try (Statement stmt = con.createStatement()) {
            for (String sqlStmt : sqlTextArray) {
                stmt.addBatch(sqlStmt);
            }
                if (stmt != null) {
                    stmt.executeBatch();
                    LogHandler.print("  >> CHILD rows deleted ...");
                    stmt.close();
                }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }


    }
    private  Map getPanDataEncId()
    {
        Map<String,Object> encId=new HashMap<>();
        String sqlText = "SELECT " +
                "NVL(TO_CHAR(DVC_PAN_DATA_ENC_ID), 'NULL') \"DVC_PAN_DATA_ENC_ID\", " +
                "NVL(TO_CHAR(FUND_PAN_DATA_ENC_ID),'NULL') \"FUND_PAN_DATA_ENC_ID\" " +
                "FROM PAN_DVC_MAP WHERE MAP_ID = " + tcMapId;
        try (Statement stmt = con.createStatement()) {
            ResultSet results=stmt.executeQuery(sqlText);

            while (results.next())
            {
                encId.put("dvcPanDataEncId",results.getLong("DVC_PAN_DATA_ENC_ID"));
                encId.put("fundPanDataEncId",results.getString("FUND_PAN_DATA_ENC_ID"));
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return encId;
    }

    private  void delPanDvcMapRow()
    {
        String sqlText = "DELETE FROM PAN_DVC_MAP WHERE MAP_ID = " + tcMapId;
        try (Statement stmt = con.createStatement()) {
            stmt.executeUpdate(sqlText);
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private  void delPanDataEncRows()
    {
        Map<String,Object>  encDataMap=getPanDataEncId();

        String sqlText = "SELECT ENCRYPT_PAN_DATA FROM PAN_DATA_ENC " +
                "WHERE PAN_DATA_ENC_ID = " +encDataMap.get("dvcPanDataEncId");
        try (Statement stmt = con.createStatement()) {
            ResultSet results=stmt.executeQuery(sqlText);

            while (results.next())
            {
                encDataMap.put("dvcEncryptPanData",results.getString("ENCRYPT_PAN_DATA"));
            }
            DelPanDataEnc dpe=new DelPanDataEnc("Y",encDataMap.get("dvcPanDataEncId").toString(),
                    encDataMap.get("dvcEncryptPanData").toString());
            dpe.dbDelPanDataEnc();
            results.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        con.close();
    }
}
