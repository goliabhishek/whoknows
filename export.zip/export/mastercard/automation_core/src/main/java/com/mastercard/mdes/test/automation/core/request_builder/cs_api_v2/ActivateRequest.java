package com.mastercard.mdes.test.automation.core.request_builder.cs_api_v2;

/**
 * Created by John Kalbac E055238 on 1/25/2016.
 */
public class ActivateRequest {

    private String tokenUniqueReference;
    private String reasonCode;
    private String commentText;
    private String userId;
    private String userName;
    private String organization;
    private String phone;

    public ActivateRequest tokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
        return this;
    }

    public ActivateRequest reasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
        return this;
    }

    public ActivateRequest commentText(String commentText) {
        this.commentText = commentText;
        return this;
    }

    public ActivateRequest userId(String userId) {
        this.userId = userId;
        return this;
    }

    public ActivateRequest userName(String userName) {
        this.userName = userName;
        return this;
    }

    public ActivateRequest organization(String organization) {
        this.organization = organization;
        return this;
    }

    public ActivateRequest phone(String phone) {
        this.phone = phone;
        return this;
    }


    public ActivateRequest allDefaults() {
        tokenUniqueReference = "tokenUniqueReference";
        reasonCode = "C";
        commentText = "Activate from automated test suite";
        userId = "AutomatedTest";
        userName = "AutomatedTest";
        organization = "MasterCard";
        phone = "5551234567";
        return this;
    }


    public String build() {
        return "<ActivateRequest>" +
                "    <TokenUniqueReference>" + tokenUniqueReference + "</TokenUniqueReference>" +
                "    <ReasonCode>" + reasonCode + "</ReasonCode>" +
                "    <CommentText>" + commentText + "</CommentText>" +
                "    <AuditInfo>" +
                "        <UserId>" + userId + "</UserId>" +
                "        <UserName>" + userName + "</UserName>" +
                "        <Organization>" + organization + "</Organization>" +
                "        <Phone>" + phone + "</Phone>" +
                "    </AuditInfo>" +
                "</ActivateRequest>";
    }

}
