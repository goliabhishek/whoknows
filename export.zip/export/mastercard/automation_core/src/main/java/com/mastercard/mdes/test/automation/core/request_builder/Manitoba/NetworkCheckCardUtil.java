package com.mastercard.mdes.test.automation.core.request_builder.Manitoba;

/**
 * Created by e062684 on 3/17/2016.
 */
public class NetworkCheckCardUtil {
    // all the methods will be in static
    public static void sampleMethod()
    {
        NetworkCheckCardObjectInfo nccoi=new NetworkCheckCardObjectInfo();
        //set defaults or non defaults or optionals
       /* nccoi.setTcDeviceType1("uuuuuu");
        nccoi.setTcCardIdentifier3("yyyyyy");
        *///call the request methods and pass NetworkCheckCardObjectInfo object (nccoi) or
        // generate a Json or xml object to make
        //request calls
    }
}
