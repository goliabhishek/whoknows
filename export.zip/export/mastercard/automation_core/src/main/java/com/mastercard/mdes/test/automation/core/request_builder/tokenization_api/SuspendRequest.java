package com.mastercard.mdes.test.automation.core.request_builder.tokenization_api;

import com.mastercard.mdes.test.automation.core.TestUtils;
import com.mastercard.mdes.test.automation.core.request_builder.JsonObjectMapper;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by John Kalbac e055238 on 1/22/2016.
 */

public class SuspendRequest {

    private String requestId;
    private String tokenUniqueReference;
    private String reason;

    public SuspendRequest requestId(String requestId) {
        this.requestId = requestId;
        return this;
    }

    public SuspendRequest tokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
        return this;
    }

    public SuspendRequest reason(String reason) {
        this.reason = reason;
        return this;
    }

    public SuspendRequest allDefaults() {
        requestId = TestUtils.generateRequestId();
        tokenUniqueReference = "12345";
        reason = "OTHER";
        return this;
    }


    public String build() {

        Map<String, Object> jsonObject = new LinkedHashMap<>();
        jsonObject.put("requestId", requestId);
        jsonObject.put("tokenUniqueReference", tokenUniqueReference);
        jsonObject.put("reason", reason);

        // Evaluate the values and update based on keywords
        jsonObject = JsonObjectMapper.evaluateMapForKeywords(jsonObject);

        return JsonObjectMapper.writeMapAsJson(jsonObject);
    }

}