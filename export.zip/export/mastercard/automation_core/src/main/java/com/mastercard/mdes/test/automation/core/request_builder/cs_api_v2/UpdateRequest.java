package com.mastercard.mdes.test.automation.core.request_builder.cs_api_v2;

/**
 * Created by John Kalbac E055238 on 1/25/2016.
 */
public class UpdateRequest {

    private String tokenUniqueReference;
    private String newAccountPan;
    private String expirationDate;
    private String accountPanSequenceNumber;
    private String updateWalletProviderIndicator;
    private String userId;
    private String userName;
    private String organization;
    private String phone;

    public UpdateRequest tokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
        return this;
    }

    public UpdateRequest newAccountPan(String newAccountPan) {
        this.newAccountPan = newAccountPan;
        return this;
    }

    public UpdateRequest expirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
        return this;
    }

    public UpdateRequest accountPanSequenceNumber(String accountPanSequenceNumber) {
        this.accountPanSequenceNumber = accountPanSequenceNumber;
        return this;
    }

    public UpdateRequest updateWalletProviderIndicator(String updateWalletProviderIndicator) {
        this.updateWalletProviderIndicator = updateWalletProviderIndicator;
        return this;
    }

    public UpdateRequest userId(String userId) {
        this.userId = userId;
        return this;
    }

    public UpdateRequest userName(String userName) {
        this.userName = userName;
        return this;
    }

    public UpdateRequest organization(String organization) {
        this.organization = organization;
        return this;
    }

    public UpdateRequest phone(String phone) {
        this.phone = phone;
        return this;
    }


    public UpdateRequest allDefaults() {
        tokenUniqueReference = "tokenUniqueReference";
        newAccountPan = "50001234123412345";
        expirationDate = "1128";
        accountPanSequenceNumber = "01";
        updateWalletProviderIndicator = "0";
        userId = "AutomatedTest";
        userName = "AutomatedTest";
        organization = "MasterCard";
        phone = "5551234567";
        return this;
    }


    public String build() {
        return "<TokenUpdateRequest>" +
                "    <TokenUniqueReference>" + tokenUniqueReference + "</TokenUniqueReference>" +
                "    <NewAccountPan>" + newAccountPan + "</NewAccountPan>" +
                "    <ExpirationDate>" + expirationDate + "</ExpirationDate>" +
                "    <AccountPanSequenceNumber>" + accountPanSequenceNumber + "</AccountPanSequenceNumber>" +
                "    <UpdateWalletProviderIndicator>" + updateWalletProviderIndicator + "</UpdateWalletProviderIndicator>" +
                "    <AuditInfo>" +
                "        <UserId>" + userId + "</UserId>" +
                "        <UserName>" + userName + "</UserName>" +
                "        <Organization>" + organization + "</Organization>" +
                "        <Phone>" + phone + "</Phone>" +
                "    </AuditInfo>" +
                "</TokenUpdateRequest>";
    }

}
