package com.mastercard.mdes.test.automation.core;

import com.jayway.restassured.response.Response;

import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Random;

import static com.jayway.restassured.RestAssured.when;

/**
 * Created by E055238 on 8/6/2015.
 */

public class TestUtils {

    public static String generateRequestId() {
        Random random = new Random();
        Integer i = random.nextInt(100000000);
        return i.toString();
    }



    public static void printVersionCheckDetails() throws Exception {
        LogHandler.print(" Retrieving the current build details from /version.jsp service");

        // Check for Stage environment configuration since version.jsp only works on DEV-CLOUD
        String environment = PropertyHandler.getGlobalProperty("environment");
        if (environment.toLowerCase().contains("stage")) {
            LogHandler.print("    Detected a Stage environment configuration. Skipping the version check.");
            return;
        }

        Properties p = new Properties();
        try {
            Response response = when().post("/version.jsp");
            p.load(new StringReader(response.asString()));
            LogHandler.print("    Implementation-Title:        " + p.getProperty("Implementation-Title"));
            LogHandler.print("    Implementation-Version:      " + p.getProperty("Implementation-Version"));
            LogHandler.print("    Build-Jdk:                   " + p.getProperty("Build-Jdk"));
            LogHandler.print("    Created-By:                  " + p.getProperty("Created-By"));
            LogHandler.print("    Build-Timestamp:             " + p.getProperty("Build-Timestamp"));
            LogHandler.print("    SCM-Revision:                " + p.getProperty("SCM-Revision"));
            LogHandler.print("    Build-Number:                " + p.getProperty("Build-Number"));
            LogHandler.print("    Build-Key:                   " + p.getProperty("Build-Key"));
            LogHandler.print("    Build-Results-URL:           " + p.getProperty("Build-Results-URL"));
        } catch (Exception e) {
            LogHandler.print("    Unable to retrieve version details");
        }
    }

    public static Boolean evaluateInExecSwitch(Object inExec){
        if (!inExec.toString().equalsIgnoreCase("Y")) {
            LogHandler.print("inExec is not 'Y', skipping test case");
            return false;
        } else {
            return true;
        }
    }


    /**
     * Request utils from SOAPUI start here
     */

    public static String generateUniqueRequestId(String key) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd-HHmmss.SSS");
        return key + "-" + simpleDateFormat.format(new Date());
    }

    public static String generateTermsAndConditionsDate() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz");
        return simpleDateFormat.format(new Date());
    }

    public static String generateUniqueAlphanumericString(int length) {
        char[] charSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
        String result = "";
        Random random = new Random();

        for (int i = 0; i < length; i++) {
            int randomNumber = random.nextInt(charSet.length);
            result += charSet[randomNumber];
        }

        return result;
    }

    public static String generateUniqueHexString(int length) {
        char[] charSet = "ABCDEF0123456789".toCharArray();
        String result = "";
        Random random = new Random();

        for (int i = 0; i < length; i++) {
            int randomNumber = random.nextInt(charSet.length);
            result += charSet[randomNumber];
        }

        return result;
    }

    public static String generateUniqueNumericString(int length) {
        char[] charSet = "0123456789".toCharArray();
        String result = "";
        Random random = new Random();

        for (int i = 0; i < length; i++) {
            int randomNumber = random.nextInt(charSet.length);
            result += charSet[randomNumber];
        }

        return result;
    }
}