package com.mastercard.mdes.test.automation.core.request_builder.dpan;

import com.mastercard.mdes.test.automation.core.request_builder.dpan.service.*;
import com.mastercard.mdes.test.automation.core.request_builder.dpan.consumer.*;

/**
 * Created by E055238 on 3/4/2016.
 */
public class DPANRequestBuilder {

    /**
     *  DPAN Service requests
     */

    public static ConfigureRequest configureRequest()
    {
        return new ConfigureRequest();
    }

    public static ExhaustedRequest exhaustedRequest()
    {
        return new ExhaustedRequest();
    }

    public static HashRequest hashRequest()
    {
        return new HashRequest();
    }

    public static MPSLoadedRequest mpsLoadedRequest()
    {
        return new MPSLoadedRequest();
    }

    public static RecycleRequest recycleRequest()
    {
        return new RecycleRequest();
    }


    /**
     *  DPAN Consumer requests
     */

    public static AcquireRequest acquireRequest()
    {
        return new AcquireRequest();
    }

    public static CancelRequest cancelRequest()
    {
        return new CancelRequest();
    }

    public static ConfirmRequest confirmRequest()
    {
        return new ConfirmRequest();
    }

}

