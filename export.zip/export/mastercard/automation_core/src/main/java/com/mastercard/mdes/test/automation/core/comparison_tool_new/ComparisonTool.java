package com.mastercard.mdes.test.automation.core.comparison_tool_new;

import com.mastercard.mdes.test.automation.core.LogHandler;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import static org.junit.Assert.*;



/**
 * Created by e062684 on 2/25/2016.
 */
public  class ComparisonTool {

    public String[] params;
    protected Map beforeResult;
    protected Map afterResult;
    private boolean isInsert=false;
    private final static String notUpdated="NOT-UPDATED";
    private final static String updated="UPDATED";
    private final static String ignore="IGNORE";
    private final static String notNull="NOT-NULL";
    private final static String dateRange="DATERANGE:";

    /**
     * To check afterResult date is in between the expected Result range
     * @param expValue
     * @param orignalValue
     * @throws ParseException
     */
    private void checkDateRange(String expValue, String orignalValue) throws ParseException {
        expValue = expValue.replaceAll("DATERANGE:","");
        String[] expDateRange = expValue.split("#");
        DateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.ENGLISH);
        Date expDate1 = format.parse(expDateRange[0]);
        Date expDate2 = format.parse(expDateRange[1]);
        format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
        Date originalDate = format.parse(orignalValue);
        boolean check=originalDate.compareTo(expDate1) >= 0 && originalDate.compareTo(expDate2) <= 0;
        assertTrue("Updated date is not between the range",check);
    }

    /**
     * Local method to compare and assert the expectedRecod and afterResults record
     * @param expectedRecord
     * @throws ParseException
     */
    private void compareExpectedAndAfterResults(Map<String,Object> expectedRecord) throws ParseException {
        String message;
        for (String key:expectedRecord.keySet()) {
            LogHandler.print("----->"+key);
            message = "After Result is not Equal to Expected result there is change " + key + " column";
            String expectedValue = expectedRecord.get(key.toString()).toString();
            String realValue = afterResult.get(key.toString())!=null?afterResult.get(key.toString()).toString():"";

                if (!isInsert && expectedValue.equalsIgnoreCase(notUpdated)) {
                    String beforeValue = beforeResult.get(key.toString())!=null?beforeResult.get(key.toString()).toString():"";
                    message = "Field not updated but After result is not same as before result";
                    assertEquals(message, beforeValue, realValue);
                } else if (!isInsert && expectedValue.equalsIgnoreCase(updated)) {
                    String beforeValue = beforeResult.get(key.toString())!=null?beforeResult.get(key.toString()).toString():"";
                    message = "Field updated but After result is  same as before result";
                    assertNotEquals(message, beforeValue, realValue);
                }
                else if ( expectedValue.equalsIgnoreCase(ignore))
                    continue;
                else if ( expectedValue.equalsIgnoreCase(notNull) )
                {
                    message="Field updated but After result is NULL";
                    assertNotNull(message, realValue);
                }
                else if ( expectedValue.startsWith(dateRange) == true )
                {

                    checkDateRange(expectedValue,realValue);
                }
                else {
                    assertEquals(message, expectedValue, realValue);
                }

        }
    }

    public void compareResultsAfterInsert(Map<String,Object> testRowMap, String prefix) throws Exception {
        LogHandler.print("**************** Insert record comparison Start ****************");
        String message;
        isInsert=true;
        Map<String, Object> expectedRecord= MiscUtilties.createFilteredMapUsingPrefix(testRowMap,prefix);
        message = "No new insertion has happened";
        assertNotEquals(message,beforeResult.size(),afterResult.size());
        compareExpectedAndAfterResults(expectedRecord);
        LogHandler.print("**************** comparison successful ****************");
    }

    /**
     *
     * @param testRowMap
     * @param prefix
     * @throws Exception
     */
    public void compareResultsAfterUpdateFull(Map<String,Object> testRowMap, String prefix) throws Exception {
        LogHandler.print("**************** Update Full record comparison Start ****************");
        Map<String, Object> expectedRecord= MiscUtilties.createFilteredMapUsingPrefix(testRowMap,prefix);
        String message;
        message = "Column count of after result and before result are not same";
        assertEquals(message,beforeResult.size(),afterResult.size());
        compareExpectedAndAfterResults(expectedRecord);
        LogHandler.print("**************** comparison successful ****************");
    }

    public void compareResultsAfterUpdateLite(Map<String,Object> testRowMap, String prefix) throws Exception {
        LogHandler.print("**************** Update Lite record comparison Start ****************");
        Map<String, Object> expectedRecord= MiscUtilties.createFilteredMapUsingPrefix(testRowMap,prefix);
        String message = "Column count of after result and before result are not same";
        assertEquals(message,beforeResult.size(),afterResult.size());
        for (Object key:beforeResult.keySet()){
            if(!expectedRecord.keySet().contains(key.toString()))
            {
                if(!key.toString().contains("TS")) {
                    message = "After Result is not Equal to Before result there is change " + key + " column";
                    assertEquals(message, beforeResult.get(key.toString()), afterResult.get(key.toString()));
                }
            }
        }
        compareExpectedAndAfterResults(expectedRecord);
        LogHandler.print("**************** comparison successful ****************");
    }

}
