package com.mastercard.mdes.test.automation.core.DataBaseLookUp;

import com.google.common.base.Joiner;
import com.jayway.restassured.path.json.JsonPath;
import com.mastercard.mdes.test.automation.core.DatabaseHandler;
import com.mastercard.mdes.test.automation.core.LogHandler;
import com.mastercard.mdes.test.automation.core.comparison_tool_new.MiscUtilties;
import groovy.json.JsonSlurper;
import junit.framework.Assert;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static junit.framework.TestCase.assertTrue;

/**
 * Created by e062684 on 3/16/2016.
 */
@SuppressWarnings("all")
public class DBLookUpUtils {
    private static Connection con=null;

    private static void establishConnection()
    {
        DatabaseHandler db = new DatabaseHandler();
        try {
            con = db.getDbConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private static void closeConnection()
    {
        try {
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param dvcPan
     * @return
     */
    public static Map<Integer, Map> getAmsMckMapRow(String dvcPan)
    {
        String sqlText =	"SELECT " +
                "NVL(DVC_PAN, 'NULL') \"DVC_PAN\", " +
                "NVL(FUND_PAN_EXPIR_DT, 'NULL') \"FUND_PAN_EXPIR_DT\", " +
                "NVL(FUND_PAN, 'NULL') \"FUND_PAN\", " +
                "NVL(MAP_STAT, 'NULL') \"MAP_STAT\", " +
                "NVL(TO_CHAR(RPLCTN_UPDT_TS, 'YYYY/MM/DD HH24:MI:SS.FF'), 'NULL') \"RPLCTN_UPDT_TS\" " +
                "FROM AMS_MCK_MAP " +
                "WHERE DVC_PAN = '" + dvcPan + "'";

        return getResultData(sqlText);
    }

    public static Map<Integer, Map> getDvcNotifRow(String dvcNotifId)
    {
        String sqlText =	"SELECT " +
                "NVL(CLOUD_NOTIF_TOKEN_ID, 'NULL') \"CLOUD_NOTIF_TOKEN_ID\", " +
                "NVL(TO_CHAR(DVC_NOTIF_ID), 'NULL') \"DVC_NOTIF_ID\", " +
                "NVL(HASH_WLT_PRVDR_ACCT_ID, 'NULL') \"HASH_WLT_PRVDR_ACCT_ID\", " +
                "NVL(TO_CHAR(PREV_TRAN_REG_TOKEN_EXPIR_DT, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"PREV_TRAN_REG_TOKEN_EXPIR_DT\", " +
                "NVL(PREV_TRAN_REG_TOKEN_ID, 'NULL') \"PREV_TRAN_REG_TOKEN_ID\", " +
                "NVL(TO_CHAR(RPLCTN_UPDT_TS, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"RPLCTN_UPDT_TS\", " +
                "NVL(TO_CHAR(TRAN_REG_TOKEN_EXPIR_DT, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"TRAN_REG_TOKEN_EXPIR_DT\", " +
                "NVL(TRAN_REG_TOKEN_ID, 'NULL') \"TRAN_REG_TOKEN_ID\", " +
                "NVL(WLT_PRVDR_DVC_ID, 'NULL') \"WLT_PRVDR_DVC_ID\", " +
                "NVL(TO_CHAR(WLT_PRVDR_ID), 'NULL') \"WLT_PRVDR_ID\" " +
                "FROM DVC_NOTIF " +
                "WHERE DVC_NOTIF_ID = " + dvcNotifId;

        return getResultData(sqlText);
    }
    public static String getQueueMsgException(String queueMgrNam, String suid)
    {
        List<String> matchedMsgs = new ArrayList<String>();
        String sqlText    = "SELECT ";
        sqlText	+= "QUEUE_MGR_NAM, ";
        sqlText	+= "QUEUE_NAM, ";
        sqlText	+= "TO_CHAR(CRTE_TS, 'YYYY/MM/DD HH24:MI:SS') \"CRTE_TS1\", ";
        sqlText	+= "TO_CHAR(CRTE_TS, 'YYYY/MM/DD HH24:MI:SS.FF') \"CRTE_TS2\", ";
        sqlText	+= "MSG, ";
        sqlText	+= "TO_CHAR(QUEUE_MSG_ID) \"QUEUE_MSG_ID\", ";
        sqlText	+= "TO_CHAR(RPLCTN_UPDT_TS, 'YYYY/MM/DD HH24:MI:SS') \"RPLCTN_UPDT_TS1\", ";
        sqlText	+= "TO_CHAR(RPLCTN_UPDT_TS, 'YYYY/MM/DD HH24:MI:SS.FF') \"RPLCTN_UPDT_TS2\" ";
        sqlText	+= "FROM QUEUE_MSG ";
        sqlText	+= "WHERE QUEUE_MGR_NAM = '" + queueMgrNam + "' ";
        sqlText	+= "AND QUEUE_NAM = 'DES.EXCEPTION.REQ' ";
        sqlText	+= "ORDER BY CRTE_TS DESC";
        establishConnection();
        try(Statement stmt=con.createStatement())
        {
            ResultSet results=stmt.executeQuery(sqlText);
            while (results.next()) {
                String msgStr = MiscUtilties.clobStringConversion(results.getClob("MSG"));
                JsonPath jp = new JsonPath(msgStr);
                String resultSuid=jp.getString("suid");
//                LogHandler.print(resultSuid);
                if (suid.equalsIgnoreCase(resultSuid)) {
                    LogHandler.print(" .. MATCH FOUND ... QUEUE_MSG_ID = " + results.getString("QUEUE_MSG_ID"));

                    matchedMsgs.add(msgStr);
                }

            }
        }catch (Exception e)
        {
            assertNull(e.getMessage(),e);
        }
        closeConnection();
        Joiner joiner = Joiner.on("~");
        String str=joiner.join(matchedMsgs);
        return str;
    }

    /**
     *
     * @param tcPanDataEncId
     * @return
     */
    public static  Map<String, String> getEncryptedPanDataCol(String tcPanDataEncId)
    {
        String sqlText =	"SELECT " +
                "PAN_DATA_ENC_ID, " +
                "NVL(ENCRYPT_PAN_DATA,'null') \"ENCRYPT_PAN_DATA\" " +
                "FROM PAN_DATA_ENC " +
                "WHERE PAN_DATA_ENC_ID = '" + tcPanDataEncId + "'";
        Map<Integer,Map> finalMap=getResultData(sqlText);
        int actualValue=finalMap.size();
        int expectedValue=1;
        assertTrue(" row(s) returned in query is [" + actualValue + "], expecting [" + expectedValue + "]",actualValue==expectedValue);

        return finalMap.get(1);
    }

    public static String getEncryptedDataTxtCol(String tcPrvsnRqstId)
    {
        String resultData="";
        String sqlText = "SELECT " +
                "NVL(ENCRYPT_DATA_TXT,'null') \"ENCRYPT_DATA_TXT\" " +
                "FROM PRVSN_RQST " +
                "WHERE PRVSN_RQST_ID = '" +tcPrvsnRqstId + "'";

        establishConnection();
        try(Statement stmt=con.createStatement())
        {
            ResultSet results=stmt.executeQuery(sqlText);

            int count=0;
            while (results.next()) {
                count++;
                resultData=MiscUtilties.clobStringConversion(results.getClob("ENCRYPT_DATA_TXT"));
            }
            int actualValue = count;
            int expectedValue = 1;
            String message="  row(s) returned in query is [" + actualValue + "], expecting [" + expectedValue + "]";
            assertTrue(message,actualValue==expectedValue);
        }catch (Exception e)
        {
            assertNull(e.getMessage(),e);
        }
        closeConnection();
        return resultData;
    }
    public static String getGpRsltTxtCol(String tcPrvsnRqstId)
    {
        String resultData="";
        String sqlText = "SELECT " +
                "NVL(GP_RSLT_TXT,'NULL') \"GP_RSLT_TXT\" " +
                "FROM PRVSN_RQST " +
                "WHERE PRVSN_RQST_ID = '" + tcPrvsnRqstId + "'";
        establishConnection();
        try(Statement stmt=con.createStatement())
        {
            ResultSet results=stmt.executeQuery(sqlText);

            int count=0;
            while (results.next()) {
                count++;
                resultData=MiscUtilties.clobStringConversion(results.getClob("GP_RSLT_TXT"));
            }
            int actualValue = count;
            int expectedValue = 1;
            String message="  row(s) returned in query is [" + actualValue + "], expecting [" + expectedValue + "]";
            assertTrue(message,actualValue==expectedValue);
        }catch (Exception e)
        {
            assertNull(e.getMessage(),e);
        }
        closeConnection();
        return resultData;
    }
    public static Map<Integer, Map> getKeyIds(String idType, String idValue)
    {
        String msgValidValues = "valid values are: DPANID, TKNID or TASKID";
        boolean condition = idType.equalsIgnoreCase("DPANID") ||
                idType.equalsIgnoreCase("TKNID") ||
                idType.equalsIgnoreCase("TASKID");
        assertTrue(msgValidValues, condition);


//validate remaining input properites based on value of 'tcGetById':
        String sqlWhereClause = "";
        switch ( idType ) {

            case "DPANID":
                sqlWhereClause = "AND PDM.DVC_PAN_UNQ_ID = '" + idValue + "' ";
                break;

            case "TKNID":

                sqlWhereClause = "AND PR.AUTHTCN_TOKEN_ID = '" + idValue + "' ";
                break;

            case "TASKID":

                sqlWhereClause = "AND PR.WLT_PRVDR_RQST_ID = '" + idValue + "' ";
                break;
        }

        Map<Integer, Map> fullResultMap=new LinkedHashMap<>();
        String sqlText = "SELECT " +
                "NVL(TO_CHAR(PDM.MAP_ID),'NULL') \"MAP_ID\", " +
                "NVL(TO_CHAR(PDM.PAYMT_APPL_INSTNCE_ID),'NULL') \"PAYMT_APPL_INSTNCE_ID\", " +
                "NVL(TO_CHAR(PDM.WLT_PRVDR_ID),'NULL') \"WLT_PRVDR_ID\", " +
                "NVL(TO_CHAR(PR.PRVSN_RQST_ID),'NULL') \"PRVSN_RQST_ID\", " +
                "NVL(TO_CHAR(PDE.PAN_DATA_ENC_ID),'NULL') \"PAN_DATA_ENC_ID\", " +
                "NVL(TO_CHAR(PDM.TOKEN_RQSTR_ID),'NULL') \"TOKEN_RQSTR_ID\" " +
                "FROM PRVSN_RQST PR, " +
                "PAN_DVC_MAP PDM, " +
                "PAN_DATA_ENC PDE " +
                "WHERE PR.MAP_ID = PDM.MAP_ID " +
                "AND PDM.DVC_PAN_DATA_ENC_ID = PDE.PAN_DATA_ENC_ID " +sqlWhereClause;
        return getResultData(sqlText);
    }
    public static Map<Integer, Map> getGpScrptTxtCol(String prvsnRqstId)
    {

        String sqlText = "SELECT " +
                "NVL(GP_SCRPT_TXT,'NULL') \"GP_SCRPT_TXT\" " +
                "FROM PRVSN_RQST " +
                "WHERE PRVSN_RQST_ID = '" + prvsnRqstId + "'";
        return getResultData(sqlText);
    }

    public static Map<Integer, Map> getMapId(String hashFundPan, String secureElement)
    {
        String sqlText = "SELECT " +
                "NVL(HASH_FUND_PAN,               'NULL') \"HASH_FUND_PAN\", " +
                "NVL(SEC_ELMT_ID,                 'NULL') \"SEC_ELMT_ID\", " +
                "NVL(TO_CHAR(MAP_ID),             'NULL') \"MAP_ID\", " +
                "NVL(TO_CHAR(DVC_PAN_DATA_ENC_ID),'NULL') \"DVC_PAN_DATA_ENC_ID\", " +
                "NVL(TO_CHAR(DVC_ID),             'NULL') \"DVC_ID\" " +
                "FROM PAN_DVC_MAP " +
                "WHERE HASH_FUND_PAN = '" + hashFundPan + "' AND SEC_ELMT_ID = '" + secureElement + "'";

        return getResultData(sqlText);
    }

    public static Map<Integer,Map> getPanDvcMapRow(String tcMapId)
    {
        String sqlText =  "SELECT " +
            "NVL(ACTV_CD,                                            'NULL') \"ACTV_CD\", " +
            "NVL(TO_CHAR(ACTV_CD_ATMPT_CNT),                         'NULL') \"ACTV_CD_ATMPT_CNT\", " +
            "NVL(TO_CHAR(ACTV_CD_EXPIR_DT, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"ACTV_CD_EXPIR_DT\", " +
            "NVL(APPLET_VER_NUM,                                     'NULL') \"APPLET_VER_NUM\", " +
            "NVL(APPL_AID_TXT,                                       'NULL') \"APPL_AID_TXT\", " +
            "NVL(TO_CHAR(CARDLET_ID),                                'NULL') \"CARDLET_ID\", " +
            "NVL(CONFIG_SRC_CD,                                      'NULL') \"CONFIG_SRC_CD\", " +
            "NVL(CONFIG_UUID,                                        'NULL') \"CONFIG_UUID\", " +
            "NVL(TO_CHAR(CRTE_DT,          'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"CRTE_DT\", " +
            "NVL(TO_CHAR(DATA_PREP_PROFL_ID),                        'NULL') \"DATA_PREP_PROFL_ID\", " +
            "NVL(TO_CHAR(DPAN_RNG_STRT_NUM),                         'NULL') \"DPAN_RNG_STRT_NUM\", " +
            "NVL(TO_CHAR(DVC_ID),                                    'NULL') \"DVC_ID\", " +
//            "NVL(TO_CHAR(DVC_NOTIF_ID),                              'NULL') \"DVC_NOTIF_ID\", " +
            "NVL(TO_CHAR(DVC_PAN_DATA_ENC_ID),                       'NULL') \"DVC_PAN_DATA_ENC_ID\", " +
            "NVL(DVC_PAN_EXPIR_DT,                                   'NULL') \"DVC_PAN_EXPIR_DT\",  " +
            "NVL(DVC_PAN_UNQ_ID,                                     'NULL') \"DVC_PAN_UNQ_ID\", " +
            "NVL(TO_CHAR(FPAN_RNG_STRT_NUM),                         'NULL') \"FPAN_RNG_STRT_NUM\", " +
            "NVL(FPAN_SEQ_NUM,                                       'NULL') \"FPAN_SEQ_NUM\", " +
            "NVL(FUND_EXPIR_DT,                                      'NULL') \"FUND_EXPIR_DT\", " +
            "NVL(TO_CHAR(FUND_PAN_DATA_ENC_ID),                      'NULL') \"FUND_PAN_DATA_ENC_ID\", " +
            "NVL(FUND_PAN_UNQ_ID,                                    'NULL') \"FUND_PAN_UNQ_ID\", " +
            "NVL(HASH_DVC_PAN,                                       'NULL') \"HASH_DVC_PAN\", " +
            "NVL(HASH_FUND_PAN,                                      'NULL') \"HASH_FUND_PAN\", " +
            "NVL(HASH_WLT_PRVDR_ACCT_ID,                             'NULL') \"HASH_WLT_PRVDR_ACCT_ID\", " +
            "NVL(MAP_STAT_CD,                                        'NULL') \"MAP_STAT_CD\", " +
            "NVL(TO_CHAR(MAP_STAT_DT, 'YYYY/MM/DD HH24:MI:SS'),      'NULL') \"MAP_STAT_DT\", " +
            "NVL(RECYCLE_DPAN_SW,                                    'NULL') \"RECYCLE_DPAN_SW\", " +
            "NVL(SEC_ELMT_ID,                                        'NULL') \"SEC_ELMT_ID\", " +
            "NVL(SSD_AID_TXT,                                        'NULL') \"SSD_AID_TXT\", " +
            "NVL(TO_CHAR(TERM_COND_ACPT_DT, 'YYYY/MM/DD HH24:MI:SS'),'NULL') \"TERM_COND_ACPT_DT\", " +
            "NVL(TERM_COND_VER_ID,                                   'NULL') \"TERM_COND_VER_ID\", " +
            "NVL(TO_CHAR(WLT_PRVDR_ID),                              'NULL') \"WLT_PRVDR_ID\" " +
            "FROM PAN_DVC_MAP " +
            "WHERE MAP_ID = " + tcMapId;

        return getResultData(sqlText);
    }

    public static Map<Integer,Map> getPrvsnRqstRow(String tcPrvsnRqstId)
    {
        String sqlText =  "SELECT " +
                "NVL(ASYNC_TAM_SENT_SW, 'NULL') \"ASYNC_TAM_SENT_SW\", " +
                "NVL(TO_CHAR(AUTHTCN_TOKEN_EXPIR_DT,'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"AUTHTCN_TOKEN_EXPIR_DT\", " +
                "NVL(AUTHTCN_TOKEN_ID, 'NULL') \"AUTHTCN_TOKEN_ID\", " +
                "NVL(TO_CHAR(CRTE_DT, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"CRTE_DT\", " +
                "NVL(DATA_PREP_OUTPT_TXT, 'NULL') \"DATA_PREP_OUTPT_TXT\", " +
                "NVL(DECSN_ACTV_BY_TXT, 'NULL') \"DECSN_ACTV_BY_TXT\", " +
                "NVL(DVC_LOC_TXT, 'NULL') \"DVC_LOC_TXT\", " +
                "NVL(ENCRYPT_DATA_TXT, 'NULL') \"ENCRYPT_DATA_TXT\", " +
                "NVL(FPAN_SRC_CD, 'NULL') \"FPAN_SRC_CD\", " +
                "NVL(GP_RSLT_TXT, 'NULL') \"GP_RSLT_TXT\", " +
                "NVL(GP_RSLT_TXT_ENC_SW, 'NULL') \"GP_RSLT_TXT_ENC_SW\", " +
                "NVL(GP_SCRPT_TXT, 'NULL') \"GP_SCRPT_TXT\", " +
                "NVL(IDV_DECSN_MADE_BY_CD, 'NULL') \"IDV_DECSN_MADE_BY_CD\", " +
                "NVL(TO_CHAR(IDV_DECSN_RULE_ID), 'NULL') \"IDV_DECSN_RULE_ID\", " +
                "NVL(TO_CHAR(IDV_DECSN_TS,          'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"IDV_DECSN_TS\", " +
                "NVL(IDV_DECSN_TXT, 'NULL') \"IDV_DECSN_TXT\", " +
                "NVL(LANG_CD, 'NULL') \"LANG_CD\", " +
                "NVL(TO_CHAR(MAP_ID), 'NULL') \"MAP_ID\", " +
                "NVL(PKG_DLVR_ID, 'NULL') \"PKG_DLVR_ID\", " +
                "NVL(TO_CHAR(PKG_DLVR_TS, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"PKG_DLVR_TS\", " +
                "NVL(TO_CHAR(PRVSN_CHNG_RQST_DT,    'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"PRVSN_CHNG_RQST_DT\", " +
                "NVL(PRVSN_CHNG_RSN_TXT, 'NULL') \"PRVSN_CHNG_RSN_TXT\", " +
//                "NVL(PRVSN_EXCP_CD, 'NULL') \"PRVSN_EXCP_CD\", " +
                "NVL(TO_CHAR(PRVSN_RQST_ID), 'NULL') \"PRVSN_RQST_ID\", " +
                "NVL(PRVSN_STAT_CD, 'NULL') \"PRVSN_STAT_CD\", " +
                "NVL(TO_CHAR(PRVSN_STAT_DT, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"PRVSN_STAT_DT\", " +
                "NVL(PRVSN_TYPE_CD, 'NULL') \"PRVSN_TYPE_CD\", " +
                "NVL(PUT_PEND_RESP_DATA, 'NULL') \"PUT_PEND_RESP_DATA\", " +
                "NVL(REP_ID, 'NULL') \"REP_ID\", " +
                "NVL(REP_NAM, 'NULL') \"REP_NAM\", " +
                "NVL(REP_ORG_NAM, 'NULL') \"REP_ORG_NAM\", " +
                "NVL(RESP_LOC_TXT, 'NULL') \"RESP_LOC_TXT\", " +
                "NVL(TO_CHAR(RPLCTN_UPDT_TS, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"RPLCTN_UPDT_TS\", " +
                "NVL(TO_CHAR(TERM_COND_ACPT_RCV_TS, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"TERM_COND_ACPT_RCV_TS\", " +
                "NVL(TO_CHAR(WLT_PRVDR_HTTP_RESP_CD), 'NULL') \"WLT_PRVDR_HTTP_RESP_CD\", " +
                "NVL(TO_CHAR(WLT_PRVDR_ID), 'NULL') \"WLT_PRVDR_ID\", " +
                "NVL(WLT_PRVDR_RCMND_DECSN_TXT, 'NULL') \"WLT_PRVDR_RCMND_DECSN_TXT\", " +
                "NVL(TO_CHAR(WLT_PRVDR_RESP_SEC_CNT), 'NULL') \"WLT_PRVDR_RESP_SEC_CNT\", " +
                "NVL(TO_CHAR(WLT_PRVDR_RQST_ID), 'NULL') \"WLT_PRVDR_RQST_ID\" " +
                "FROM PRVSN_RQST " +
                "WHERE PRVSN_RQST_ID = " + tcPrvsnRqstId;

        return getResultData(sqlText);
    }

    public static Map<Integer,Map> getTranRow(String tcMapId,String tcTranId,String tcNtwrkRefNum,String tcWltPrvdrTranId)
    {

        String whereClause = "WHERE ";
        if ( !tcMapId.equalsIgnoreCase("CONDITIONAL") ) { whereClause += "MAP_ID = " + tcMapId+" AND "; }
        if ( !tcTranId.equalsIgnoreCase("CONDITIONAL") ) { whereClause += "TRAN_ID = " + tcTranId+" AND "; }
        if ( !tcNtwrkRefNum.equalsIgnoreCase("CONDITIONAL") ) { whereClause += "NTWRK_REF_NUM = '" + tcNtwrkRefNum + "' AND " ;}
        if ( !tcWltPrvdrTranId.equalsIgnoreCase("CONDITIONAL") ) { whereClause += "WLT_PRVDR_TRAN_ID = '" + tcWltPrvdrTranId + "' "; }
        String sqlText =  "SELECT " +
                "NVL(ACQ_INST_ID, 'NULL') \"ACQ_INST_ID\", " +
                "NVL(AUTH_RESP_CD, 'NULL') \"AUTH_RESP_CD\", " +
                "NVL(TO_CHAR(CRTE_TS, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"CRTE_TS\", " +
                "NVL(CURR_ALPHA_CD, 'NULL') \"CURR_ALPHA_CD\", " +
                "NVL(FWD_INST_ID, 'NULL') \"FWD_INST_ID\", " +
                "NVL(TO_CHAR(LOC_DT, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"LOC_DT\", " +
                "NVL(TO_CHAR(MAP_ID), 'NULL') \"MAP_ID\", " +
                "NVL(TO_CHAR(MERCH_CAT_CD), 'NULL') \"MERCH_CAT_CD\", " +
                "NVL(MERCH_NAM, 'NULL') \"MERCH_NAM\", " +
                "NVL(MTI_CD, 'NULL') \"MTI_CD\", " +
                "NVL(NTWRK_REF_NUM, 'NULL') \"NTWRK_REF_NUM\", " +
                "NVL(RAW_MERCH_NAM, 'NULL') \"RAW_MERCH_NAM\", " +
                "NVL(TO_CHAR(RPLCTN_UPDT_TS, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"RPLCTN_UPDT_TS\", " +
                "NVL(TO_CHAR(SETL_DT, 'YYYY/MM/DD'), 'NULL') \"SETL_DT\", " +
                "NVL(SYS_TRACE_AUDIT_NUM, 'NULL') \"SYS_TRACE_AUDIT_NUM\", " +
                "NVL(TO_CHAR(TRAN_AMT), 'NULL') \"TRAN_AMT\", " +
                "NVL(TO_CHAR(TRAN_ID), 'NULL') \"TRAN_ID\", " +
                "NVL(TRAN_SRC_CD, 'NULL') \"TRAN_SRC_CD\", " +
                "NVL(TRAN_STAT_CD, 'NULL') \"TRAN_STAT_CD\", " +
                "NVL(TRAN_SUB_STAT_CD, 'NULL') \"TRAN_SUB_STAT_CD\", " +
                "NVL(TO_CHAR(TRAN_TS, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"TRAN_TS\", " +
                "NVL(TRAN_TYPE_CD, 'NULL') \"TRAN_TYPE_CD\", " +
                "NVL(TO_CHAR(TRAN_UPDT_TS, 'YYYY/MM/DD HH24:MI:SS'), 'NULL') \"TRAN_UPDT_TS\", " +
                "NVL(WLT_PRVDR_TRAN_ID, 'NULL') \"WLT_PRVDR_TRAN_ID\" " +
                "FROM TRAN " + whereClause;

        return getResultData(sqlText);
    }

    /**
     *
     * @param sqlQuery
     * @return
     */
    private static Map<Integer,Map> getResultData(String sqlQuery)
    {
        Map<Integer, Map> fullResultMap=new LinkedHashMap<>();
        establishConnection();
        try(Statement stmt=con.createStatement())
        {
            LogHandler.print("EXECUTING '(" + sqlQuery + ")'");
            ResultSet results=stmt.executeQuery(sqlQuery);
            LogHandler.print("COMPLETED EXECUTING'(" + sqlQuery+ ")'");
            Integer recordCount = 0;
            Map<String,Object> resultRowMap=null;
            ResultSetMetaData rsmd = results.getMetaData();
            int columnCount = rsmd.getColumnCount();
            while (results.next())
            {
                recordCount++;
                resultRowMap=new LinkedHashMap<>();
                for (int i = 1; i <= columnCount; i++) {
                    String columnName=rsmd.getColumnName(i);
                   String[] str= columnName.split("_");
                    String key="tcx";
                    for (String c:str) {
                       String s=c.substring(0,1)+c.substring(1, c.length()).toLowerCase();
                        key+=s;
                    }
                    resultRowMap.put(key,results.getObject(columnName));
                }
                fullResultMap.put(recordCount,resultRowMap);
            }

            stmt.close();
        }catch (Exception e)
        {
//            e.printStackTrace();
            assertNull(e.getMessage(),e);

        }
        closeConnection();
        return fullResultMap;
    }

}


