package com.mastercard.mdes.test.automation.core.mdes_utilities;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.mastercard.mdes.test.automation.core.LogHandler;
import com.mastercard.mdes.test.automation.core.PropertyHandler;

import static com.jayway.restassured.RestAssured.given;

/*
 * Created by E055238 on 3/1/2016.
 */


public class CaasServiceUtil {

    private String mdesUtilitiesBaseUrl;
    private String baseUrl;

    public enum EncodingType {
        HEX, BASE64
    }

    public enum HashingAlgorithm {
        SHA256, SHA512
    }

    CaasServiceUtil() {

        try {
            mdesUtilitiesBaseUrl = PropertyHandler.getEnvironmentProperty("mdesUtilitiesEndpoint");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            baseUrl = RestAssured.baseURI;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String encrypt(String unencryptedText) {
        System.out.println(baseUrl);
        System.out.println(mdesUtilitiesBaseUrl);

        RestAssured.baseURI = mdesUtilitiesBaseUrl;
        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .queryParam("text", unencryptedText)
                .when()
                .post("/caas/encrypt");

        resetRestAssured();

        return response.asString();
    }

    public String decrypt(String encryptedText) {
        RestAssured.baseURI = mdesUtilitiesBaseUrl;
        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .queryParam("text", encryptedText)
                .when()
                .post("/caas/decrypt");

        resetRestAssured();

        return response.asString();
    }


    public String wrappedEncrypt(EncodingType encodingType, String cardInfo, String iv,
                                 HashingAlgorithm hashingAlgorithm, String certString) {

        RestAssured.baseURI = mdesUtilitiesBaseUrl;
        Response wrappedEncryptResponse =  given()
                .queryParam("fieldEncoding", encodingType)
                .queryParam("text", cardInfo)
                .queryParam("hexInitializationVector", iv)
                .queryParam("hashAlgorithm", hashingAlgorithm)
                .queryParam("certificate", certString)
                .when()
                .post("/wrappedEncrypt/raw");

        resetRestAssured();

        return wrappedEncryptResponse.asString();
    }

    public String wrappedDecryptUsingEncryptedPrivateKey(EncodingType encodingType, String encryptedData,
                                                         String encryptedKey, String encryptedPrivateKey,
                                                         String iv, HashingAlgorithm hashingAlgorithm) {

        RestAssured.baseURI = mdesUtilitiesBaseUrl;
        Response wrappedDecryptResponse = given()
                .urlEncodingEnabled(true)
                .contentType("application/x-www-form-urlencoded")
                .queryParam("fieldEncoding", encodingType)
                .queryParam("encryptedText", encryptedData)
                .queryParam("wrappedKey", encryptedKey)
                .queryParam("encryptedPrivateKey", encryptedPrivateKey)
                .queryParam("initializationVector", iv)
                .queryParam("hashingAlgorithm", hashingAlgorithm)
                .when()
                .post("/caas/wrappedDecrypt");

        resetRestAssured();

        return wrappedDecryptResponse.asString();
    }

    public String wrappedDecryptUsingFingerprint(EncodingType encodingType, String encryptedData,
                                                         String encryptedKey, String unwrappingKeyFingerprint,
                                                         String iv, HashingAlgorithm hashingAlgorithm) {

        RestAssured.baseURI = mdesUtilitiesBaseUrl;
        Response wrappedDecryptResponse = given()
                .urlEncodingEnabled(true)
                .contentType("application/x-www-form-urlencoded")
                .queryParam("fieldEncoding", encodingType)
                .queryParam("encryptedText", encryptedData)
                .queryParam("wrappedKey", encryptedKey)
                .queryParam("unwrappingKeyFingerprint", unwrappingKeyFingerprint)
                .queryParam("initializationVector", iv)
                .queryParam("hashingAlgorithm", hashingAlgorithm)
                .when()
                .post("/caas/wrappedDecrypt");

        resetRestAssured();

        return wrappedDecryptResponse.asString();
    }

    public String hash(String value) {
        String returnVal = com.mastercard.mdes.utility.common.util.crypto.HashPanUtil.hash(value);
        LogHandler.print(returnVal);

        return returnVal;
    }

    private void resetRestAssured(){

        RestAssured.reset();
        RestAssured.baseURI = baseUrl;
    }

}