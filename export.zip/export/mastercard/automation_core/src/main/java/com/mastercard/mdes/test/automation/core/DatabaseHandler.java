package com.mastercard.mdes.test.automation.core;

import org.junit.BeforeClass;
import org.junit.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Created by E055238 on 7/27/2015.
 */

public class DatabaseHandler {

    public static Connection getDbConnection() throws Exception {

        Connection con = null;
        String connectionString = null;

        try {
            connectionString = PropertyHandler.getEnvironmentProperty("dbConnectionString");
        } catch (Exception e) {
            System.out.println("Unable to get property value for connectionString");
        }

        try {
            con =  DriverManager.getConnection(connectionString);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return con;
    }


    public static void testDatabaseConnection() throws Exception {
        Connection con = getDbConnection();
        con.close();
        LogHandler.print("Established DB Connection");
    }


}
