package com.mastercard.mdes.test.automation.core.request_builder.cs_api_v2;

/**
 * Created by John Kalbac E055238 on 1/25/2016.
 */
public class SearchRequest {

    private String accountPan;
    private String paymentAppInstanceId;
    private String commentId;
    private String token;
    private String tokenUniqueReference;
    private String excludeDeletedIndicator;
    private String userId;
    private String userName;
    private String organization;
    private String phone;

    public SearchRequest accountPan(String accountPan) {
        this.accountPan = accountPan;
        return this;
    }

    public SearchRequest paymentAppInstanceId(String paymentAppInstanceId) {
        this.paymentAppInstanceId = paymentAppInstanceId;
        return this;
    }

    public SearchRequest commentId(String commentId) {
        this.commentId = commentId;
        return this;
    }

    public SearchRequest token(String token) {
        this.token = token;
        return this;
    }

    public SearchRequest tokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
        return this;
    }

    public SearchRequest excludeDeletedIndicator(String excludeDeletedIndicator) {
        this.excludeDeletedIndicator = excludeDeletedIndicator;
        return this;
    }

    public SearchRequest userId(String userId) {
        this.userId = userId;
        return this;
    }

    public SearchRequest userName(String userName) {
        this.userName = userName;
        return this;
    }

    public SearchRequest organization(String organization) {
        this.organization = organization;
        return this;
    }

    public SearchRequest phone(String phone) {
        this.phone = phone;
        return this;
    }


    public SearchRequest allDefaults() {
        accountPan = "";
        paymentAppInstanceId = "";
        commentId = "";
        token = "";
        tokenUniqueReference = "";
        excludeDeletedIndicator = "TRUE";
        userId = "AutomatedTest";
        userName = "AutomatedTest";
        organization = "MasterCard";
        phone = "5551234567";
        return this;
    }


    public String build() {
        return  "<SearchRequest>" +
                "    <AccountPan>" + accountPan + "</AccountPan>" +
                "    <PaymentAppInstanceId>" + paymentAppInstanceId + "</PaymentAppInstanceId>" +
                "    <CommentId>" + commentId + "</CommentId>" +
                "    <Token>" + token + "</Token>" +
                "    <TokenUniqueReference>" + tokenUniqueReference + "</TokenUniqueReference>" +
                "    <ExcludeDeletedIndicator>" + excludeDeletedIndicator + "</ExcludeDeletedIndicator>" +
                "    <AuditInfo>" +
                "        <UserId>" + userId + "</UserId>" +
                "        <UserName>" + userName + "</UserName>" +
                "        <Organization>" + organization + "</Organization>" +
                "        <Phone>" + phone + "</Phone>" +
                "    </AuditInfo>" +
                "</SearchRequest>";
    }




   }
