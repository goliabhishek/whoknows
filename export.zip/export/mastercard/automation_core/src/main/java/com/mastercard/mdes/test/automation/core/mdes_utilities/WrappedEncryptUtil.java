package com.mastercard.mdes.test.automation.core.mdes_utilities;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.mastercard.mdes.test.automation.core.PropertyHandler;

import static com.jayway.restassured.RestAssured.given;

/**
 * Created by e062683 on 3/2/2016.
 */
public class WrappedEncryptUtil {
    private String mdesUtilitiesBaseUrl;
    private String baseUrl;
    WrappedEncryptUtil() {
        try {
            mdesUtilitiesBaseUrl = PropertyHandler.getEnvironmentProperty("mdesUtilitiesEndpoint");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            baseUrl = PropertyHandler.getEnvironmentProperty("baseUrl");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String applePayWrappedEncrypt(String fpan,String expiryMonth, String expiryYear, String cvc2,String fpanId, String devicenumber,String certString) {
        RestAssured.baseURI = mdesUtilitiesBaseUrl;

        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .queryParam("fpan", fpan)
                .queryParam("expiryMonth", expiryMonth)
                .queryParam("expiryYear", expiryYear)
                .queryParam("cvc2", cvc2)
                .queryParam("fpanId", fpanId)
                .queryParam("devicenumber", devicenumber)
                .queryParam("certificate", certString)


                .when()
                .post("/wrappedEncrypt/applePay");

        RestAssured.reset();
        RestAssured.baseURI = baseUrl;

        return response.asString();
    }
    public String mcbpWrappedEncrypt(String hexinitializationVector,String hashingAlgorithm,String fpan,String expiryMonth, String expiryYear, String cardHolderName,String source, String securityCode,String expirationTimeStamp,String addressLine1,String addressLine2,String city,String countrySubdivision,String postalCode,String country,String certString) {
        RestAssured.baseURI = mdesUtilitiesBaseUrl;

        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .queryParam("hexinitializationVector", hexinitializationVector)
                .queryParam("hashingAlgorithm", hashingAlgorithm)
                .queryParam("fpan", fpan)
                .queryParam("expiryMonth", expiryMonth)
                .queryParam("expiryYear", expiryYear)
                .queryParam("cardHolderName", cardHolderName)
                .queryParam("source", source)
                .queryParam("securityCode", securityCode)
                .queryParam("expirationTimeStamp", expirationTimeStamp)
                .queryParam("addressLine1", addressLine1)
                .queryParam("addressLine2", addressLine2)
                .queryParam("city", city)
                .queryParam("countrySubdivision", countrySubdivision)
                .queryParam("postalCode", postalCode)
                .queryParam("country", country)
                .queryParam("certificate", certString)


                .when()
                .post("/wrappedEncrypt/mcbp");

        RestAssured.reset();
        RestAssured.baseURI = baseUrl;

        return response.asString();
    }

}
