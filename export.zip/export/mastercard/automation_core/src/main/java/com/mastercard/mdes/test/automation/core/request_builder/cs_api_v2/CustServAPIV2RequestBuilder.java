package com.mastercard.mdes.test.automation.core.request_builder.cs_api_v2;

/**
 * Created by John Kalbac E055238 on 1/25/2016.
 */
public class CustServAPIV2RequestBuilder {

    public static ActivateRequest activateRequest() {
        return new ActivateRequest();
    }

    public static ActivationMethodsRequest activationMethodsRequest() {
        return new ActivationMethodsRequest();
    }

    public static CommentsRequest commentsRequest() {
        return new CommentsRequest();
    }

    public static DeleteRequest deleteRequest() {
        return new DeleteRequest();
    }

    public static ResendActivationCodeRequest resendActivationCodeRequest() {
        return new ResendActivationCodeRequest();
    }

    public static ResetMobilePinRequest resetMobilePinRequest() {
        return new ResetMobilePinRequest();
    }

    public static SearchRequest searchRequest() {
        return new SearchRequest();
    }

    public static StatusHistoryRequest statusHistoryRequest() {
        return new StatusHistoryRequest();
    }

    public static SuspendRequest suspendRequest() {
        return new SuspendRequest();
    }

    public static TransactionsRequest transactionsRequest() {
        return new TransactionsRequest();
    }

    public static UnsuspendRequest unsuspendRequest() {
        return new UnsuspendRequest();
    }

    public static UpdateRequest updateRequest() {
        return new UpdateRequest();
    }
}
