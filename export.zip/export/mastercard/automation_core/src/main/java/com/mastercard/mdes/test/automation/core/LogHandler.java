package com.mastercard.mdes.test.automation.core;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.path.xml.XmlPath;
import com.jayway.restassured.response.Response;
import com.mastercard.mdes.test.automation.core.mdes_utilities.MDESUtilities;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;



import java.util.Map;

/**
 * Created by E055238 on 7/31/2015.
 */
public class LogHandler {

    private static final Logger logger = LogManager.getLogger("com.mc.logger1");
    private static final Logger reportlogger = LogManager.getLogger("com.mc.logger2");

    public static void printTestInitHeader() {
        String testName = Thread.currentThread().getStackTrace()[2].getMethodName();
        logger.info("**************************************");
        logger.info(" Starting Test: {}", testName);
    }


    public static void printTestFinishedHeader() {
        logger.info(" Test Complete!");
        logger.info("**************************************");
    }

    public static void prettyPrintResponse(Response r) {
        logger.info(" Response Value:");
        logger.info(r.getStatusLine());

        try {
            JsonPath js = new JsonPath(r.asString());
            // Use JsonPath prettify() here to avoid double-printing the response to the console.
            logger.info("\n" + js.prettify());
        } catch (Exception e) {
            logger.info(r.asString());
        }
    }

    public static void prettyPrintResponseXml(Response r) {
        logger.info(" Response Value:");
        try {
            XmlPath xml = new XmlPath(r.asString());
            logger.info("\n" + xml.prettify());
        } catch (Exception e) {
            logger.info(r.asString());
        }

    }

    public static void prettyPrintRequest(String r) {
        logger.info(" Request Value:");
        logger.info("\n" + r);
    }

    public static void prettyPrintRequestXml(String r) {
        logger.info(" Request Value:");
        String formatted = MDESUtilities.formatXml(r);
        logger.info("\n" + formatted);
    }

    public static void print(String s) {
        logger.info(s);
    }

    public static void printToReport(String s) {reportlogger.info(s);}

    public static void printMQMessageBody(String msg) {
        logger.info(" MQ Message Body:");
        JsonPath js = new JsonPath(msg);
        logger.info("\n" + js.prettify());
    }

    public static void printDatabaseRecords(Map results) {

        /**
         *  This needs to handle maps with both a single record result and multiple records
         */
        if (results.containsKey(1)) {
            for (Integer i = 1; i <= results.size(); i++) {
                Map record = (Map) results.get(i);
                String recordFormatted = "";
                try {
                    recordFormatted = new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, true)
                            .writerWithDefaultPrettyPrinter().writeValueAsString(record);
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                }

                logger.info("\n" + " Record Number " + i.toString() + "\n" + recordFormatted);
            }
        } else {
            String recordFormatted = "";
            try {
                recordFormatted = new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, true)
                        .writerWithDefaultPrettyPrinter().writeValueAsString(results);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }

            logger.info("\n" + recordFormatted);
        }
    }
}
