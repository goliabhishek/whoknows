package com.mastercard.mdes.test.automation.core.mdes_utilities;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.mastercard.mdes.test.automation.core.PropertyHandler;

import static com.jayway.restassured.RestAssured.given;

/**
 * Created by e062683 on 3/3/2016.
 */
public class TavCreationUtil {


    private String mdesUtilitiesBaseUrl;
    private String baseUrl;
    TavCreationUtil() {
        try {
            mdesUtilitiesBaseUrl = PropertyHandler.getEnvironmentProperty("mdesUtilitiesEndpoint");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            baseUrl = PropertyHandler.getEnvironmentProperty("baseUrl");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    baseUrl = "http://ech-10-157-130-38.mastercard.int:8080";

    public String createTav(String version, String fpan, String fpanExpiry, String dpanId, String signatureKeyAlias) {
        RestAssured.baseURI = mdesUtilitiesBaseUrl;

        Response response = given()
                .contentType("application/x-www-form-urlencoded")
                .queryParam("version", version)
                .queryParam("fpan", fpan)
                .queryParam("fpanExpiry", fpanExpiry)
                .queryParam("dpanId", dpanId)
                .queryParam("signatureKeyAlias", signatureKeyAlias)

                .when()
                .post("/tav/create");

        RestAssured.reset();
        RestAssured.baseURI = baseUrl;

        return response.asString();
    }

}
