package com.mastercard.mdes.automation.manitoba_regression.tests.functional.createToken;

import com.mastercard.mdes.automation.manitoba_regression.support.Constants;
import com.mastercard.mdes.automation.manitoba_regression.tests.FunctionalTests;
import com.mastercard.mdes.test.automation.core.*;
import com.mastercard.mdes.test.automation.core.db_comparison.ExcelHandler;
import com.mastercard.mdes.test.automation.core.db_comparison.MiscUtilties;
import com.mastercard.mdes.test.automation.core.db_comparison.PrvsnRqstCadFailComparisonTool;
import com.mastercard.mdes.test.automation.core.mdes_utilities.MDESUtilities;
import com.mastercard.mdes.test.automation.core.request_builder.JsonObjectMapper;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenParser;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenUtil;
import org.easetech.easytest.annotation.DataLoader;
import org.easetech.easytest.annotation.Param;
import org.easetech.easytest.loader.LoaderType;
import org.easetech.easytest.runner.DataDrivenTestRunner;
import org.junit.Assume;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.assertTrue;

/**
 * Created by e062683 on 8/31/2016.
 */



@Category(FunctionalTests.class)
@RunWith(DataDrivenTestRunner.class)
@DataLoader(filePaths={Constants.PATH_FUNCTIONAL_CREATETOKEN+"/testCreateTokenWhiteListAndHaltProvisionValidation.xls"}, loaderType= LoaderType.EXCEL, writeData=false)

public class CreateTokenWhiteListAndHaltProvisionValidationTest {

    //standard definitions (tester to update):
    static private String wltPrdvrId;
    static private String fpanHash;

    static private String RELATIVE_PATH = Constants.PATH_FUNCTIONAL_CREATETOKEN;
    static private String TEST_METHOD_NAME = "testCreateTokenWhiteListAndHaltProvisionValidation";

    static private String WltPrdvrId ;

    //standard definitions (do not update):
    static private String DATASOURCE_PATH = Constants.PATH_RESOURCES + "/" + RELATIVE_PATH + "/" + TEST_METHOD_NAME + ".xls";

    static private Map fullDataMap;

    //testcase specific definitions:
    private static final boolean LOG_TRUE = true;
    private Map<String, Object> excelRow;
    private Map<String, String> excelRowStr;

    private CreateTokenUtil crteTknUtil;
    private Map<String, String> crteTknReqMap;
    private Map<String, String> crteTknRspMap;
    private Map<String, String> crteTknMiscMap;
    static private String rowNumToBeExcecuted;


    @BeforeClass
    public static void setUp() throws Exception {
        LogHandler.debugPrint(DATASOURCE_PATH);
        fullDataMap = ExcelHandler.generateFullRecordMapFromExcel(DATASOURCE_PATH);
        ReportLogUtils.logTestName(Constants.PROJECT, RELATIVE_PATH, TEST_METHOD_NAME);
        wltPrdvrId = PropertyHandler.getEnvironmentProperty("manitobaDefaultWltPrvdrId");

    }

    @Test
    public void testCreateTokenWhiteListAndHaltProvisionValidation(@Param(name = "inTestNbr") String inTestNbr) throws Exception   {

        loadExcelRow(inTestNbr);
        if(excelRowStr.get("genFpanHash").equals("Y")) {
            generateFpanHash();
        }

        updateAcctRngMdesParm();
        if(excelRowStr.get("inHashInsert").equals("Y")) {
            insAcctRngWhiteCard();
        }

        if(excelRowStr.get("inDelWLRecord").equals("Y")) {
            delAcctRngWhiteCard();
        }
        createTokenRestCall();
        resetChanges();
        validateCreateTokenRsp();

        if(excelRowStr.get("ValidatePrvsnRqstCadFailCount").equals("Y"))
        {
            validatePrvsnRqstCadFailRow();
        }

    }

    private void loadExcelRow(String inTestNbr) {
        excelRow = MiscUtilties.createExcelRowMap(fullDataMap, TEST_METHOD_NAME, inTestNbr);
        Assume.assumeTrue(TestUtils.isTestRunnable(inTestNbr, excelRow.get("inExec"), rowNumToBeExcecuted));
        excelRowStr = JsonObjectMapper.createStringStringMap(excelRow);
        LogHandler.debugPrint("excelRowStr=" + excelRowStr.toString());
        ReportLogUtils.logTestRowDesc(excelRowStr);
    }


    private void createTokenRestCall() throws Exception {

        LogHandler.debugPrint("createTokenRestCall");

        // Set util inputs and run
        CreateTokenUtil.create()

                .setInDbResetIndicator(excelRowStr.get("inDbResetIndicator"))
                .setInDbResetFpan(excelRowStr.get("inFpanCardDescDataFpan"))
                .setinFpanCardDescDataFpan(excelRowStr.get("inFpanCardDescDataFpan"))
                .setinFpanCardDescDataExpiry(excelRowStr.get("inFpanCardDescDataExpiry"))
                .setInHttpHdrSysUserId(excelRowStr.get("inHttpHdrSysUserId"))
                .setInSeid(excelRowStr.get("inSeid"))
                .setInHttpHdrXpod(excelRowStr.get("inHttpHdrXPod"))
                .run();

        // Get outputs
        crteTknReqMap = crteTknUtil.getOutRequestMap();
        crteTknRspMap = crteTknUtil.getOutResponseMap();
        crteTknMiscMap = crteTknUtil.getOutMiscellaneousMap();
    }


    private void validateCreateTokenRsp() throws Exception {
        final String EXP_PREFIX = "expRsp.";
        Map<String, String> expectedMap = MiscUtilties.extractByPrefix(excelRow, EXP_PREFIX);


        CreateTokenParser.validateResponse(
                EXP_PREFIX,
                expectedMap,
                crteTknRspMap);
    }

    private void updateAcctRngMdesParm() throws Exception {
        Map<String,String> map = new LinkedHashMap<>();
    //printing table name before reseting hlt prvsn dvc sw to N
        map.put("HALT_PRVSN_DVC_SW",excelRowStr.get("HaltPvsnDvcSw"));
        map.put("HALT_PRVSN_COF_SW",excelRowStr.get("HaltPvsnCOFSw"));

        DataUtils.updAcctRngMdesParm(
                excelRowStr.get("refRngStartNum"),
                map,
                LOG_TRUE);

        }

    private void resetChanges() throws Exception {
        if(excelRowStr.get("HaltPvsnDvcSw").equals("Y")) {
            Map<String, String> map = new LinkedHashMap<>();
            map.put("HALT_PRVSN_DVC_SW", "N");
            map.put("HALT_PRVSN_COF_SW", "N");
            //printing table name after reseting hlt prvsn dvc sw to N
            DataUtils.updAcctRngMdesParm(excelRowStr.get("refRngStartNum"), map, LOG_TRUE);
        }

    }

    private void generateFpanHash() throws Exception {

        fpanHash = MDESUtilities.hash(excelRow.get("inFpanCardDescDataFpan").toString());
        LogHandler.debugPrint("FPAN HASH : "+fpanHash);
        LogHandler.reportPrint("FPAN HASH : "+fpanHash);
    }

    private void insAcctRngWhiteCard() throws Exception {
        String rngStrtNum = excelRow.get("refRngStartNum").toString();

       DataUtils.insertAcctRngWhiteCard(fpanHash,rngStrtNum,wltPrdvrId, LOG_TRUE);


    }

    private void delAcctRngWhiteCard() throws Exception {

        DataUtils.removeAcctRngWhiteCardRecord(excelRowStr.get("refRngStartNum").toString(), LOG_TRUE);
    }

    public void insertAcctRngWhiteCard(String fpanHash,String rngStrtNum,String wltprvderId,boolean inLogUpdate) throws Exception {
        assert fpanHash != null;
        assert rngStrtNum != null;
        assert wltprvderId != null;
        assertTrue("rngStrtNum=["+rngStrtNum+"], length != 19!", rngStrtNum.length() == 19);


        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        jdbcTemplate.update("Insert into ACCT_RNG_WHITE_CARD " +
                "   (HASH_FUND_PAN, RNG_STRT_NUM, WLT_PRVDR_ID )  " +
                " Values " +
                "   (?, ?, ?)",fpanHash ,rngStrtNum,wltprvderId);

    }



    public void removeAcctRngWhiteCardRecord(String rngStrtNum,boolean inLogUpdate) throws Exception {
        assert rngStrtNum != null;
        assertTrue("rngStrtNum=["+rngStrtNum+"], length != 19!", rngStrtNum.length() == 19);
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        jdbcTemplate.update("DELETE FROM ACCT_RNG_WHITE_CARD  WHERE RNG_STRT_NUM=? ",rngStrtNum );
    }

    private void validatePrvsnRqstCadFailRow() throws Exception {

        String timeBeforeRestCall = crteTknMiscMap.get("before.SYSTIMEDATETIMEMS");

        PrvsnRqstCadFailComparisonTool prcfCompare = new PrvsnRqstCadFailComparisonTool();
        Map<String,String> map = new LinkedHashMap<>();
        map.put("FPAN_SRC_CD","UNDEFINED");
        map.put("RQST_TYPE_CD","create_token");
        map.put("FAIL_RSN_CD","card_eligibility");
        map.put("RQST_STAT_CD","FAIL");
        map.put("TOKEN_TYPE_CD","SE");
        map.put("RPLCTN_UPDT_TS >",timeBeforeRestCall.substring(0,timeBeforeRestCall.length()-7)+":00.000000");

        List<Map<String, Object>> cadFailList = DataUtils.getPrvsnRqstCadFailByMap(excelRowStr.get("inFpanCardDescDataFpan"),map, LOG_TRUE);
        LogHandler.debugPrint("Size:"+cadFailList.size());
        LogHandler.reportPrint("Size:"+cadFailList.size());
        assertTrue("Record count is not equal to One",cadFailList.size() == 1);

        int count = prcfCompare.retrieveAfterRecordUsingMapAndStartTime(
                excelRowStr.get("refRngStrtNum"),
                map,
                crteTknMiscMap.get("before.SYSDATETIME"),
                LOG_TRUE);
        AssertionUtility.equals("count", excelRowStr.get("expCnt.Prcf"), count);
    }

}
