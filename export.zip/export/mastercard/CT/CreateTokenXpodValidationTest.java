package com.mastercard.mdes.automation.manitoba_regression.tests.functional.createToken;

import com.mastercard.mdes.automation.manitoba_regression.support.Constants;
import com.mastercard.mdes.automation.manitoba_regression.tests.FunctionalTests;
import com.mastercard.mdes.test.automation.core.LogHandler;
import com.mastercard.mdes.test.automation.core.PropertyHandler;
import com.mastercard.mdes.test.automation.core.ReportLogUtils;
import com.mastercard.mdes.test.automation.core.TestUtils;
import com.mastercard.mdes.test.automation.core.db_comparison.DvcComparisionTool;
import com.mastercard.mdes.test.automation.core.db_comparison.ExcelHandler;
import com.mastercard.mdes.test.automation.core.db_comparison.MiscUtilties;
import com.mastercard.mdes.test.automation.core.request_builder.JsonObjectMapper;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenParser;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenUtil;
import org.easetech.easytest.annotation.DataLoader;
import org.easetech.easytest.annotation.Param;
import org.easetech.easytest.loader.LoaderType;
import org.easetech.easytest.runner.DataDrivenTestRunner;
import org.junit.Assume;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;

import java.util.Map;


/**
 * Created by E055798 on 8/15/2016.
 */

@Category(FunctionalTests.class)
@RunWith(DataDrivenTestRunner.class)
@DataLoader(filePaths={Constants.PATH_FUNCTIONAL_CREATETOKEN+"/testCreateTokenXPodValidation.xls"}, loaderType= LoaderType.EXCEL, writeData=false)

public class CreateTokenXpodValidationTest {

    //standard definitions (tester to update):
    static private String RELATIVE_PATH = Constants.PATH_FUNCTIONAL_CREATETOKEN;
    static private String TEST_METHOD_NAME = "testCreateTokenXPodValidation";
    static private String WltPrdvrId ;

    //standard definitions (do not update):
    static private String DATASOURCE_PATH = Constants.PATH_RESOURCES + "/" + RELATIVE_PATH + "/" + TEST_METHOD_NAME + ".xls";
    //datasourcePath = "src/test/resources/input_validation/CreateTokenInputValidation.xls";

    static private Map fullDataMap;

    //testcase specific definitions:
    private static final boolean LOG_TRUE = true;
    private Map<String, Object> excelRow;
    private Map<String, String> excelRowStr;

    private CreateTokenUtil crteTknUtil;
    private Map<String, String> crteTknReqMap;
    private Map<String, String> crteTknRspMap;
    private Map<String, String> crteTknMiscMap;
    static private String rowNumToBeExcecuted;


    @BeforeClass
    public static void setUp() throws Exception {
        LogHandler.debugPrint(DATASOURCE_PATH);
        fullDataMap = ExcelHandler.generateFullRecordMapFromExcel(DATASOURCE_PATH);
        ReportLogUtils.logTestName(Constants.PROJECT, RELATIVE_PATH, TEST_METHOD_NAME);

    }

    @Test
    public void testCreateTokenXPodValidation(@Param(name = "inTestNbr") String inTestNbr) throws Exception   {

        loadExcelRow(inTestNbr);
        createTokenRestCall();
        validateCreateTokenRsp();
        validateDvc();

    }

    private void loadExcelRow(String inTestNbr) {
        excelRow = MiscUtilties.createExcelRowMap(fullDataMap, TEST_METHOD_NAME, inTestNbr);
        Assume.assumeTrue(TestUtils.isTestRunnable(inTestNbr, excelRow.get("inExec"), rowNumToBeExcecuted));
        excelRowStr = JsonObjectMapper.createStringStringMap(excelRow);
        LogHandler.debugPrint("excelRowStr=" + excelRowStr.toString());
        ReportLogUtils.logTestRowDesc(excelRowStr);
    }


    private void createTokenRestCall() throws Exception {
        CreateTokenUtil.create()
            .setInHttpHdrXpod(excelRowStr.get("inHttpHdrXPod"))
            .setInDbResetIndicator("Y")
            .setInDbResetFpan(excelRowStr.get("inFpanCardDescDataFpan"))
            .setInDbResetFpan(excelRowStr.get("inFpanCardDescDataFpan"))
            .setinFpanCardDescDataFpan(excelRowStr.get("inFpanCardDescDataFpan"))
            .setinFpanCardDescDataExpiry(excelRowStr.get("inFpanCardDescDataExpiry"))
            .setInHttpHdrSysUserId(excelRowStr.get("inHttpHdrSysUserId"))
            .setInSeid(excelRowStr.get("inSeid"))
            .run();



        //getters:
        crteTknReqMap = crteTknUtil.getOutRequestMap();
        crteTknRspMap = crteTknUtil.getOutResponseMap();
        crteTknMiscMap = crteTknUtil.getOutMiscellaneousMap();
    }

    private void validateCreateTokenRsp() throws Exception {
        final String EXP_PREFIX = "expRsp.";
        Map<String, String> expectedMap = MiscUtilties.extractByPrefix(excelRow, EXP_PREFIX);


        CreateTokenParser.validateResponse(
                EXP_PREFIX,
                expectedMap,
                crteTknRspMap);
    }

    private void validateDvc() throws Exception {
        WltPrdvrId = PropertyHandler.getEnvironmentProperty("manitobaDefaultWltPrvdrId");
        DvcComparisionTool dvcCompare = new DvcComparisionTool();
        String expPrefix = "expdvc.";

        //ToDo: see if there is another SoapUI testcase which does in-depth validation ... if not ...
        //      may want to update this testcase:

        //retrieve record:
        int count = dvcCompare.retrieveAfterRecordBySeId(
                excelRowStr.get("inSeid"),
                WltPrdvrId,
                LOG_TRUE);
        //AssertionUtility.equals("count", excelRowStr.get("expCnt.Pr"), count);

        //validate record:
        if (count == 1) {
            //append run-time expected values:

            dvcCompare.validateInsertLite(expPrefix, excelRow);
        }
    }


}
