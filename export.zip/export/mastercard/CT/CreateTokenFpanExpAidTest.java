
package com.mastercard.mdes.automation.manitoba_regression.tests.functional.createToken;

import com.mastercard.mdes.automation.manitoba_regression.support.Constants;
import com.mastercard.mdes.automation.manitoba_regression.tests.FunctionalTests;
import com.mastercard.mdes.test.automation.core.*;
import com.mastercard.mdes.test.automation.core.db_comparison.ExcelHandler;
import com.mastercard.mdes.test.automation.core.db_comparison.MiscUtilties;
import com.mastercard.mdes.test.automation.core.request_builder.JsonObjectMapper;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenParser;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenUtil;
import org.apache.commons.collections.MapUtils;
import org.easetech.easytest.annotation.DataLoader;
import org.easetech.easytest.annotation.Param;
import org.easetech.easytest.loader.LoaderType;
import org.easetech.easytest.runner.DataDrivenTestRunner;
import org.junit.Assume;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import static org.junit.Assert.assertTrue;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by E055798 on 9/2/2016.
 */


@Category(FunctionalTests.class)
@RunWith(DataDrivenTestRunner.class)
@DataLoader(filePaths={Constants.PATH_FUNCTIONAL_CREATETOKEN+"/testCreateTokenFpanExpAid.xls"}, loaderType= LoaderType.EXCEL, writeData=false)

public class CreateTokenFpanExpAidTest {

    static private String wltPrdvrId;
    //standard definitions (tester to update):
    static private String RELATIVE_PATH = Constants.PATH_FUNCTIONAL_CREATETOKEN;
    static private String TEST_METHOD_NAME = "testCreateTokenFpanExpAid";
    //standard definitions (do not update):
    static private String DATASOURCE_PATH = Constants.PATH_RESOURCES + "/" + RELATIVE_PATH + "/" + TEST_METHOD_NAME + ".xls";
    static private Map fullDataMap;
    //testcase specific definitions:
    private static final boolean LOG_TRUE = true;
    private Map<String, Object> excelRow;
    private Map<String, String> excelRowStr;

    private CreateTokenUtil crteTknUtil;
    private Map<String, String> crteTknReqMap;
    private Map<String, String> crteTknRspMap;
    private Map<String, String> crteTknMiscMap;
    static private String rowNumToBeExcecuted;


    @BeforeClass
    public static void setUp() throws Exception {
        LogHandler.debugPrint(DATASOURCE_PATH);
        fullDataMap = ExcelHandler.generateFullRecordMapFromExcel(DATASOURCE_PATH);
        wltPrdvrId = PropertyHandler.getEnvironmentProperty("manitobaDefaultWltPrvdrId");
        ReportLogUtils.logTestName(Constants.PROJECT, RELATIVE_PATH, TEST_METHOD_NAME);
    }

    @Test
    public void testCreateTokenFpanExpAid(@Param(name = "inTestNbr") String inTestNbr) throws Exception   {

        loadExcelRow(inTestNbr,TEST_METHOD_NAME);
        updateAcctRngMdesParm();
        printAcctRngMdesParm();
        Map<String,String> getSysDate = DBDateUtils.getSysDate();
        String curDate= getSysDate.get("SYSTIMEDATETIMEMS");
        LogHandler.debugPrint("*****************************************"+curDate);
        createTokenRestCall();
        validateCreateTokenRsp();
        ResetAcctRngMdesParm();
        chkDVCCount();
        chkPanDvcMapCnt();
       /* if(excelRowStr.get("ValidatePDM").equals("Y")) {
            validatePDM();
        }
*/

    }



    private void loadExcelRow(String inTestNbr,String testMethodName) {
        excelRow = MiscUtilties.createExcelRowMap(fullDataMap, testMethodName, inTestNbr);
        Assume.assumeTrue(TestUtils.isTestRunnable(inTestNbr, excelRow.get("inExec"), rowNumToBeExcecuted));
        excelRowStr = JsonObjectMapper.createStringStringMap(excelRow);
        LogHandler.debugPrint("excelRowStr=" + excelRowStr.toString());
        ReportLogUtils.logTestRowDesc(excelRowStr);
    }


    private void createTokenRestCall() throws Exception {

        CreateTokenUtil.create()
                .setInDbResetIndicator("Y")
                .setInDbResetFpan(excelRowStr.get("inFpanCardDescDataFpan"))
                .setinFpanCardDescDataFpan(excelRowStr.get("inFpanCardDescDataFpan"))
                .setinFpanCardDescDataExpiry(excelRowStr.get("inFpanCardDescDataExpiry"))
                .setInHttpHdrXpod(excelRowStr.get("inHttpHdrXPod"))
                .setInHttpHdrSysUserId(excelRowStr.get("inHttpHdrSysUserId"))
                .setInSsdDescAppletInstanceAid(excelRowStr.get("inAppletInstanceAid"))
                .setInSsdDescAppletVersionNumber(excelRowStr.get("inAppletVersionNumber"))
                .setInSeid(excelRowStr.get("inSeid"))
                .run();



        //getters:
        crteTknReqMap = crteTknUtil.getOutRequestMap();
        crteTknRspMap = crteTknUtil.getOutResponseMap();
        crteTknMiscMap = crteTknUtil.getOutMiscellaneousMap();

    }

    private void validateCreateTokenRsp() throws Exception {
        final String EXP_PREFIX = "expRsp.";
        Map<String, String> expectedMap = MiscUtilties.extractByPrefix(excelRow, EXP_PREFIX);


        CreateTokenParser.validateResponse(
                EXP_PREFIX,
                expectedMap,
                crteTknRspMap);
    }

    private void updateAcctRngMdesParm() throws Exception {

        Map<String, String> map = new LinkedHashMap<>();

        String inCardLenNum = excelRowStr.get("UpdCardLenNum");
        if (inCardLenNum != null && !inCardLenNum.isEmpty() && !inCardLenNum.trim().isEmpty()) {
            if (inCardLenNum.equals("Y")) {
                map.put("CARD_LEN_NUM", excelRowStr.get("inCardLenNum"));
            }
        }
        String updLuhnchkReqd = excelRowStr.get("UpdLuhnchkReqd");
        if (updLuhnchkReqd != null && !updLuhnchkReqd.isEmpty() && !updLuhnchkReqd.trim().isEmpty()) {
            if (updLuhnchkReqd.equals("Y")) {
                map.put("LUHN_CHK_REQD_SW", excelRowStr.get("inLuhnchkReqd"));
            }
        }

        String updExpDtPrsntOnCardSw = excelRowStr.get("UpdExpDtPrsntOnCardSw");
        if (updExpDtPrsntOnCardSw != null && !updExpDtPrsntOnCardSw.isEmpty() && !updExpDtPrsntOnCardSw.trim().isEmpty()) {
            if (updExpDtPrsntOnCardSw.equals("Y")) {
                map.put("EXPIRY_DT_PRSNT_ON_CARD_SW", excelRowStr.get("inExpDtPrsntOnCardSw"));
            }
        }

        String UpdAlpha2CntryCodetoBlank = excelRowStr.get("UpdAlpha2CntryCodetoBlank");
        if (UpdAlpha2CntryCodetoBlank != null && !UpdAlpha2CntryCodetoBlank.isEmpty() && !UpdAlpha2CntryCodetoBlank.trim().isEmpty()) {
            if (UpdAlpha2CntryCodetoBlank.equals("Y")) {
                map.put("ALPHA2_CNTRY_CD", "");
            }
        }
        //printing table name before reseting hlt prvsn dvc sw to N

        if (!MapUtils.isEmpty(map)) {

            DataUtils.updAcctRngMdesParm(
                    excelRowStr.get("inAccountRange"),
                    map,
                    LOG_TRUE);

        }
    }

    private void ResetAcctRngMdesParm() throws Exception {
        Map<String, String> map = new LinkedHashMap<>();
        String UpdAlpha2CntryCodetoBlank = excelRowStr.get("UpdAlpha2CntryCodetoBlank");
        if (UpdAlpha2CntryCodetoBlank != null && !UpdAlpha2CntryCodetoBlank.isEmpty() && !UpdAlpha2CntryCodetoBlank.trim().isEmpty()) {
            if (UpdAlpha2CntryCodetoBlank.equals("Y")) {
                map.put("ALPHA2_CNTRY_CD", "US");
            }

            if (!MapUtils.isEmpty(map)) {

                DataUtils.updAcctRngMdesParm(
                        excelRowStr.get("inAccountRange"),
                        map,
                        LOG_TRUE);

            }
        }
    }


    private void printAcctRngMdesParm() throws Exception {

        DataUtils.getAcctRngMdesParmList(excelRowStr.get("inAccountRange"),LOG_TRUE);

    }

    private void chkDVCCount() throws Exception {

        List<Map<String, Object>>resultList = DataUtils.getDvcListBySeidAndWID(excelRowStr.get("inSeid"),wltPrdvrId,LOG_TRUE);
        assertTrue("Number of Records that are changed are "+Integer.toString(resultList.size())+" not Equal to Expected",excelRowStr.get("expDVCCnt").equals(Integer.toString(resultList.size())));
        LogHandler.debugPrint("");
    }
    private void chkPanDvcMapCnt() throws Exception {

        Map<String,String> map = new LinkedHashMap<>();
        map.put("DVC_PAN_UNQ_ID",crteTknRspMap.get("createTokenResponse.dpanId"));
        map.put("PAYMT_APPL_INSTNCE_ID",excelRowStr.get("inSeid"));

        List<Map<String, Object>> resultList = DataUtils.getPanDvcMapByMap(map,LOG_TRUE);
        assertTrue("Number of Records that are changed are "+Integer.toString(resultList.size())+" not Equal to Expected",excelRowStr.get("expPDMCnt").equals(Integer.toString(resultList.size())));


    }
    private void validatePDM() throws Exception {
        // we will work on this later
        LogHandler.debugPrint("");

    }





}














