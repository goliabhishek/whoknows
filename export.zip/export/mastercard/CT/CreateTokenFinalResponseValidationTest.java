package com.mastercard.mdes.automation.manitoba_regression.tests.functional.createToken;

import com.mastercard.mdes.automation.manitoba_regression.support.Constants;
import com.mastercard.mdes.automation.manitoba_regression.tests.FunctionalTests;
import com.mastercard.mdes.test.automation.core.*;
import com.mastercard.mdes.test.automation.core.db_comparison.ExcelHandler;
import com.mastercard.mdes.test.automation.core.db_comparison.MiscUtilties;
import com.mastercard.mdes.test.automation.core.request_builder.JsonObjectMapper;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenParser;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenUtil;
import org.apache.commons.lang.StringUtils;
import org.easetech.easytest.annotation.DataLoader;
import org.easetech.easytest.annotation.Param;
import org.easetech.easytest.loader.LoaderType;
import org.easetech.easytest.runner.DataDrivenTestRunner;
import org.junit.Assume;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertTrue;

/**
 * Created by E055798 on 9/13/2016.
 */



@Category(FunctionalTests.class)
@RunWith(DataDrivenTestRunner.class)
@DataLoader(filePaths={Constants.PATH_FUNCTIONAL_CREATETOKEN+"/testCreateTokenFinalResponseValidation.xls"}, loaderType= LoaderType.EXCEL, writeData=false)

public class CreateTokenFinalResponseValidationTest {



    //standard definitions (tester to update):
    static private String RELATIVE_PATH = Constants.PATH_FUNCTIONAL_CREATETOKEN;
    static private String TEST_METHOD_NAME = "testCreateTokenFinalResponseValidation";


    //standard definitions (do not update):
    static private String DATASOURCE_PATH = Constants.PATH_RESOURCES + "/" + RELATIVE_PATH + "/" + TEST_METHOD_NAME + ".xls";
    static private Map fullDataMap;

    //testcase specific definitions:
    private final boolean LOG_YES = true;
    private static final boolean LOG_TRUE = true;
    private Map<String, Object> excelRow;
    private Map<String, String> excelRowStr;
    private CreateTokenUtil crteTknUtil;
    private Map<String, String> crteTknReqMap;
    private Map<String, String> crteTknRspMap;
    private Map<String, String> crteTknMiscMap;
    static private String rowNumToBeExcecuted;


    @BeforeClass
    public static void setUp() throws Exception {
        LogHandler.debugPrint(DATASOURCE_PATH);
        fullDataMap = ExcelHandler.generateFullRecordMapFromExcel(DATASOURCE_PATH);
        ReportLogUtils.logTestName(Constants.PROJECT, RELATIVE_PATH, TEST_METHOD_NAME);

    }

    @Test
    public void testCreateTokenFinalResponseValidation(@Param(name = "inTestNbr") String inTestNbr) throws Exception   {
        loadExcelRow(inTestNbr,TEST_METHOD_NAME);
        updateAcctRngMdesParm();
        prtDpanAcctRange();
        createTokenRestCall();
        validateCreateTokenRsp();
    }


    private void loadExcelRow(String inTestNbr,String testMethodName) {
        excelRow = MiscUtilties.createExcelRowMap(fullDataMap, testMethodName, inTestNbr);
        Assume.assumeTrue(TestUtils.isTestRunnable(inTestNbr, excelRow.get("inExec"), rowNumToBeExcecuted));
        excelRowStr = JsonObjectMapper.createStringStringMap(excelRow);
        LogHandler.debugPrint("");
        LogHandler.debugPrint("");
        LogHandler.debugPrint("excelRowStr=" + excelRowStr.toString());
        ReportLogUtils.logTestRowDesc(excelRowStr);
    }


    private void createTokenRestCall() throws Exception {
        CreateTokenUtil.create()

            .setInHttpHdrXpod(excelRowStr.get("inHttpHdrXPod"))
            .setInDbResetIndicator("Y")
            .setInDbResetFpan(excelRowStr.get("inFpanCardDescDataFpan"))
            .setinFpanCardDescDataFpan(excelRowStr.get("inFpanCardDescDataFpan"))
            .setinFpanCardDescDataExpiry(excelRowStr.get("inFpanCardDescDataExpiry"))
            .setInSsdDescAppletInstanceAid(excelRowStr.get("inAppletInstanceAid"))
            .setInSsdDescAppletVersionNumber(excelRowStr.get("inAppletVersionNumber"))
            .setInSeid(excelRowStr.get("inSeid"))
            .run();


        crteTknReqMap = crteTknUtil.getOutRequestMap();
        crteTknRspMap = crteTknUtil.getOutResponseMap();
        crteTknMiscMap = crteTknUtil.getOutMiscellaneousMap();
    }

    private void validateCreateTokenRsp() throws Exception {

        Map<String, String> PDMrecord = validatePanDvcMap();

        final String EXP_PREFIX = "expRsp.";
        Map<String, String> expectedMap = MiscUtilties.extractByPrefix(excelRow, EXP_PREFIX);
        Map<String, String> newExpectedMap = expectedMap;

        String dpanSuffix = crteTknMiscMap.get("tokenPan").substring(crteTknMiscMap.get("tokenPan").length() - 4);
        AssertionUtility.equals("DpanId",PDMrecord.get("DVC_PAN_UNQ_ID") , crteTknRspMap.get("createTokenResponse.dpanId"));
        AssertionUtility.equals("DpanSuffix", dpanSuffix, crteTknRspMap.get("createTokenResponse.dpanSuffix"));
        AssertionUtility.equals("PersoScriptRequestId", crteTknMiscMap.get("dbPkgDlvrId"), crteTknRspMap.get("createTokenResponse.persoScriptRequestIdentifier"));
        AssertionUtility.equals("ConversationId", crteTknMiscMap.get("dbconversationId"), crteTknRspMap.get("responseHeader.conversationId"));
        AssertionUtility.equals("ResponseId", crteTknMiscMap.get("dbresponseId"), crteTknRspMap.get("responseHeader.responseId"));

        CreateTokenParser.validateResponse(
                EXP_PREFIX,
                expectedMap,
                crteTknRspMap);

    }



    private void updateAcctRngMdesParm() throws Exception {
        Map<String, String> map = new LinkedHashMap<>();
        map.put("ACPT_BRND_ID",excelRowStr.get("inAcctRngMdesAcptBrndId"));
        map.put("EXPIRY_DT_PRSNT_ON_CARD_SW", excelRowStr.get("inExpiryDtPrsntOnCardSw"));
        DataUtils.updAcctRngMdesParm(excelRowStr.get("refRngStartNum"), map, LOG_TRUE);
    }




    private void prtDpanAcctRange() throws Exception {
        Map<String, String> map = new LinkedHashMap<>();
        map.put("FPAN_RNG_STRT_NUM",excelRowStr.get("refRngStartNum"));
        List<Map<String, Object>>dpanAcctRngRec = DataUtils.getDpanAcctRngList(map, LOG_TRUE);
        LogHandler.debugPrint("No of Rows Fetched : " + dpanAcctRngRec.size());
    }

    private Map<String, String> validatePanDvcMap() throws Exception {
        LogHandler.debugPrint("Validating PANDVCMAP Table ");
        Map<String,String> map = new LinkedHashMap<>();

        List<Map<String, Object>> PDMrecList = DataUtils.getPanDvcMapListByMapId(crteTknMiscMap.get("dbMapId"),LOG_TRUE);
        int count =PDMrecList.size();

        LogHandler.debugPrint("Number of records Based on FpanHash and Seid : "+Integer.toString(count));
        Map<String, String> record = null;
        AssertionUtility.equals("Number of records Based on FpanHash and Seid are not equal to One",excelRowStr.get("expPDMCount"),count);

        if (count == 1) {
            record = JsonObjectMapper.createStringStringMap(PDMrecList.get(0));
        }

        return record;
    }




}
