package com.mastercard.mdes.automation.manitoba_regression.tests.functional.createToken;

import com.mastercard.mdes.automation.manitoba_regression.support.Constants;
import com.mastercard.mdes.automation.manitoba_regression.tests.FunctionalTests;
import com.mastercard.mdes.test.automation.core.*;
import com.mastercard.mdes.test.automation.core.db_comparison.ExcelHandler;
import com.mastercard.mdes.test.automation.core.db_comparison.MiscUtilties;
import com.mastercard.mdes.test.automation.core.mdes_utilities.MDESUtilities;
import com.mastercard.mdes.test.automation.core.request_builder.JsonObjectMapper;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenParser;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenUtil;
import org.easetech.easytest.annotation.DataLoader;
import org.easetech.easytest.annotation.Param;
import org.easetech.easytest.loader.LoaderType;
import org.easetech.easytest.runner.DataDrivenTestRunner;
import org.junit.Assume;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertTrue;

/**
 * Created by e062683 on 9/7/2016.
 */

@Category(FunctionalTests.class)
@RunWith(DataDrivenTestRunner.class)
@DataLoader(filePaths={Constants.PATH_FUNCTIONAL_CREATETOKEN+"/testCreateTokenConcurrentReq.xls"}, loaderType= LoaderType.EXCEL, writeData=false)


public class CreateTokenConcurrentReqTest {

    //standard definitions (tester to update):
    static private String RELATIVE_PATH = Constants.PATH_FUNCTIONAL_CREATETOKEN;
    static private String TEST_METHOD_NAME = "testCreateTokenConcurrentReq";

    //standard definitions (do not update):
    static private String DATASOURCE_PATH = Constants.PATH_RESOURCES + "/" + RELATIVE_PATH + "/" + TEST_METHOD_NAME + ".xls";
    static private Map fullDataMap;

    //testcase specific definitions:
    private Map<String, Object> excelRow;
    private Map<String, String> excelRowStr;
    private CreateTokenUtil crteTknUtil;
    private Map<String, String> crteTknRspMap;
    private Map<String, String> crteTknMiscMap;
    private String fpanHash;
    private String mthdUniqRefId;
    static private String rowNumToBeExcecuted;
    private Map<String,String> dbMap = new LinkedHashMap<>();

    @BeforeClass
    public static void setUp() throws Exception {
        LogHandler.debugPrint(DATASOURCE_PATH);
        fullDataMap = ExcelHandler.generateFullRecordMapFromExcel(DATASOURCE_PATH);
        ReportLogUtils.logTestName(Constants.PROJECT, RELATIVE_PATH, TEST_METHOD_NAME);
    }

    @Test
    public void testCreateTokenConcurrentReq(@Param(name = "inTestNbr") String inTestNbr) throws Exception   {
        loadExcelRow(inTestNbr);
        DbResetUtil.deleteMappingBySeid(excelRowStr.get("inSeid"), Constants.DFLT_MANITOBA_WALLET_PRVDR_ID);
        getFpanHash();
        insertMthdCurPrcssRow();
        createTokenRestCall();
        validateConcurrentResp();
        deleteMthdCurPrcssRow();
        createTokenRestCall();
        validateNonConcurrentResp();
    }

    private void loadExcelRow(String inTestNbr) {
        LogHandler.debugPrint("loadExcelRow="+inTestNbr);
        excelRow = MiscUtilties.createExcelRowMap(fullDataMap, TEST_METHOD_NAME, inTestNbr);
        Assume.assumeTrue(TestUtils.isTestRunnable(inTestNbr, excelRow.get("inExec"), rowNumToBeExcecuted));
        excelRowStr = JsonObjectMapper.createStringStringMap(excelRow);
        LogHandler.debugPrint("excelRowStr=" + excelRowStr.toString());
        ReportLogUtils.logTestRowDesc(excelRowStr);
    }
    private void createTokenRestCall() throws Exception {
        CreateTokenUtil.create()
                .setInDbResetFpan(excelRowStr.get("inFpan"))
                .setInSeid(excelRowStr.get("inSeid"))
                .setinFpanCardDescDataFpan(excelRowStr.get("inFpan"))
                .setinFpanCardDescDataExpiry(excelRowStr.get("inExpiry"))
                .run();

        //getters:
        crteTknRspMap = crteTknUtil.getOutResponseMap();
        crteTknMiscMap = crteTknUtil.getOutMiscellaneousMap();
    }
    private void insertMthdCurPrcssRow() throws Exception {
        delMthdCurPrcssRow();
        insMthdCurPrcssRow();
        printMthdCurPrcssRow();
    }
    private void deleteMthdCurPrcssRow() throws Exception {
        delMthdCurPrcssRow();
        printMthdCurPrcssRow();
    }
    private void validateNonConcurrentResp() throws Exception {
        AssertionUtility.equals("statusCode", crteTknRspMap.get("http.statusCode"), "200");
        AssertionUtility.doesNotContainKey("Retry-After", "Hdr.Retry-After", crteTknRspMap);

        final String EXP_PREFIX = "expRsp.";
        Map<String, String> expectedMap = new LinkedHashMap<>();
        expectedMap.put("expRsp.hdr.statusCode","200");
        expectedMap.put("expRsp.ctr.dpanId","PRESENT");
        CreateTokenParser.validateResponse(
                EXP_PREFIX,
                expectedMap,
                crteTknRspMap);

        chkPanDvcMapCnt(1);
    }

    private void getFpanHash() throws Exception {

        fpanHash = MDESUtilities.hash(excelRow.get("inFpan").toString());
        mthdUniqRefId = fpanHash + excelRowStr.get("inExpiry") +excelRowStr.get("inSeid");
        LogHandler.debugPrint("FPAN HASH : "+fpanHash);
        LogHandler.reportPrint("FPAN HASH : "+fpanHash);
        LogHandler.debugPrint("mthdUniqRefId : "+mthdUniqRefId);
        LogHandler.reportPrint("mthdUniqRefId : "+mthdUniqRefId);
    }


    private void insMthdCurPrcssRow() throws Exception {
        DataUtils.insertMthdCurPrcc("APPLE_CT",mthdUniqRefId,Constants.LOG_NO);
    }

    private void delMthdCurPrcssRow() throws Exception {
        DataUtils.removeMthdCurPrccRecord("APPLE_CT",mthdUniqRefId,Constants.LOG_NO);
    }

    private void printMthdCurPrcssRow() throws Exception {
        dbMap.clear();
        dbMap.put("MTHD_TYPE_CD","APPLE_CT");
        DataUtils.getMthdCurPrcssByMap(dbMap,Constants.LOG_YES);
    }

    private void validateConcurrentResp() throws Exception {
        String retryAfter;

        AssertionUtility.equals("statusCode", crteTknRspMap.get("http.statusCode"), "503");
        retryAfter = AssertionUtility.containsKey("Retry-After","Hdr.Retry-After",crteTknRspMap);
        AssertionUtility.equals("Retry-After","5",retryAfter);
        chkPanDvcMapCnt(0);
    }

    private void chkPanDvcMapCnt(int inCount) throws Exception {
        dbMap.clear();
        dbMap.put("PAYMT_APPL_INSTNCE_ID",excelRowStr.get("inSeid"));
        List<Map<String, Object>> resultList = DataUtils.getPanDvcMapByMap(dbMap,Constants.LOG_YES);
        AssertionUtility.equals("PAN_DVC_MAP count",inCount, resultList.size());

    }


}
















