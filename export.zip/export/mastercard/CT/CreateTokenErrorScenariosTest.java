package com.mastercard.mdes.automation.manitoba_regression.tests.functional.createToken;

import com.mastercard.mdes.automation.manitoba_regression.support.Constants;
import com.mastercard.mdes.automation.manitoba_regression.tests.FunctionalTests;
import com.mastercard.mdes.test.automation.core.DataUtils;
import com.mastercard.mdes.test.automation.core.LogHandler;
import com.mastercard.mdes.test.automation.core.PropertyHandler;
import com.mastercard.mdes.test.automation.core.ReportLogUtils;
import com.mastercard.mdes.test.automation.core.TestUtils;
import com.mastercard.mdes.test.automation.core.db_comparison.ExcelHandler;
import com.mastercard.mdes.test.automation.core.db_comparison.MiscUtilties;
import com.mastercard.mdes.test.automation.core.request_builder.JsonObjectMapper;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenParser;
import com.mastercard.mdes.test.automation.core.request_builder.manitoba.createToken.CreateTokenUtil;
import org.easetech.easytest.annotation.DataLoader;
import org.easetech.easytest.annotation.Param;
import org.easetech.easytest.loader.LoaderType;
import org.easetech.easytest.runner.DataDrivenTestRunner;
import org.junit.After;
import org.junit.Assume;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;

import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.Assert.assertTrue;

/**
 * Created by e062683 on 8/10/2016.
 */


@Category(FunctionalTests.class)
@RunWith(DataDrivenTestRunner.class)
@DataLoader(filePaths={Constants.PATH_FUNCTIONAL_CREATETOKEN+"/testCreateTokenErrorScenarios.xls"}, loaderType= LoaderType.EXCEL, writeData=false)
public class CreateTokenErrorScenariosTest {


    static private String manitobaDefaultSysUser;
    static private String manitobaAltSysUser;
    static private String manitobaInvalidSysUserId;
    static private String wltPrdvrId;
    static private String storageTypeCd;
    static private String tknTypeCd;

    //standard definitions (tester to update):
    static private String RELATIVE_PATH = Constants.PATH_FUNCTIONAL_CREATETOKEN;
    static private String TEST_METHOD_NAME = "testCreateTokenErrorScenarios";

    //standard definitions (do not update):
    static private String DATASOURCE_PATH = Constants.PATH_RESOURCES+"/"+RELATIVE_PATH+"/"+TEST_METHOD_NAME+".xls";
    static private Map fullDataMap;

    //testcase specific definitions:
    private static final boolean LOG_TRUE = true;
    private Map<String,Object> excelRow;
    private Map<String,String> excelRowStr;

    private CreateTokenUtil crteTknUtil;
    private Map<String,String> crteTknReqMap;
    private Map<String,String> crteTknRspMap;
    private Map<String,String> crteTknMiscMap;
    static private String rowNumToBeExcecuted;



    @BeforeClass
    public static void setUp() throws Exception {
        LogHandler.debugPrint(DATASOURCE_PATH);
        fullDataMap = ExcelHandler.generateFullRecordMapFromExcel(DATASOURCE_PATH);
        manitobaDefaultSysUser = PropertyHandler.getEnvironmentProperty("manitobaDefaultSysUser");
        manitobaAltSysUser = PropertyHandler.getEnvironmentProperty("manitobaAltSysUser");
        manitobaInvalidSysUserId = PropertyHandler.getEnvironmentProperty("manitobaInvalidSysUserId");
        wltPrdvrId = PropertyHandler.getEnvironmentProperty("manitobaDefaultWltPrvdrId");
        storageTypeCd = PropertyHandler.getEnvironmentProperty("manitobaDefaultStrgTypeCode");
        tknTypeCd = PropertyHandler.getEnvironmentProperty("manitobaDefaultTknTypeCode");
        ReportLogUtils.logTestName(Constants.PROJECT, RELATIVE_PATH, TEST_METHOD_NAME);

        // Perform a pre-check to validate the APPL_USER configuration is correct for these tests
        checkApplUserConfiguration();
        printRequiredTables();

        //DataUtils.printWltPrvdrDvcType(wltPrdvrId);

    }

    @After
    public void resetToDefaults() throws Exception {
                resetTknStrgType();
    }

    @Test
    public void testCreateTokenErrorScenarios(@Param(name = "inTestNbr") String inTestNbr) throws Exception {

        loadExcelRow(inTestNbr);
        if(excelRowStr.get("UpdWltPrvdrDvcTypeTBl").equals("Y")) {
            updateWltPrvdrDvcType();
        }
        if(excelRowStr.get("UpdNtwrkDvcTypeLkp").equals("Y")) {
            updateNtwrkDvcTypeLkp();
        }

        createTokenRestCall();

        if(excelRowStr.get("DuplicateRequest").equals("Y")) {
            createTokenRestCall1();
        }
        validateCreateTokenRsp();
        //crteTknUtil.setInHttpHdrSysUserId(excelRowStr.get("inHttpHdrSysUserId"));

    }



    private void loadExcelRow(String inTestNbr) {
        excelRow = MiscUtilties.createExcelRowMap(fullDataMap, TEST_METHOD_NAME, inTestNbr);
        Assume.assumeTrue(TestUtils.isTestRunnable(inTestNbr, excelRow.get("inExec"),rowNumToBeExcecuted));
        excelRowStr = JsonObjectMapper.createStringStringMap(excelRow);
        LogHandler.debugPrint("excelRowStr="+excelRowStr.toString());
        ReportLogUtils.logTestRowDesc(excelRowStr);
    }

    private void createTokenRestCall() throws Exception {
        crteTknUtil = new CreateTokenUtil();
        LogHandler.debugPrint("createTokenRestCall");

        // Set util inputs and run
        crteTknUtil
                .setInDbResetIndicator(excelRowStr.get("inDbResetIndicator"))
                .setInDbResetFpan(excelRowStr.get("inFpanCardDescDataFpan"))
                .setInFpanCardDescKeyInfoWrappedKey(excelRowStr.get("inFpanCardDescKeyInfoWrappedKey"))
                .setInFpanCardDescEncryptedData(excelRowStr.get("inFpanCardDescEncryptedData"))
                .setinFpanCardDescDataFpanId(excelRowStr.get("inFpanCardDescDataFpanId"))
                .setInFpanCardDescUnencryptedData(excelRowStr.get("inFpanCardDescUnencryptedData"))
                .setinFpanCardDescDataFpan(excelRowStr.get("inFpanCardDescDataFpan"))
                .setinFpanCardDescDataExpiry(excelRowStr.get("inFpanCardDescDataExpiry"))
                .setInHttpHdrSysUserId(excelRowStr.get("inHttpHdrSysUserId"))
                .setInHttpHdrXpod(excelRowStr.get("inHttpHdrXPod"))
                .setInSeid(excelRowStr.get("inSeid"))
                .run();

        // Get outputs
        crteTknReqMap = crteTknUtil.getOutRequestMap();
        crteTknRspMap = crteTknUtil.getOutResponseMap();
        crteTknMiscMap = crteTknUtil.getOutMiscellaneousMap();
    }

    private void createTokenRestCall1() throws Exception {

        LogHandler.debugPrint("createTokenRestCall");

        // Set util inputs and run
        CreateTokenUtil.create()
                .setInHttpHdrXpod(excelRowStr.get("inHttpHdrXPod"))
                .setInDbResetIndicator("N")
                .setInFpanCardDescKeyInfoWrappedKey(excelRowStr.get("inFpanCardDescKeyInfoWrappedKey"))
                .setInFpanCardDescEncryptedData(excelRowStr.get("inFpanCardDescEncryptedData"))
                .setinFpanCardDescDataFpanId(excelRowStr.get("inFpanCardDescDataFpanId"))
                .setInFpanCardDescUnencryptedData(excelRowStr.get("inFpanCardDescUnencryptedData"))
                .setinFpanCardDescDataFpan(excelRowStr.get("inFpanCardDescDataFpan"))
                .setinFpanCardDescDataExpiry(excelRowStr.get("inFpanCardDescDataExpiry"))
                .setInHttpHdrSysUserId(excelRowStr.get("inHttpHdrSysUserId"))
                .setInSeid(excelRowStr.get("inSeid"))
                .run();

        // Get outputs
        crteTknReqMap = crteTknUtil.getOutRequestMap();
        crteTknRspMap = crteTknUtil.getOutResponseMap();
        crteTknMiscMap = crteTknUtil.getOutMiscellaneousMap();
    }

    private void validateCreateTokenRsp() throws Exception {
        final String EXP_PREFIX = "expRsp.";
        Map<String,String> expectedMap = MiscUtilties.extractByPrefix(excelRow, EXP_PREFIX);


        CreateTokenParser.validateResponse(
                EXP_PREFIX,
                expectedMap,
                crteTknRspMap);
        }

    private static void checkApplUserConfiguration() throws Exception {

        int manitobaDefaultSysUserRecordCnt = DataUtils.getApplUserList(manitobaDefaultSysUser,LOG_TRUE).size();
        int manitobaAltSysUserRecordCnt = DataUtils.getApplUserList(manitobaAltSysUser,LOG_TRUE).size();
        int manitobaInvalidSysUserIdRecordCnt = DataUtils.getApplUserList(manitobaInvalidSysUserId,LOG_TRUE).size();

        assertTrue("Record count for " + manitobaDefaultSysUserRecordCnt + " : " + manitobaDefaultSysUserRecordCnt +
                ", expected 1.", manitobaDefaultSysUserRecordCnt == 1);
        assertTrue("Record count for " + manitobaAltSysUserRecordCnt + " : " + manitobaAltSysUserRecordCnt +
                ", expected > 1.", manitobaAltSysUserRecordCnt > 1);
        assertTrue("Record count for " + manitobaInvalidSysUserIdRecordCnt + " : " + manitobaInvalidSysUserIdRecordCnt +
                ", expected 0.", manitobaInvalidSysUserIdRecordCnt == 0);
    }

    private void updateWltPrvdrDvcType() throws Exception {
        Map<String,String> map = new LinkedHashMap<>();
        LogHandler.debugPrint("updateWltPrvdrDvcType");
        //ToDo: talk to John about the generic approach used in updating this table:
        map.put("TOKEN_TYPE_CD", excelRowStr.get("cfgTokenTypeCd"));

        DataUtils.updWltPrvdrDvcType(
                wltPrdvrId,
                excelRowStr.get("inDVcTypeCode"),
                tknTypeCd,
                map,
                LOG_TRUE);

        //ToDo: for now ... not updating the MBL_WLT_APPL_PARM table due to impact to other testers
        //      re-evaluate once testing has moved to FlyWay
    }

    private static void printRequiredTables() throws Exception {

        DataUtils.getMblWltApplParmList("PASSBOOKAUX","aux.range.eligible",LOG_TRUE);

        DataUtils.getWltPrvdrParmList(wltPrdvrId,"aux.eligible.mobile.wallet.id",LOG_TRUE);

        DataUtils.getDvcStrgTypeList(storageTypeCd,LOG_TRUE);

        DataUtils.getNtwrkDvcTypeLkpList(storageTypeCd,tknTypeCd,LOG_TRUE);

        DataUtils.getWltPrvdrDvcTypeList(wltPrdvrId,tknTypeCd,LOG_TRUE);

    }

    private void updateNtwrkDvcTypeLkp() throws Exception {
        Map<String,String> map = new LinkedHashMap<>();
        LogHandler.debugPrint("updateNtwrkDvcTypeLkp");
        //ToDo: talk to John about the generic approach used in updating this table:
        map.put("TOKEN_TYPE_CD", excelRowStr.get("cfgTokenTypeCd"));
        DataUtils.updNtwrkDvcTypeLkp(
                tknTypeCd,
                excelRowStr.get("inDVcTypeCode"),
                storageTypeCd,
                tknTypeCd,
                map,
                LOG_TRUE);

        //ToDo: for now ... not updating the MBL_WLT_APPL_PARM table due to impact to other testers
        //      re-evaluate once testing has moved to FlyWay
    }

    private void resetTknStrgType() throws Exception {
        Map<String, String> map = new LinkedHashMap<>();
        if (excelRow.get("inExec").equals("Y")) {

            if (excelRowStr.get("UpdNtwrkDvcTypeLkp").equals("Y")) {
                LogHandler.debugPrint("Resetting The Data");
                map.put("TOKEN_TYPE_CD", tknTypeCd);
                DataUtils.updNtwrkDvcTypeLkp(
                        "SE",
                        excelRowStr.get("inDVcTypeCode"),
                        storageTypeCd,
                        excelRowStr.get("cfgTokenTypeCd"),
                        map,
                        LOG_TRUE);
            }

            if (excelRowStr.get("UpdWltPrvdrDvcTypeTBl").equals("Y")) {
                map.put("TOKEN_TYPE_CD", tknTypeCd);
                DataUtils.updWltPrvdrDvcType(
                        wltPrdvrId,
                        excelRowStr.get("inDVcTypeCode"),
                        excelRowStr.get("cfgTokenTypeCd"),
                        map,
                        LOG_TRUE);
            }

        }
    }

}