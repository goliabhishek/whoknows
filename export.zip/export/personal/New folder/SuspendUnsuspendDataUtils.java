package com.mastercard.mdes.automation.portal_regression.support.data_manager;

import com.mastercard.mdes.test.automation.core.DatabaseHandler;
import com.mastercard.mdes.test.automation.core.LogHandler;
import com.mastercard.mdes.test.automation.core.mdes_utilities.MDESUtilities;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.annotation.Nonnull;
import java.util.*;

import com.mastercard.mdes.test.automation.core.DatabaseHandler;
import com.mastercard.mdes.test.automation.core.LogHandler;
import com.mastercard.mdes.test.automation.core.mdes_utilities.MDESUtilities;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.annotation.Nonnull;
import java.util.*;

/**
 * Created by E055238 on 8/6/2015.
 */
public class SuspendUnsuspendDataUtils {


    public static String generateRequestId() {
        Random random = new Random();
        Integer i = random.nextInt(900000000);
        return i.toString();
    }

    public static String getCurrentDatabaseTimestamp() throws Exception {
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        Map result = jdbcTemplate.queryForMap("SELECT  TO_CHAR(CURRENT_TIMESTAMP, 'MM/DD/YYYY HH:MI:SS.FF3 PM') AS SYSDATETIME FROM DUAL");
        return String.valueOf(result.get("SYSDATETIME"));
    }

    public static String getClientIdByTokenUniqueReference(String tokenUniqueReference) throws Exception {
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql = "SELECT CC.CLNT_ID " +
                "FROM ACCT_RNG_MDES_PARM PARM " +
                "INNER JOIN PAN_DVC_MAP PDM " +
                "ON PARM.RNG_STRT_NUM = PDM.FPAN_RNG_STRT_NUM " +
                "    AND DVC_PAN_UNQ_ID = ? " +
                "INNER JOIN CUST_CLNT CC " +
                "ON PARM.CUST_ID = CC.CUST_ID " +
                "    AND CC.MDES_SERV_CD='CSR'";
        Map<String, Object> result = jdbcTemplate.queryForMap(sql, tokenUniqueReference);

        return String.valueOf(result.get("CLNT_ID"));
    }

    public static String getPaymentAppInstanceIdByTokenUniqueReference(String tokenUniqueReference) throws Exception {
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql =    "SELECT PDM.DVC_PAN_UNQ_ID,PDM.PAYMT_APPL_INSTNCE_ID " +
                "FROM MDES_OWNER2.PAN_DVC_MAP PDM " +
                "WHERE PDM.DVC_PAN_UNQ_ID = ?  ";

        Map<String, Object> result = jdbcTemplate.queryForMap(sql, tokenUniqueReference);
        return String.valueOf(result.get("PAYMT_APPL_INSTNCE_ID"));
    }

    public static Map<String, String> getPanDvcMapRecordUsingTokenUniqueReference(String tokenUniqueReference) throws Exception {
        Map<String, String> resultMap = new HashMap<>();
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();

        String sql = "SELECT * FROM PAN_DVC_MAP WHERE DVC_PAN_UNQ_ID=?";
        Map<String, Object> results = jdbcTemplate.queryForMap(sql, tokenUniqueReference);

        resultMap.put("mapId", String.valueOf(results.get("MAP_ID")));
        resultMap.put("mapStatCd", String.valueOf(results.get("MAP_STAT_CD")));
        resultMap.put("crteDt", String.valueOf(results.get("CRTE_DT")));
        resultMap.put("fundExpirDt", String.valueOf(results.get("FUND_EXPIR_DT")));
        resultMap.put("dvcPanUnqId", String.valueOf(results.get("DVC_PAN_UNQ_ID")));
        resultMap.put("fundPanUnqId", String.valueOf(results.get("FUND_PAN_UNQ_ID")));
        resultMap.put("fundPanUnqId", String.valueOf(results.get("FUND_PAN_UNQ_ID")));
        resultMap.put("dpanRngStrtNum", String.valueOf(results.get("DPAN_RNG_STRT_NUM")));
        resultMap.put("fpanRngStrtNum", String.valueOf(results.get("FPAN_RNG_STRT_NUM")));
        resultMap.put("dvcPanExpirDt", String.valueOf(results.get("DVC_PAN_EXPIR_DT")));
        resultMap.put("recycleDpanSw", String.valueOf(results.get("RECYCLE_DPAN_SW")));
        resultMap.put("mblWltId", String.valueOf(results.get("MBL_WLT_ID")));
        resultMap.put("tokenRqstrId", String.valueOf(results.get("TOKEN_RQSTR_ID")));
        resultMap.put("tokenTypeCd", String.valueOf(results.get("TOKEN_TYPE_CD")));
        resultMap.put("clntApplId", String.valueOf(results.get("CLNT_APPL_ID")));
        resultMap.put("cofEcommEnblSw", String.valueOf(results.get("COF_ECOMM_ENBL_SW")));
        resultMap.put("tokenAssrnceLvlNum", String.valueOf(results.get("TOKEN_ASSRNCE_LVL_NUM")));
        resultMap.put("tokenStrgTypeCd", String.valueOf(results.get("TOKEN_STRG_TYPE_CD")));
        resultMap.put("wltPrvdrId", String.valueOf(results.get("WLT_PRVDR_ID")));

        return resultMap;
    }

    public static Map<String, String> getAmsMckMapRecordUsingTokenUniqueReference(String tokenUniqueReference) throws Exception {

        // Retrieve and decrypt the DPAN/FPAN for a given tokenUniqueReference

        Map<String, String> resultMap = new HashMap<>();

        // Get the encrypted DPAN
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        Map<String, Object> pdmResult = jdbcTemplate.queryForMap("SELECT PDE.ENCRYPT_PAN_DATA " +
                "FROM PAN_DVC_MAP PDM, PAN_DATA_ENC PDE " +
                "WHERE PDM.DVC_PAN_UNQ_ID = ? " +
                "    AND PDM.DVC_PAN_DATA_ENC_ID = PDE.PAN_DATA_ENC_ID ", tokenUniqueReference);

        String dpanEncrypted = pdmResult.get("ENCRYPT_PAN_DATA").toString();

        //LogHandler.debugPrint("    Found the encrypted DPAN: " + dpanEncrypted);

        // Now call the service to decrypt the DPAN
        String dpan = MDESUtilities.caasDecrypt(dpanEncrypted);

        //LogHandler.debugPrint("    Retrieved DPAN as: " + dpan);

        Map<String, Object> amsResult = jdbcTemplate.queryForMap("SELECT * FROM AMS_MCK_MAP WHERE DVC_PAN=?", dpan);
        String fpan = amsResult.get("FUND_PAN").toString();
        String fundPanExpirDt = amsResult.get("FUND_PAN_EXPIR_DT").toString();
        String mapStat = amsResult.get("MAP_STAT").toString();
        String tokenTypeCd = amsResult.get("TOKEN_TYPE_CD").toString();
        String rqstrId = amsResult.get("RQSTR_ID").toString();

        //LogHandler.debugPrint("    Retrieved FPAN as: " + amsResult.get("FUND_PAN").toString());

        // Return the dpan, fpan, etc in a map
        resultMap.put("dpan", dpan);
        resultMap.put("fpan", fpan);
        resultMap.put("fundPanExpirDt", fundPanExpirDt);
        resultMap.put("mapStat", mapStat);
        resultMap.put("tokenTypeCd", tokenTypeCd);
        resultMap.put("rqstrId", rqstrId);
        return resultMap;
    }

    public static ArrayList<String> getMDESSuspenders(String tokenUniqueReference) throws Exception {
        Map<String, String> amsResults = getAmsMckMapRecordUsingTokenUniqueReference(tokenUniqueReference);
        String dpan = amsResults.get("dpan");
        assert dpan != null;

        ArrayList<String> resultList = new ArrayList<>();

        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        List<Map<String, Object>> results = jdbcTemplate.queryForList("SELECT pdms.* FROM PAN_DVC_MAP_SPND pdms LEFT JOIN PAN_DVC_MAP pdm ON pdms.MAP_ID = pdm.MAP_ID WHERE pdm.DVC_PAN_UNQ_ID = ? ORDER BY SPND_RQSTR_CD ASC", tokenUniqueReference);

        for (int i = 0; i < results.size(); i++) {
            Map m = results.get(i);
            resultList.add(m.get("SPND_RQSTR_CD").toString());
        }

        return resultList;
    }

    public static Map getDpanUsingTokenUniqueReference(String tokenUniqueReference) throws Exception {
        LogHandler.debugPrint("Finding the decrypted DPAN/FPAN for a tokenUniqueReference");
        Map<String, String> resultMap = new HashMap<String, String>();

        // Get the encrypted DPAN
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql = "SELECT PDE.ENCRYPT_PAN_DATA " +
                "FROM PAN_DVC_MAP PDM, PAN_DATA_ENC PDE " +
                "WHERE PDM.DVC_PAN_UNQ_ID = ? " +
                "    AND PDM.DVC_PAN_DATA_ENC_ID = PDE.PAN_DATA_ENC_ID ";

        Map<String, Object> pdmResult = jdbcTemplate.queryForMap(sql, tokenUniqueReference);
        String dpanEncrypted = (String) pdmResult.get("ENCRYPT_PAN_DATA");

        LogHandler.debugPrint("    Found the encrypted DPAN: " + dpanEncrypted);

        String dpan = MDESUtilities.caasDecrypt(dpanEncrypted);
        assert dpan != null;
        LogHandler.debugPrint("    Retrieved DPAN as: " + dpan);

        // Find the FPAN from AMS_MCK_MAP

        String sql2 = "SELECT * FROM AMS_MCK_MAP WHERE DVC_PAN=?";
        Map<String, Object> amsResult = jdbcTemplate.queryForMap(sql2, dpan);

        String fpan = String.valueOf(amsResult.get("FUND_PAN"));
        String fpanexpir= String.valueOf(amsResult.get("FUND_PAN_EXPIR_DT"));

        LogHandler.debugPrint("    Retrieved FPAN as: " + fpan);

        // Return the dpan, fpan, etc in a map
        resultMap.put("dpan", dpan);
        resultMap.put("fpan", fpan);
        resultMap.put("fpanexpir", fpanexpir);
        return resultMap;
    }

    public static Map<String, String> getPrvsnRqstRecordUsingMapId(String mapId, String prvsnTypeCd) throws Exception {
        Map<String, String> resultMap = new HashMap<>();

        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql = "SELECT * FROM PRVSN_RQST WHERE MAP_ID=? AND PRVSN_TYPE_CD=?";
        Map<String, Object> results = jdbcTemplate.queryForMap(sql, mapId, prvsnTypeCd);

        resultMap.put("prvsnRqstId", String.valueOf(results.get("PRVSN_RQST_ID")));
        resultMap.put("prvsnStatCd", String.valueOf(results.get("PRVSN_STAT_CD")));
        resultMap.put("prvsnStatDt", String.valueOf(results.get("PRVSN_STAT_DT")));
        resultMap.put("crteDt", String.valueOf(results.get("CRTE_DT")));
        resultMap.put("wltPrvdrId", String.valueOf(results.get("WLT_PRVDR_ID")));
        resultMap.put("wltPrvdrRqstId", String.valueOf(results.get("WLT_PRVDR_RQST_ID")));
        resultMap.put("mapId", String.valueOf(results.get("MAP_ID")));
        resultMap.put("idvDecsnTxt", String.valueOf(results.get("IDV_DECSN_TXT")));
        resultMap.put("prvsnChngRsnTxt", String.valueOf(results.get("PRVSN_CHNG_RSN_TXT")));
        resultMap.put("encryptDataTxt", String.valueOf(results.get("ENCRYPT_DATA_TXT")));
        resultMap.put("putPendRespData",  String.valueOf(results.get("PUT_PEND_RESP_DATA")));
        resultMap.put("prvsnChgRqstDt", String.valueOf(results.get("PRVSN_CHNG_RQST_DT")));
        resultMap.put("srcApplNam", String.valueOf(results.get("SRC_APPL_NAM")));

        return resultMap;
    }

    public static ArrayList<String> getAMSSuspenders(String tokenUniqueReference) throws Exception {

        Map<String, String> amsResults = getAmsMckMapRecordUsingTokenUniqueReference(tokenUniqueReference);
        String dpan = amsResults.get("dpan");
        assert dpan != null;

        ArrayList<String> resultList = new ArrayList<>();

        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        List<Map<String, Object>> results = jdbcTemplate.queryForList("SELECT * FROM AMS_MOCK_EVENT WHERE DVC_PAN = ? " +
                "ORDER BY EVENT_RQSTR_CD ASC", dpan);

        for (int i = 0; i < results.size(); i++) {
            Map m = (Map) results.get(i);
            resultList.add(String.valueOf(m.get("EVENT_RQSTR_CD")));
        }

        return resultList;
    }

    public static Map<String, String> getApiActivityRecordUsingApiCallName(String startTimestamp, String apiCallName) throws Exception {
        Map<String, String> resultMap = new HashMap<>();

        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        Map<String, Object> results = jdbcTemplate.queryForMap("SELECT * FROM API_ACTVTY " +
                "WHERE API_CALL_NAM=? AND MDES_SERV_CD=? " +
                "AND CRTE_TS>TO_TIMESTAMP(?,'MM/DD/YYYY HH:MI:SS.FF3 PM') AND ROWNUM = 1 ORDER BY CRTE_TS DESC", apiCallName, "CSR", startTimestamp);

        resultMap.put("apiCallNam", String.valueOf(results.get("API_CALL_NAM")));
        resultMap.put("crteTs", String.valueOf(results.get("CRTE_TS")));
        resultMap.put("mapId", String.valueOf(results.get("MAP_ID")));
        resultMap.put("clntId", String.valueOf(results.get("CLNT_ID")));
        resultMap.put("mdesServCd", String.valueOf(results.get("MDES_SERV_CD")));
        resultMap.put("errTxt", String.valueOf(results.get("ERR_TXT")));
        resultMap.put("dvcPanUnqId", String.valueOf(results.get("DVC_PAN_UNQ_ID")));
        resultMap.put("respTmMsecCnt", String.valueOf(results.get("RESP_TM_MSEC_CNT")));

        return resultMap;
    }

    public static String getFpanByTokenUniqueReference(String tokenUniqueReference) throws Exception {
        Map<String, String> amsDetails = getDpanUsingTokenUniqueReference(tokenUniqueReference);
        return amsDetails.get("fpan");
    }

    public static String getMapId(String tokenUniqueReference) throws Exception {
        assert tokenUniqueReference != null;

        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql = "SELECT MAP_ID FROM PAN_DVC_MAP WHERE DVC_PAN_UNQ_ID=?";
        Map<String, Object> results = jdbcTemplate.queryForMap(sql, tokenUniqueReference);

        return results.get("MAP_ID").toString();
    }

    public static List getActivationMethodsByTokenUniqueReference(@Nonnull String tokenUniqueReference) throws Exception {

        Map pdmResults = SuspendUnsuspendDataUtils.getPanDvcMapRecordUsingTokenUniqueReference(tokenUniqueReference);
        String mapId = pdmResults.get("mapId").toString();
        String fpanRange = pdmResults.get("fpanRngStrtNum").toString();
        String wspId = pdmResults.get("wltPrvdrId").toString();

        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        // Dat sql...
        String sql = "SELECT ACM.ACTV_CD_MTHD_CD,\n" +
                "  ACM.ACTV_CD_MTHD_DESC,\n" +
                "  PDMACM.ACTV_CD_MTHD_VAL,\n" +
                "  ACM.ISSR_VAL_SW,\n" +
                "  ACM.CRDHLDR_VAL_SW,\n" +
                "  WPACM.WLT_PRVDR_ID,\n" +
                "  WPACM.WLT_PRVDR_ACTV_CD_MTHD_NAM,\n" +
                "  WPACM.VAL_REQ_SW,\n" +
                "  PDMACM.PAN_DVC_MAP_ACTV_CD_MTHD_ID                                                                                                                                                                     AS WLT_PRVDR_ACTV_CD_MTHD_ID,\n" +
                "  DECODE(PDMACM.MSG_TYPE_CD, CAST('GET_ACTIVATION_METHODS_WEBSERVICE' AS VARCHAR2(3)), 1, CAST('AUTHORIZE_SERVICE_WEBSERVICE' AS VARCHAR2(3)), 2, CAST('TOKENIZATION_AUTHORIZATION_REQUEST' AS VARCHAR2(3)), 3, CAST('TOKENIZATION_ELIGIBILITY_REQUEST' AS VARCHAR2(3)), 4) AS PRIORITY_NUM,\n" +
                "  PDMACM.ORDER_NUM                                                                                                                                                                                       AS ORDER_NUM,\n" +
                "  PDMACM.MSG_TYPE_CD\n" +
                "FROM WLT_PRVDR_ACTV_CD_MTHD WPACM\n" +
                "JOIN PAN_DVC_MAP_ACTV_CD_MTHD PDMACM\n" +
                "ON WPACM.ACTV_CD_MTHD_CD = PDMACM.ACTV_CD_MTHD_CD\n" +
                "JOIN ACTV_CD_MTHD_VW ACM\n" +
                "ON PDMACM.ACTV_CD_MTHD_CD = ACM.ACTV_CD_MTHD_CD\n" +
                "WHERE WPACM.WLT_PRVDR_ID  = ?\n" +
                "AND PDMACM.MAP_ID         = ?\n" +
                "AND ACM.CRDHLDR_VAL_SW    = 'Y'\n" +
                "UNION\n" +
                "  (SELECT ACM.ACTV_CD_MTHD_CD,\n" +
                "    ACM.ACTV_CD_MTHD_DESC,\n" +
                "    ARCHACM.ACTV_CD_MTHD_VAL,\n" +
                "    ACM.ISSR_VAL_SW,\n" +
                "    ACM.CRDHLDR_VAL_SW,\n" +
                "    WPACM.WLT_PRVDR_ID,\n" +
                "    WPACM.WLT_PRVDR_ACTV_CD_MTHD_NAM,\n" +
                "    WPACM.VAL_REQ_SW,\n" +
                "    WPACM.WLT_PRVDR_ACTV_CD_MTHD_ID,\n" +
                "    5    AS PRIORITY_NUM,\n" +
                "    0    AS ORDER_NUM,\n" +
                "    NULL AS MSG_TYPE_CD\n" +
                "  FROM WLT_PRVDR_ACTV_CD_MTHD WPACM\n" +
                "  JOIN AR_CRDHLDR_ACTV_CD_MTHD_VW ARCHACM\n" +
                "  ON WPACM.ACTV_CD_MTHD_CD = ARCHACM.ACTV_CD_MTHD_CD\n" +
                "  JOIN ACTV_CD_MTHD_VW ACM\n" +
                "  ON ARCHACM.ACTV_CD_MTHD_CD = ACM.ACTV_CD_MTHD_CD\n" +
                "  WHERE WPACM.WLT_PRVDR_ID   = ?\n" +
                "  AND ARCHACM.RNG_STRT_NUM   = ?\n" +
                "  AND ACM.CRDHLDR_VAL_SW     = 'Y'\n" +
                "  )\n" +
                "ORDER BY PRIORITY_NUM ASC,\n" +
                "  ORDER_NUM ASC";
        List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql, wspId, mapId, wspId, fpanRange);

        return resultList;
    }

    public static void updatePanDvcMapStatus(String tokenUniqueReference, String mapStatCd) throws Exception {
        assert tokenUniqueReference != null;
        assert mapStatCd != null;

        LogHandler.debugPrint(" Updating PAN_DVC_MAP for tokenUniqueReference: " + tokenUniqueReference);
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql = "UPDATE PAN_DVC_MAP SET MAP_STAT_CD=? WHERE DVC_PAN_UNQ_ID=?";
        jdbcTemplate.update(sql, mapStatCd, tokenUniqueReference);
        LogHandler.debugPrint("    Update complete");
    }

    public static void updatePanDvcMapTermsAndConditionsDate(String tokenUniqueReference, String newTermCondAcptDt) throws Exception {
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        jdbcTemplate.update("UPDATE PAN_DVC_MAP SET TERM_COND_ACPT_DT=? WHERE DVC_PAN_UNQ_ID=?", newTermCondAcptDt, tokenUniqueReference);
    }

    public static void updatePrvsnRqstPrvsnStatCd(String tokenUniqueReference, String newPrvsnStatCd) throws Exception {
        String mapId = getMapId(tokenUniqueReference);
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        jdbcTemplate.update("UPDATE PRVSN_RQST SET PRVSN_STAT_CD=? WHERE MAP_ID=? AND PRVSN_TYPE_CD=?", newPrvsnStatCd, mapId, "PR");
    }

    public static void updatePrvsnRqstIdvDecsnTxt(String tokenUniqueReference, String newIdvDecsnTxt) throws Exception {
        String mapId = getMapId(tokenUniqueReference);
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        jdbcTemplate.update("UPDATE PRVSN_RQST SET IDV_DECSN_TXT=? WHERE MAP_ID=? AND PRVSN_TYPE_CD=?", newIdvDecsnTxt, mapId, "PR");
    }

    public static void updatePrvsnRqstCrteDt(String tokenUniqueReference, int offset) throws Exception {

        String mapId = getMapId(tokenUniqueReference);
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        jdbcTemplate.update("UPDATE PRVSN_RQST SET CRTE_DT=CURRENT_TIMESTAMP-? WHERE MAP_ID=? AND PRVSN_TYPE_CD=?", offset, mapId, "PR");
    }

    public static void setTokenStatus(String desiredStatus, String tokenUniqueReference, String suspenderId) throws Exception {

        /*
         Sets the given token to a suspended, active or unmapped status by doing the following:
            - Sets status in AMS_MCK_MAP and PAN_DVC_MAP
            - Adds or clears a suspender record to AMS_MCK_EVENT and PAN_DVC_MAP_SPND
            - Updates PRVSN_RQST to set as green or yellow path
          */

        // Get the MAP_ID and DPAN
        String mapId = getMapId(tokenUniqueReference);
        Map<String, String> amsResults = getDpanUsingTokenUniqueReference(tokenUniqueReference);
        String dpan = amsResults.get("dpan");
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();

        LogHandler.debugPrint(" Performing Steps to Set Token Status");
        LogHandler.debugPrint("      desiredStatus: 		" + desiredStatus);
        LogHandler.debugPrint("      tokenUniqueReference:	" + tokenUniqueReference);
        LogHandler.debugPrint("      dpan:				    " + dpan);
        LogHandler.debugPrint("      MAP_ID:				" + mapId);
        LogHandler.debugPrint("      EVENT_RQSTR_CD:		" + suspenderId);

        // Data checks
        assert mapId != null;
        assert dpan != null;

        /*
         * AMS_MCK_MAP -- Set MAP_STAT value
         */
        //LogHandler.debugPrint(" 1. Updating AMS_MCK_MAP");
        String mapStatCd = null;

        //TODO consider a switch statement here
        if (desiredStatus.equalsIgnoreCase("suspend")) {
            mapStatCd = "S";
            jdbcTemplate.update("UPDATE AMS_MCK_MAP SET MAP_STAT=? WHERE DVC_PAN=?", mapStatCd, dpan);
            //LogHandler.debugPrint("      Successfully set MAP_STAT to: " + mapStatCd);
        } else if (desiredStatus.equalsIgnoreCase("active")) {
            mapStatCd = "A";
            jdbcTemplate.update("UPDATE AMS_MCK_MAP SET MAP_STAT=? WHERE DVC_PAN=?", mapStatCd, dpan);
            //LogHandler.debugPrint("      Successfully set MAP_STAT to: " + mapStatCd);
        } else if (desiredStatus.equalsIgnoreCase("delete")) {
            mapStatCd = "P";
            jdbcTemplate.update("UPDATE AMS_MCK_MAP SET MAP_STAT=? WHERE DVC_PAN=?", mapStatCd, dpan);
            //LogHandler.debugPrint("      Successfully set MAP_STAT to: " + mapStatCd);
        } else if (desiredStatus.equalsIgnoreCase("unmapped")) {
            jdbcTemplate.update("DELETE FROM AMS_MCK_MAP WHERE DVC_PAN=?", dpan);
            //LogHandler.debugPrint("      Successfully removed AMS_MCK_MAP record for DPAN: " + dpan);
        } else {
            //LogHandler.debugPrint(" Updating AMS_MCK_MAP failed.");
            assert false;
        }

        /*
         * AMS_MOCK_EVENT -- Create or remove suspender record
         */
        //LogHandler.debugPrint(" 2. Updating AMS_MOCK_EVENT");
        //LogHandler.debugPrint("      Clearing existing records.");
        deleteFromAmsMockEvent(dpan);

        if (desiredStatus.equalsIgnoreCase("suspend")) {
            jdbcTemplate.update("INSERT INTO AMS_MOCK_EVENT (DVC_PAN, EVENT_RQSTR_CD, EVENT_RQST_TYPE_CD) VALUES(?,?,?)", dpan, suspenderId, "S");
            //LogHandler.debugPrint("     Successfully inserted suspender record into AMS_MOCK_EVENT with EVENT_RQSTR_CD: " + suspenderId);
        } else {
            // Do nothing since the records were already cleared.
        }

        /*
         * PAN_DVC_MAP -- Set MAP_STAT_CD
         */

        //LogHandler.debugPrint(" 3. Updating PAN_DVC_MAP");
        if (desiredStatus.equalsIgnoreCase("suspend")) {
            mapStatCd = "S";
        } else if (desiredStatus.equalsIgnoreCase("active")) {
            mapStatCd = "A";
        } else if (desiredStatus.equalsIgnoreCase("delete")) {
            mapStatCd = "D";
        } else if (desiredStatus.equalsIgnoreCase("unmapped")) {
            mapStatCd = "U";
        } else {
            assert false : (" Updating PAN_DVC_MAP failed.");
        }

        updatePanDvcMapStatus(tokenUniqueReference, mapStatCd);
        //LogHandler.debugPrint("      Successfully set MAP_STAT_CD to: " + mapStatCd);

        /*
         * PAN_DVC_MAP_SPND -- Create or remove suspender record
         */

        //LogHandler.debugPrint(" 4. Updating PAN_DVC_MAP_SPND");
        //LogHandler.debugPrint("      Clearing existing records.");
        deleteFromPanDvcMapSpnd(mapId);

        if (desiredStatus.equalsIgnoreCase("suspend")) {
            jdbcTemplate.update("INSERT INTO PAN_DVC_MAP_SPND (MAP_ID, SPND_RQSTR_CD, CRTE_TS) VALUES(?,?,?)", mapId, suspenderId, "2015-01-01");
            //LogHandler.debugPrint("     Successfully inserted suspender record into PAN_DVC_MAP_SPND with EVENT_RQSTR_CD: " + suspenderId);
        } else {
            // Do nothing since the records were already cleared.
        }

        /*
        * PRVSN_RQST -- Update IDV_DECSN_TXT
         */

        //LogHandler.debugPrint(" 5. Updating PRVSN_RQST");
        //LogHandler.debugPrint("      Updating PRVSN_RQST IDV_DECSN_TXT.");

        String idvDecsnTxt = null;
        if (desiredStatus.equalsIgnoreCase("suspend")) {
            idvDecsnTxt = "Green";
        } else if (desiredStatus.equalsIgnoreCase("active")) {
            idvDecsnTxt = "Green";
        } else if (desiredStatus.equalsIgnoreCase("delete")) {
            idvDecsnTxt = "Green";
        } else if (desiredStatus.equalsIgnoreCase("unmapped")) {
            idvDecsnTxt = "Yellow";
        } else {
            assert false : (" Updating PAN_DVC_MAP failed.");
        }

        jdbcTemplate.update("UPDATE PRVSN_RQST SET IDV_DECSN_TXT=? WHERE MAP_ID=? AND PRVSN_TYPE_CD=?", idvDecsnTxt, mapId, "PR");
        //LogHandler.debugPrint("           Updated!");

        //LogHandler.debugPrint("      Cleaning extra PRVSN_RQST records.");
        if (desiredStatus.equalsIgnoreCase("unmapped")) {
            removeExtraPrvsnRqstRecords(mapId, true);
        } else {
            removeExtraPrvsnRqstRecords(mapId, false);
        }
        //LogHandler.debugPrint("           Complete!");

        //LogHandler.debugPrint(" Data Setup Complete!");
        //LogHandler.debugPrint(" ***************************");

    }

    public static void deleteFromAmsMockEvent(String dpan) throws Exception {
        assert dpan != null;
        LogHandler.debugPrint(" Removing record from AMS_MOCK_EVENT for dpan: " + dpan);
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        jdbcTemplate.update("DELETE FROM AMS_MOCK_EVENT WHERE DVC_PAN=?", dpan);
        LogHandler.debugPrint("    Record(s) cleared.");
    }

    public static Map<String, String> getPanDvcMapSpndRecordUsingTokenUniqueReference(String tokenUniqueReference) throws Exception {
        Map<String, String> resultMap = new HashMap<>();

        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        List<Map<String, Object>> resultsList = jdbcTemplate.queryForList("SELECT PDMS.*\n" +
                "FROM PAN_DVC_MAP_SPND PDMS, PAN_DVC_MAP PDM\n" +
                "WHERE PDM.DVC_PAN_UNQ_ID=? AND\n" +
                "PDM.MAP_ID = PDMS.MAP_ID\n" +
                "ORDER BY CRTE_TS DESC", tokenUniqueReference);

        if (!resultsList.isEmpty()) {
            Map<String, Object> results = (Map) resultsList.get(0);

            resultMap.put("mapId", results.get("MAP_ID").toString());
            resultMap.put("spndRqstrCd", results.get("SPND_RQSTR_CD").toString());
            resultMap.put("crteTs", results.get("CRTE_TS").toString());
        }

        return resultMap;
    }

    public static void deleteFromPanDvcMapSpnd(String mapId) throws Exception {
        assert mapId != null;
        LogHandler.debugPrint(" Removing record from PAN_DVC_MAP_SPND for mapId: " + mapId);
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        jdbcTemplate.update("DELETE FROM PAN_DVC_MAP_SPND WHERE MAP_ID=?", mapId);
        LogHandler.debugPrint("    Record(s) cleared.");
    }

    public static void removeExtraPrvsnRqstRecords(String mapId, Boolean removeADRecord) throws Exception {
        assert mapId != null;
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql;
        if (removeADRecord) {
            sql = "DELETE FROM PRVSN_RQST WHERE MAP_ID=? AND PRVSN_TYPE_CD IN ('AD', 'DD', 'FPR', 'RD', 'SD')";
        } else {
            sql = "DELETE FROM PRVSN_RQST WHERE MAP_ID=? AND PRVSN_TYPE_CD IN ('DD', 'FPR', 'RD', 'SD')";
        }
        jdbcTemplate.update(sql, mapId);
    }

    public static Map<String, String> getAmsMockEventRecordUsingTokenUniqueReference(String tokenUniqueReference) throws Exception {

        Map<String, String> resultMap = new HashMap<>();
        String fpan = null;
        String dpan = null;
        String dpanEncrypted = null;
        String fundPanExpirDt = null;
        String mapStat = null;
        String tokenTypeCd = null;
        String rqstrId = null;

        // Get the encrypted DPAN
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        Map<String, Object> pdmResult = jdbcTemplate.queryForMap("SELECT PDE.ENCRYPT_PAN_DATA " +
                "FROM PAN_DVC_MAP PDM, PAN_DATA_ENC PDE " +
                "WHERE PDM.DVC_PAN_UNQ_ID = ? " +
                "    AND PDM.DVC_PAN_DATA_ENC_ID = PDE.PAN_DATA_ENC_ID ", tokenUniqueReference);


        dpanEncrypted = pdmResult.get("ENCRYPT_PAN_DATA").toString();

        //LogHandler.debugPrint("    Found the encrypted DPAN: " + dpanEncrypted);

        // Now call the service to decrypt the DPAN
        dpan = MDESUtilities.caasDecrypt(dpanEncrypted);
        //LogHandler.debugPrint("    Retrieved DPAN as: " + dpan);

        // Find the AMS_MOCK_EVENT record
        List<Map<String, Object>> amsMockEventList = jdbcTemplate.queryForList("SELECT * FROM AMS_MOCK_EVENT WHERE DVC_PAN=?", dpan);

        if (!amsMockEventList.isEmpty()) {
            Map amsMockEventResult = (Map) amsMockEventList.get(0);
            resultMap.put("dpan", amsMockEventResult.get("DVC_PAN").toString());
            resultMap.put("eventRqstrCd", amsMockEventResult.get("EVENT_RQSTR_CD").toString());
            resultMap.put("eventRqstTypeCd", amsMockEventResult.get("EVENT_RQST_TYPE_CD").toString());
        }


        return resultMap;
    }

    public static Map<String, String> getApiActivityRecordUsingTokenUniqueReference(String startTimestamp, String mdesServCd, String clntId) throws Exception {
        Map<String, String> resultMap = new HashMap<>();

        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        Map<String, Object> results = jdbcTemplate.queryForMap("SELECT * " +
                "FROM API_ACTVTY " +
                "WHERE MDES_SERV_CD=? AND CLNT_ID=? AND CRTE_TS>TO_TIMESTAMP(?,'fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM') AND ROWNUM = 1 ORDER BY CRTE_TS DESC", mdesServCd, clntId, startTimestamp);

        resultMap.put("apiCallNam", String.valueOf(results.get("API_CALL_NAM")));
        resultMap.put("crteTs", String.valueOf(results.get("CRTE_TS")));
        resultMap.put("mapId", String.valueOf(results.get("MAP_ID")));
        resultMap.put("clntId", String.valueOf(results.get("CLNT_ID")));
        resultMap.put("mdesServCd", String.valueOf(results.get("MDES_SERV_CD")));
        resultMap.put("errTxt", String.valueOf(results.get("ERR_TXT")));
        resultMap.put("dvcPanUnqId", String.valueOf(results.get("DVC_PAN_UNQ_ID")));
        resultMap.put("respTmMsecCnt", String.valueOf(results.get("RESP_TM_MSEC_CNT")));

        return resultMap;
    }

    public static void addSuspender(String tokenUniqueReference, String suspenderCode) throws Exception {
        Map<String, String> amsResults = getAmsMckMapRecordUsingTokenUniqueReference(tokenUniqueReference);
        String dpan = amsResults.get("dpan");
        assert dpan != null;

        Map pdmResults = getPanDvcMapRecordUsingTokenUniqueReference(tokenUniqueReference);
        String mapId = pdmResults.get("mapId").toString();
        assert mapId != null;

        // Insert AMS_MOCK_EVENT record
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        jdbcTemplate.update("Insert into AMS_MOCK_EVENT\n" +
                "   (DVC_PAN, EVENT_RQSTR_CD, EVENT_RQST_TYPE_CD, RPLCTN_UPDT_TS)\n" +
                " Values\n" +
                "   (?, ?, 'S', TO_TIMESTAMP('11/4/2015 9:24:36.106483 AM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'))", dpan, suspenderCode);

        // Insert PAN_DVC_MAP_SPND record
        jdbcTemplate.update("Insert into PAN_DVC_MAP_SPND\n" +
                "   (MAP_ID, SPND_RQSTR_CD, CRTE_TS, RPLCTN_UPDT_TS)\n" +
                " Values\n" +
                "   (?, ?, TO_TIMESTAMP('5/13/2015 10:58:32.000000 AM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'), TO_TIMESTAMP('5/13/2015 10:58:32.570903 AM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'))", mapId, suspenderCode);

    }

    public static void insertComment(String mapId) throws Exception {
        assert mapId != null;
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql =    "Insert into CUST_SERV_CMNT" +
                "   (CMNT_ID, MAP_ID, CMNT_TXT, REP_ID, REP_NAM, " +
                "    REP_ORG_NAM, CRTE_TS, REP_PHN_NUM, RPLCTN_UPDT_TS)" +
                " Values" +
                "   (CMNT_ID_SEQ.nextval, ?, 'CS API V2 Smoke Test', 'E055238', 'CS API V2 Smoke Test', " +
                "    'MDES Super Test', TO_TIMESTAMP('8/2/2015 8:07:40.810000 PM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'), NULL, TO_TIMESTAMP('8/2/2015 8:07:40.861992 PM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'))";
        jdbcTemplate.update(sql, mapId);
    }

    public static void insertCommentByTokenUniqueReference(String tokenUniqueReference, String commentText, String repId, String repNam) throws Exception {
        assert tokenUniqueReference != null;
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql = "Insert into CUST_SERV_CMNT\n" +
                " (CMNT_ID, MAP_ID, CMNT_TXT, REP_ID, REP_NAM,\n" +
                "  REP_ORG_NAM, CRTE_TS, REP_PHN_NUM, RPLCTN_UPDT_TS)\n" +
                "Values\n" +
                " (CMNT_ID_SEQ.nextval, (SELECT MAP_ID FROM PAN_DVC_MAP WHERE DVC_PAN_UNQ_ID=?), ?, ?, ?,\n" +
                "  'MDES Super Test', CURRENT_TIMESTAMP, \n" +
                "  NULL, CURRENT_TIMESTAMP)";
        jdbcTemplate.update(sql, tokenUniqueReference, commentText, repId, repNam);
    }

    public static void insertTokenStatusHistoryEvent(String mapId) throws Exception {
        assert mapId != null;
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql =
                "Insert into PAN_DVC_MAP_AUD" +
                        "   (MAP_ID, UPDT_DT, MAP_STAT_CD, MAP_STAT_DT, DVC_PAN_DATA_ENC_ID, " +
                        "    HASH_DVC_PAN, HASH_FUND_PAN, CRTE_DT, SEC_ELMT_ID, APPL_AID_TXT, " +
                        "    TERM_COND_VER_ID, TERM_COND_ACPT_DT, WLT_PRVDR_ID, ACTV_CD, ACTV_CD_EXPIR_DT, " +
                        "    FUND_EXPIR_DT, DATA_PREP_PROFL_ID, DVC_PAN_UNQ_ID, FUND_PAN_UNQ_ID, CARDLET_ID, " +
                        "    SSD_AID_TXT, ACTV_CD_ATMPT_CNT, HASH_WLT_PRVDR_ACCT_ID, DPAN_RNG_STRT_NUM, FPAN_RNG_STRT_NUM, " +
                        "    FPAN_SEQ_NUM, DVC_PAN_EXPIR_DT, CONFIG_UUID, CONFIG_SRC_CD, " +
                        "    RECYCLE_DPAN_SW, APPLET_VER_NUM, FUND_PAN_DATA_ENC_ID, RPLCTN_UPDT_TS, " +
                        "    DPAN_RECLM_SW, PRDCT_CONFIG_UPDT_TS, MBL_WLT_ID, TOKEN_RQSTR_ID, TOKEN_TYPE_CD, " +
                        "    NFC_CPBL_SW, DSRP_ENBL_SW, PAYMT_APPL_INSTNCE_ID, CMK_ID)" +
                        " Values" +
                        "   (?, TO_TIMESTAMP('8/11/2015 12:02:33.844287 PM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'), 'U', TO_DATE('08/11/2015 12:02:24', 'MM/DD/YYYY HH24:MI:SS'), 92759, " +
                        "    '4BF0DF7E329549D5D8053233D9583F0C9D04E63EAD5BB5DA9B27B49C85E9ED57', '4825CAF5773824F2EF65B35D79B92EFA5ED656C07F03FFEE67B5F1F819A46503', TO_DATE('08/11/2015 12:02:24', 'MM/DD/YYYY HH24:MI:SS'), '888160506', 'A00000000410100100000001', " +
                        "    '81d9f8e0-6292-11e3-949a-0800200c9a66', NULL, 103, NULL, NULL, " +
                        "    '1221', NULL, NULL, NULL, 4, " +
                        "    'A0000000041010AA0000000000112233', 0, NULL, 5480981600100000000, 5455016000100000000, " +
                        "    NULL, '0918', NULL, NULL, " +
                        "    'N', '0001', NULL, TO_TIMESTAMP('8/11/2015 12:02:33.844287 PM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'), " +
                        "    'N', TO_TIMESTAMP('8/11/2015 12:02:24.000000 PM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'), 'PASSBOOK', 50110030273, 'SE', " +
                        "    'Y', 'Y', NULL, NULL)";
        jdbcTemplate.update(sql, mapId);
    }

    public static List<Map<String, Object>> getTransactionRecords(String tokenUniqueReference) throws Exception {
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        return jdbcTemplate.queryForList("SELECT * FROM TRAN t WHERE MAP_ID = (SELECT MAP_ID FROM PAN_DVC_MAP WHERE DVC_PAN_UNQ_ID = ?) ORDER BY TRAN_TS DESC", tokenUniqueReference);
    }

    public static void cinsertTransactionRecord(String tokenUniqueReference) throws Exception {
        String mapId = SuspendUnsuspendDataUtils.getMapId(tokenUniqueReference);
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql =
                "Insert into TRAN" +
                        "   (TRAN_ID, MAP_ID, TRAN_TS, TRAN_AMT, CURR_ALPHA_CD, " +
                        "    TRAN_TYPE_CD, TRAN_STAT_CD, TRAN_UPDT_TS, MERCH_NAM, MERCH_CAT_CD, " +
                        "    WLT_PRVDR_TRAN_ID, TRAN_SRC_CD, MTI_CD, SYS_TRACE_AUDIT_NUM, ACQ_INST_ID, " +
                        "    FWD_INST_ID, NTWRK_REF_NUM, AUTH_RESP_CD, TRAN_SUB_STAT_CD, SETL_DT, " +
                        "    LOC_DT, RPLCTN_UPDT_TS, CRTE_TS, RAW_MERCH_NAM, POS_ENT_MODE_VAL, " +
                        "    POS_POST_CD, RMN_BAL_NUM)" +
                        " Values" +
                        "   (TRAN_ID_SEQ.nextval, ?, CURRENT_TIMESTAMP, 10.55, 'USD', " +
                        "    'PURCH', 'AUTH', TO_TIMESTAMP('7/23/2015 3:36:44.048740 PM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'), 'MDES-4998-AC1', 5812, " +
                        "    'ea81f9ac719775c568cd86da1754214d2ba91dc229374f670a3889ce31bab6b5', 'DUAL', '9110', '666666', '444444', " +
                        "    '555555', 'SLDCKD', '00', NULL, TO_DATE('04/10/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), " +
                        "    TO_DATE('04/10/2014 09:29:00', 'MM/DD/YYYY HH24:MI:SS'), TO_TIMESTAMP('8/12/2015 4:00:36.571980 AM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'), TO_TIMESTAMP('7/23/2015 3:36:44.048740 PM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'), NULL, '90', " +
                        "    NULL, NULL)";
        jdbcTemplate.update(sql, mapId);
    }

//    public static void insertTransactionRecord(String tokenUniqueReference, String tranAmt, int timestampOffset,
//                                               TransactionUtility.CURR_ALPHA_CD CURR_ALPHA_CD, TransactionUtility.TRAN_TYPE_CD TRAN_TYPE_CD) throws Exception {
//        String mapId = SuspendUnsuspendDataUtils.getMapId(tokenUniqueReference);
//        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
//        String sql =
//                "Insert into TRAN" +
//                        "   (TRAN_ID, MAP_ID, TRAN_TS, TRAN_AMT, CURR_ALPHA_CD, " +
//                        "    TRAN_TYPE_CD, TRAN_STAT_CD, TRAN_UPDT_TS, MERCH_NAM, MERCH_CAT_CD, " +
//                        "    WLT_PRVDR_TRAN_ID, TRAN_SRC_CD, MTI_CD, SYS_TRACE_AUDIT_NUM, ACQ_INST_ID, " +
//                        "    FWD_INST_ID, NTWRK_REF_NUM, AUTH_RESP_CD, TRAN_SUB_STAT_CD, SETL_DT, " +
//                        "    LOC_DT, RPLCTN_UPDT_TS, CRTE_TS, RAW_MERCH_NAM, POS_ENT_MODE_VAL, " +
//                        "    POS_POST_CD, RMN_BAL_NUM)" +
//                        " Values" +
//                        "   (TRAN_ID_SEQ.nextval, ?, CURRENT_TIMESTAMP-?, ?, ?, " +
//                        "    ?, 'AUTH', TO_TIMESTAMP('7/23/2015 3:36:44.048740 PM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'), 'MDES-4998-AC1', 5812, " +
//                        "    'ea81f9ac719775c568cd86da1754214d2ba91dc229374f670a3889ce31bab6b5', 'DUAL', '9110', '666666', '444444', " +
//                        "    '555555', 'SLDCKD', '00', NULL, TO_DATE('04/10/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), " +
//                        "    TO_DATE('04/10/2014 09:29:00', 'MM/DD/YYYY HH24:MI:SS'), TO_TIMESTAMP('8/12/2015 4:00:36.571980 AM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'), TO_TIMESTAMP('7/23/2015 3:36:44.048740 PM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'), NULL, '90', " +
//                        "    NULL, NULL)";
//        jdbcTemplate.update(sql, mapId, timestampOffset, tranAmt, CURR_ALPHA_CD.toString(), TRAN_TYPE_CD.toString());
//    }

    public static String getPrvsnRqstIdByAuthtcnTokenId(String authtcnTokenId) throws Exception {
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql =
                "SELECT * FROM PRVSN_RQST WHERE AUTHTCN_TOKEN_ID=? AND PRVSN_TYPE_CD=?";
        Map<String, Object> result = jdbcTemplate.queryForMap(sql, authtcnTokenId, "PR");
        return String.valueOf(result.get("PRVSN_RQST_ID"));
    }


    public static Map<Integer, Map> getComments(String tokenUniqueReference) throws Exception {
        Map<Integer, Map> resultMap = new LinkedHashMap<>();

        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql = "SELECT * FROM CUST_SERV_CMNT c WHERE c.MAP_ID = (SELECT MAP_ID FROM PAN_DVC_MAP WHERE DVC_PAN_UNQ_ID = ?) ORDER BY CRTE_TS DESC";
        List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql, tokenUniqueReference);

        for (int i = 0; i < resultList.size(); i++) {
            resultMap.put(i, resultList.get(i));
        }
        return resultMap;
    }

    public static Map<String, Object> getNewestComment(String tokenUniqueReference) throws Exception {
        Map<String, Object> resultMap = new LinkedHashMap<>();

        try {
            JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
            String sql = "SELECT * FROM CUST_SERV_CMNT c WHERE c.MAP_ID = (SELECT MAP_ID FROM PAN_DVC_MAP WHERE DVC_PAN_UNQ_ID = ?) AND ROWNUM = 1 ORDER BY CRTE_TS DESC";
            resultMap = jdbcTemplate.queryForMap(sql, tokenUniqueReference);
        } catch (Exception e){
            // Catch the error if no records are found so we can validate 'no comment created' scenarios.
        }

        return resultMap;
    }

    public static Map<String, Object> getCommentById(String commentId) throws Exception {
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        return jdbcTemplate.queryForMap("SELECT * FROM CUST_SERV_CMNT WHERE CMNT_ID=?", commentId);
    }

    //    by Abhishek
    public static Map getAssertionsForSearchFunctionality(String tokenUniqueReference,String type) throws Exception {
        Map<String, String> resultMap = new HashMap<String, String>();
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();

        if (type != "COF") {

            String sql =
                    "SELECT distinct PDM.MAP_ID,PDM.MAP_STAT_DT,PDM.MAP_STAT_CD,PDM.FPAN_SUF_NAM,PDM.DVC_PAN_UNQ_ID,PDM.FUND_PAN_UNQ_ID,PDM.FUND_EXPIR_DT," +
                            "PDM.DVC_PAN_EXPIR_DT,PDM.CRTE_DT,PDM.WLT_PRVDR_ID,PDM.PAYMT_APPL_INSTNCE_ID,PDM.TOKEN_TYPE_CD," +
                            "PRRQ.PRVSN_STAT_CD,DVC1.SEC_ELMT_ID ,DVC1.NTWRK_DVC_TYPE_CD,TRQ.TOKEN_RQSTR_ID,TRQ.TOKEN_RQSTR_NAM " +
                            "FROM MDES_OWNER2.PAN_DVC_MAP PDM " +
                            "INNER JOIN MDES_OWNER2.DVC DVC1 " +
                            "ON DVC1.PAYMT_APPL_INSTNCE_ID = PDM.PAYMT_APPL_INSTNCE_ID " +
                            "AND PDM.DVC_PAN_UNQ_ID = ? " +
                            "INNER JOIN TOKEN_RQSTR TRQ " +
                            "ON TRQ.TOKEN_RQSTR_ID = PDM.TOKEN_RQSTR_ID " +
                            "INNER JOIN PRVSN_RQST  PRRQ " +
                            "ON PRRQ.MAP_ID = PDM.MAP_ID";
            Map<String, Object> result = jdbcTemplate.queryForMap(sql, tokenUniqueReference);


            resultMap.put("mapId", String.valueOf(result.get("MAP_ID")));
            resultMap.put("statDt", String.valueOf(result.get("MAP_STAT_DT")));
            resultMap.put("statCd", String.valueOf(result.get("MAP_STAT_CD")));
            resultMap.put("fpanSufNam", String.valueOf(result.get("FPAN_SUF_NAM")));
            resultMap.put("fundExpirDt", String.valueOf(result.get("FUND_EXPIR_DT")));
            resultMap.put("dvcPanExpirDt", String.valueOf(result.get("DVC_PAN_EXPIR_DT")));
            resultMap.put("crteDt", String.valueOf(result.get("CRTE_DT")));
            resultMap.put("wltPrvdrId", String.valueOf(result.get("WLT_PRVDR_ID")));
            resultMap.put("paymtApplInstnceId", String.valueOf(result.get("PAYMT_APPL_INSTNCE_ID")));
            resultMap.put("tokenTypeCd", String.valueOf(result.get("TOKEN_TYPE_CD")));
            resultMap.put("prvsnStatCode", String.valueOf(result.get("PRVSN_STAT_CD")));
            resultMap.put("secElmntId", String.valueOf(result.get("SEC_ELMT_ID")));
            resultMap.put("ntwrkDvcTypeCode", String.valueOf(result.get("NTWRK_DVC_TYPE_CD")));
            resultMap.put("tokenRqstrId", String.valueOf(result.get("TOKEN_RQSTR_ID")));
            resultMap.put("tokenRqstrName", String.valueOf(result.get("TOKEN_RQSTR_NAM")));
            resultMap.put("dvcPanUnqId", String.valueOf(result.get("DVC_PAN_UNQ_ID")));
            resultMap.put("fundPanUnqId", String.valueOf(result.get("FUND_PAN_UNQ_ID")));

        }
        else {

            String sql =
                    "SELECT distinct PDM.MAP_ID,PDM.MAP_STAT_DT,PDM.MAP_STAT_CD,PDM.FPAN_SUF_NAM,PDM.DVC_PAN_UNQ_ID,PDM.FUND_PAN_UNQ_ID,PDM.FUND_EXPIR_DT," +
                            "PDM.DVC_PAN_EXPIR_DT,PDM.CRTE_DT,PDM.WLT_PRVDR_ID,PDM.PAYMT_APPL_INSTNCE_ID,PDM.TOKEN_TYPE_CD,TRQ.TOKEN_RQSTR_ID,TRQ.TOKEN_RQSTR_NAM " +
                            "FROM MDES_OWNER2.PAN_DVC_MAP PDM " +
                            "INNER JOIN TOKEN_RQSTR TRQ " +
                            "ON TRQ.TOKEN_RQSTR_ID = PDM.TOKEN_RQSTR_ID " +
                            "AND PDM.DVC_PAN_UNQ_ID = ? ";
            Map<String, Object> result = jdbcTemplate.queryForMap(sql, tokenUniqueReference);

            resultMap.put("mapId", String.valueOf(result.get("MAP_ID")));
            resultMap.put("statDt", String.valueOf(result.get("MAP_STAT_DT")));
            resultMap.put("statCd", String.valueOf(result.get("MAP_STAT_CD")));
            resultMap.put("fpanSufNam", String.valueOf(result.get("FPAN_SUF_NAM")));
            resultMap.put("fundExpirDt", String.valueOf(result.get("FUND_EXPIR_DT")));
            resultMap.put("dvcPanExpirDt", String.valueOf(result.get("DVC_PAN_EXPIR_DT")));
            resultMap.put("crteDt", String.valueOf(result.get("CRTE_DT")));
            resultMap.put("wltPrvdrId", String.valueOf(result.get("WLT_PRVDR_ID")));
            resultMap.put("paymtApplInstnceId", String.valueOf(result.get("PAYMT_APPL_INSTNCE_ID")));
            resultMap.put("tokenTypeCd", String.valueOf(result.get("TOKEN_TYPE_CD")));
            resultMap.put("tokenRqstrId", String.valueOf(result.get("TOKEN_RQSTR_ID")));
            resultMap.put("tokenRqstrName", String.valueOf(result.get("TOKEN_RQSTR_NAM")));
            resultMap.put("dvcPanUnqId", String.valueOf(result.get("DVC_PAN_UNQ_ID")));
            resultMap.put("fundPanUnqId", String.valueOf(result.get("FUND_PAN_UNQ_ID")));
        }

        return resultMap;

    }

    public static List getTURForAccPan(String fpan, String type) throws Exception {


        List<String> tur = new ArrayList();
        String hashpan= MDESUtilities.hash(fpan);
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql = "SELECT PDM.DVC_PAN_UNQ_ID,PDM.HASH_FUND_PAN " +
                "FROM MDES_OWNER2.PAN_DVC_MAP PDM " +
                "WHERE PDM.HASH_FUND_PAN = ? ";
        List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql, hashpan);

        for (int i = 0; i < resultList.size(); i++) {
            Map m = resultList.get(i);
            tur.add(String.valueOf(m.get("DVC_PAN_UNQ_ID")));
        }
        return tur;
    }

    public static List getTURForPymntAppId(String paymtApplInstnceId, String type) throws Exception {
        List<String> tur = new ArrayList();
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();

        String sql =    "SELECT PDM.DVC_PAN_UNQ_ID,PDM.PAYMT_APPL_INSTNCE_ID " +
                "FROM MDES_OWNER2.PAN_DVC_MAP PDM " +
                "WHERE PDM.PAYMT_APPL_INSTNCE_ID = ? ";
        List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql, paymtApplInstnceId);

        for (int i = 0; i < resultList.size(); i++) {
            Map m = resultList.get(i);
            tur.add(String.valueOf(m.get("DVC_PAN_UNQ_ID")));
        }

        return tur;
    }

    public static String getActvCdMthdIdUsingTUR(String tokenUniqueReference, String actvCdMthdCd) throws Exception {
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql = "SELECT WLT_PRVDR_ACTV_CD_MTHD_ID FROM WLT_PRVDR_ACTV_CD_MTHD WHERE ACTV_CD_MTHD_CD=? AND WLT_PRVDR_ID = (SELECT WLT_PRVDR_ID FROM PAN_DVC_MAP WHERE DVC_PAN_UNQ_ID = ?)";
        Map<String, Object> m = jdbcTemplate.queryForMap(sql, actvCdMthdCd, tokenUniqueReference);
        return m.get("WLT_PRVDR_ACTV_CD_MTHD_ID").toString();
    }

    public static void updateMblWltParmWltLevelPinSw(String tokenUniqueReference, String newParmVal) throws Exception {
        JdbcTemplate jdbcTemplate = DatabaseHandler.getJdbcTemplate();
        String sql = "UPDATE MBL_WLT_APPL_PARM SET PARM_VAL = ? WHERE MBL_WLT_ID = (SELECT MBL_WLT_ID FROM PAN_DVC_MAP WHERE DVC_PAN_UNQ_ID=?) AND PARM_NAM = 'WalletLevelPINSwitch'";
        jdbcTemplate.update(sql, newParmVal, tokenUniqueReference);
    }


}


