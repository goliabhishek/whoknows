SET SERVEROUTPUT ON;
SET FEEDBACK OFF;
SET ECHO OFF;
SET HEADING OFF;
SET LINESIZE 2500;
SET PAGESIZE 999;
CLEAR SCREEN;

DECLARE
   V_CO_ID                        PROJ.CO_ID%TYPE := '100002';
   V_PROJ_ID                      PROJ.PROJ_ID%TYPE;
   V_DOC_ID                       PROJ_DOC.DOC_ID%TYPE;
   V_SNPSHT_ID                    PROJ_SNPSHT.SNPSHT_ID%TYPE;
   V_RNG_STRT_NUM                 PROJ_ACCT_RNG.RNG_STRT_NUM%TYPE;
   V_TOKEN_RNG_STRT_NUM           PROJ_RNG_MAP.TOKEN_RNG_STRT_NUM%TYPE;
   V_ISSR_MSG_DOC_ID              ISSR_MSG_DOC.DOC_ID%TYPE;
   V_ACTV_DOC_ID                  ACTV_DOC.DOC_ID%TYPE;
   V_AUTH_PROFL_DOC_ID            AUTH_PROFL_DOC.DOC_ID%TYPE;
   V_TRAN_PROFL_DOC_ID            TRAN_PROFL_DOC.DOC_ID%TYPE;
   V_WLT_PROFL_DOC_ID             WLT_PROFL_DOC.DOC_ID%TYPE;
   V_NUM_CNTRY_CD                 ACCT_RNG_VW.NUM_CNTRY_CD%TYPE;
   
   REC_PROJ                       PROJ%ROWTYPE;
   REC_PROJ_DOC                   PROJ_DOC%ROWTYPE;
   REC_PROJ_SNPSHT                PROJ_SNPSHT%ROWTYPE;
   REC_ACCT_RNG_PBLSH             ACCT_RNG_PBLSH%ROWTYPE;
   REC_PROJ_ACCT_RNG              PROJ_ACCT_RNG%ROWTYPE;
   REC_PROJ_RNG_MAP               PROJ_RNG_MAP%ROWTYPE;
   REC_ACCT_RNG_PBLSH             ACCT_RNG_PBLSH%ROWTYPE;
   REC_ISSR_MSG_DOC               ISSR_MSG_DOC%ROWTYPE;
   REC_ACTV_DOC                   ACTV_DOC%ROWTYPE;
   REC_AUTH_PROFL_DOC             AUTH_PROFL_DOC%ROWTYPE;
   REC_TRAN_PROFL_DOC             TRAN_PROFL_DOC%ROWTYPE;
   REC_WLT_PROFL_DOC              WLT_PROFL_DOC%ROWTYPE;
   REC_ACCT_RNG                   ACCT_RNG_VW%ROWTYPE;
   REC_WLT_PRVDR                  WLT_PRVDR_VW%ROWTYPE;
   REC_WLT_APPL                   WLT_APPL_VW%ROWTYPE;


   WalletApplicationIds           VARCHAR2(100);
   
   TYPE TYPE_REC_WALLET IS RECORD (
      ROW_NUMBER           NUMBER,
      WID                  VARCHAR2(100),
      DOC_ID               VARCHAR2(100),
      ROW_NUMBER2          NUMBER,
      MWA                  VARCHAR2(100)
   );

   REC_WALLET                     TYPE_REC_WALLET;
   
   

BEGIN
       
   FOR REC_PROJ IN (SELECT * FROM PROJ WHERE CO_ID = V_CO_ID)
   LOOP
       DBMS_OUTPUT.PUT_LINE('PROJ: CO_ID = ' || REC_PROJ.CO_ID || ', PROJ_ID = ' || REC_PROJ.PROJ_ID); 
       DBMS_OUTPUT.PUT_LINE('  ');
       DBMS_OUTPUT.PUT_LINE('  retrieving PROJ_DOC by "' || REC_PROJ.PROJ_ID || '"');
       FOR REC_PROJ_DOC IN (SELECT * FROM PROJ_DOC WHERE PROJ_ID = REC_PROJ.PROJ_ID)
       LOOP
           DBMS_OUTPUT.PUT_LINE('      PROJ_DOC.PROJ_ID = ' || REC_PROJ_DOC.PROJ_ID); 
           DBMS_OUTPUT.PUT_LINE('      PROJ_DOC.DOC_ID = ' || REC_PROJ_DOC.DOC_ID); 
           DBMS_OUTPUT.PUT_LINE('  ');

           DBMS_OUTPUT.PUT_LINE('    retrieving PROJ_SNPSHT by "' || REC_PROJ_DOC.DOC_ID || '"');
           FOR REC_PROJ_SNPSHT IN (SELECT * FROM PROJ_SNPSHT WHERE DOC_ID = REC_PROJ_DOC.DOC_ID ORDER BY SNPSHT_ID)
           LOOP
               DBMS_OUTPUT.PUT_LINE('       PROJ_SNPSHT.DOC_ID = ' || REC_PROJ_SNPSHT.DOC_ID);
               DBMS_OUTPUT.PUT_LINE('       PROJ_SNPSHT.SNPSHT_ID = ' || REC_PROJ_SNPSHT.SNPSHT_ID);
               DBMS_OUTPUT.PUT_LINE('       PROJ_SNPSHT.SRC_CD = ' || REC_PROJ_SNPSHT.SRC_CD);
               DBMS_OUTPUT.PUT_LINE('       PROJ_SNPSHT.DOC_JSON_TXT:');
               DBMS_OUTPUT.PUT_LINE(REC_PROJ_SNPSHT.DOC_JSON_TXT);

               DBMS_OUTPUT.PUT_LINE('  '); 
               SELECT JSON_VALUE(REC_PROJ_SNPSHT.DOC_JSON_TXT, '$.activationProfile.documentId') INTO V_ACTV_DOC_ID FROM PROJ_SNPSHT WHERE SNPSHT_ID = REC_PROJ_SNPSHT.SNPSHT_ID;
               SELECT * INTO REC_ACTV_DOC FROM ACTV_DOC WHERE DOC_ID = V_ACTV_DOC_ID;
               DBMS_OUTPUT.PUT_LINE('       ACTV_DOC.DOC_ID = ' || REC_ACTV_DOC.DOC_ID); 
               DBMS_OUTPUT.PUT_LINE('       ACTV_DOC.DOC_JSON_TXT:'); 
               DBMS_OUTPUT.PUT_LINE(REC_ACTV_DOC.DOC_JSON_TXT); 

               DBMS_OUTPUT.PUT_LINE('  '); 
               SELECT JSON_VALUE(REC_PROJ_SNPSHT.DOC_JSON_TXT, '$.authorizationProfile.documentId') INTO V_AUTH_PROFL_DOC_ID FROM PROJ_SNPSHT WHERE SNPSHT_ID = REC_PROJ_SNPSHT.SNPSHT_ID;
               SELECT * INTO REC_AUTH_PROFL_DOC FROM AUTH_PROFL_DOC WHERE DOC_ID = V_AUTH_PROFL_DOC_ID;
               DBMS_OUTPUT.PUT_LINE('       AUTH_PROFL_DOC.DOC_ID = ' || REC_AUTH_PROFL_DOC.DOC_ID); 
               DBMS_OUTPUT.PUT_LINE('       AUTH_PROFL_DOC.DOC_JSON_TXT:'); 
               DBMS_OUTPUT.PUT_LINE(REC_AUTH_PROFL_DOC.DOC_JSON_TXT); 

               DBMS_OUTPUT.PUT_LINE('  '); 
               SELECT JSON_VALUE(REC_PROJ_SNPSHT.DOC_JSON_TXT, '$.issuerMessageProfile.documentId') INTO V_ISSR_MSG_DOC_ID FROM PROJ_SNPSHT WHERE SNPSHT_ID = REC_PROJ_SNPSHT.SNPSHT_ID;
               SELECT * INTO REC_ISSR_MSG_DOC FROM ISSR_MSG_DOC WHERE DOC_ID = V_ISSR_MSG_DOC_ID;
               DBMS_OUTPUT.PUT_LINE('       ISSR_MSG_DOC.DOC_ID = ' || REC_ISSR_MSG_DOC.DOC_ID); 
               DBMS_OUTPUT.PUT_LINE('       ISSR_MSG_DOC.DOC_JSON_TXT:'); 
               DBMS_OUTPUT.PUT_LINE(REC_ISSR_MSG_DOC.DOC_JSON_TXT); 

               DBMS_OUTPUT.PUT_LINE('  '); 
               SELECT JSON_VALUE(REC_PROJ_SNPSHT.DOC_JSON_TXT, '$.transactionProfile.documentId') INTO V_TRAN_PROFL_DOC_ID FROM PROJ_SNPSHT WHERE SNPSHT_ID = REC_PROJ_SNPSHT.SNPSHT_ID;
               SELECT * INTO REC_TRAN_PROFL_DOC FROM TRAN_PROFL_DOC WHERE DOC_ID = V_TRAN_PROFL_DOC_ID;
               DBMS_OUTPUT.PUT_LINE('       TRAN_PROFL_DOC.DOC_ID = ' || REC_TRAN_PROFL_DOC.DOC_ID); 
               DBMS_OUTPUT.PUT_LINE('       TRAN_PROFL_DOC.DOC_JSON_TXT:'); 
               DBMS_OUTPUT.PUT_LINE(REC_TRAN_PROFL_DOC.DOC_JSON_TXT); 

               DBMS_OUTPUT.PUT_LINE('  '); 
               DBMS_OUTPUT.PUT_LINE('       WALLETS:'); 
               FOR REC_WALLET IN 
                   (SELECT ps.* 
                    FROM PROJ_SNPSHT,
                    JSON_TABLE (DOC_JSON_TXT, '$.wallets[*]'
                        COLUMNS (row_number FOR ORDINALITY,
                                 wid        VARCHAR2(50) PATH '$.walletProviderId',
                                 doc_id     VARCHAR2(100) PATH '$.walletProfile.documentId',
                                 NESTED PATH '$.walletApplicationIds[*]' 
                                     COLUMNS (row_number2      FOR ORDINALITY,
                                              mwa varchar2(100) PATH '$')))
                    AS ps
                    WHERE PROJ_SNPSHT.SNPSHT_ID = REC_PROJ_SNPSHT.SNPSHT_ID)
               LOOP
                   DBMS_OUTPUT.PUT_LINE('         walletProviderId = ' || REC_WALLET.WID); 
                   DBMS_OUTPUT.PUT_LINE('         walletApplicationIds = ' || REC_WALLET.MWA); 
                   DBMS_OUTPUT.PUT_LINE('         documentId = ' || REC_WALLET.DOC_ID); 
                   IF REC_WALLET.DOC_ID IS NOT NULL THEN
                       SELECT * INTO REC_WLT_PROFL_DOC FROM WLT_PROFL_DOC WHERE DOC_ID = REC_WALLET.DOC_ID;
                       DBMS_OUTPUT.PUT_LINE('       WLT_PROFL_DOC.DOC_JSON_TXT:'); 
                       DBMS_OUTPUT.PUT_LINE(REC_WLT_PROFL_DOC.DOC_JSON_TXT); 
                       DBMS_OUTPUT.PUT_LINE(' '); 
                   END IF;
               END LOOP;
    
               DBMS_OUTPUT.PUT_LINE('      retrieving ACCT_RNG_PBLSH by "' || REC_PROJ_SNPSHT.SNPSHT_ID || '"');
               FOR REC_ACCT_RNG_PBLSH IN (SELECT * FROM ACCT_RNG_PBLSH WHERE SNPSHT_ID = REC_PROJ_SNPSHT.SNPSHT_ID)
               LOOP
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.SNPSHT_ID = ' || REC_ACCT_RNG_PBLSH.SNPSHT_ID); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.RNG_STRT_NUM = ' || REC_ACCT_RNG_PBLSH.RNG_STRT_NUM); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.PBLSH_STAT_CD = ' || REC_ACCT_RNG_PBLSH.PBLSH_STAT_CD); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.SITE_CD = ' || REC_ACCT_RNG_PBLSH.SITE_CD); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.LOCKED_SW = ' || REC_ACCT_RNG_PBLSH.LOCKED_SW); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.OWNR_APPL_NAM = ' || REC_ACCT_RNG_PBLSH.OWNR_APPL_NAM); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.KMS_STAT_CD = ' || REC_ACCT_RNG_PBLSH.KMS_STAT_CD); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.KMS_RQST_ID = ' || REC_ACCT_RNG_PBLSH.KMS_RQST_ID); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.MDS_STAT_CD = ' || REC_ACCT_RNG_PBLSH.MDS_STAT_CD); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.MDS_EFF_DT = ' || REC_ACCT_RNG_PBLSH.MDS_EFF_DT); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.WRK_PKG_STAT_CD = ' || REC_ACCT_RNG_PBLSH.WRK_PKG_STAT_CD); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.WRK_PKG_ID = ' || REC_ACCT_RNG_PBLSH.WRK_PKG_ID); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.RETRY_CNT = ' || REC_ACCT_RNG_PBLSH.RETRY_CNT); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.RETRY_TS = ' || REC_ACCT_RNG_PBLSH.RETRY_TS); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.ERR_MSG_TXT = ' || REC_ACCT_RNG_PBLSH.ERR_MSG_TXT); 
                   --needed to determine "AltNetworkRouting":
                   SELECT * INTO REC_ACCT_RNG FROM ACCT_RNG_VW WHERE RNG_STRT_NUM = REC_ACCT_RNG_PBLSH.RNG_STRT_NUM;
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_VW.NUM_CNTRY_CD = ' || REC_ACCT_RNG.NUM_CNTRY_CD); 
                   DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_VW.NUM_CNTRY_CD = ' || REC_ACCT_RNG.BRND_PROD_CD); 
                   DBMS_OUTPUT.PUT_LINE('  '); 
               END LOOP;
           END LOOP;
       END LOOP;

       DBMS_OUTPUT.PUT_LINE('  ');
       DBMS_OUTPUT.PUT_LINE('  retrieving PROJ_ACCT_RNG by "' || REC_PROJ.PROJ_ID || '"');
       FOR REC_PROJ_ACCT_RNG IN (SELECT * FROM PROJ_ACCT_RNG WHERE PROJ_ID = REC_PROJ.PROJ_ID ORDER BY RNG_STRT_NUM)
       LOOP
           DBMS_OUTPUT.PUT_LINE('      PROJ_ACCT_RNG.PROJ_ID = ' || REC_PROJ_ACCT_RNG.PROJ_ID); 
           DBMS_OUTPUT.PUT_LINE('      PROJ_ACCT_RNG.RNG_STRT_NUM = ' || REC_PROJ_ACCT_RNG.RNG_STRT_NUM); 
           DBMS_OUTPUT.PUT_LINE('      PROJ_ACCT_RNG.STAT_CD = ' || REC_PROJ_ACCT_RNG.STAT_CD); 
           DBMS_OUTPUT.PUT_LINE('      PROJ_ACCT_RNG.DECSN_MATRX_EXPIR_DT_TXT = ' || REC_PROJ_ACCT_RNG.DECSN_MATRX_EXPIR_DT_TXT); 
           DBMS_OUTPUT.PUT_LINE('  ');
           DBMS_OUTPUT.PUT_LINE('      retrieving PROJ_RNG_MAP by "' || REC_PROJ_ACCT_RNG.RNG_STRT_NUM || '"');
           FOR REC_PROJ_RNG_MAP IN (SELECT * FROM PROJ_RNG_MAP WHERE RNG_STRT_NUM = REC_PROJ_ACCT_RNG.RNG_STRT_NUM)
           LOOP
               DBMS_OUTPUT.PUT_LINE('          PROJ_RNG_MAP.RNG_STRT_NUM = ' || REC_PROJ_RNG_MAP.RNG_STRT_NUM); 
               DBMS_OUTPUT.PUT_LINE('          PROJ_RNG_MAP.TOKEN_RNG_STRT_NUM = ' || REC_PROJ_RNG_MAP.TOKEN_RNG_STRT_NUM); 
               DBMS_OUTPUT.PUT_LINE('          PROJ_RNG_MAP.STAT_CD = ' || REC_PROJ_RNG_MAP.STAT_CD); 
               DBMS_OUTPUT.PUT_LINE('          PROJ_RNG_MAP.USER_ID = ' || REC_PROJ_RNG_MAP.USER_ID); 
           END LOOP;
           DBMS_OUTPUT.PUT_LINE('  ');
           DBMS_OUTPUT.PUT_LINE('      retrieving ACCT_RNG_PBLSH by "' || REC_PROJ_ACCT_RNG.RNG_STRT_NUM || '"');
           FOR REC_ACCT_RNG_PBLSH IN (SELECT * FROM ACCT_RNG_PBLSH WHERE RNG_STRT_NUM = REC_PROJ_ACCT_RNG.RNG_STRT_NUM)
           LOOP
               DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.RNG_STRT_NUM = ' || REC_ACCT_RNG_PBLSH.RNG_STRT_NUM); 
               DBMS_OUTPUT.PUT_LINE('          ACCT_RNG_PBLSH.SNPSHT_ID = ' || REC_ACCT_RNG_PBLSH.SNPSHT_ID); 


           END LOOP;
       DBMS_OUTPUT.PUT_LINE('  ');
       END LOOP;
       
   END LOOP;
   
       

END;
/












