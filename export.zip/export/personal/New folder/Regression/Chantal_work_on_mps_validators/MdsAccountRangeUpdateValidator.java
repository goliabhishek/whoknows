package com.mastercard.mdcc.test.validator.mps;

import com.mastercard.mdcc.test.mdccdb.common.enumeration.MimicRequestTypeCode;
import com.mastercard.mdcc.test.validator.AbstractMimicActivityRequestValidator;
import com.mastercard.tokenservices.test.automation.common.constants.BaseConstants;
import com.mastercard.tokenservices.test.automation.common.map.MapOfObjects;

public class MdsAccountRangeUpdateValidator extends AbstractMimicActivityRequestValidator {

    private final String processId = MpsConstants.PROCESS_ID;
    private final String workPackageId = BaseConstants.NO_DEFAULT;
    private final String workPackageDescription = BaseConstants.NO_DEFAULT;
    private final String workPackageEffectiveDate = BaseConstants.NO_DEFAULT;
    private final String workPackageState = BaseConstants.NO_DEFAULT;
    private final String workPackagePriority = BaseConstants.NO_DEFAULT;
    private final String mdsAccountRangeAction = BaseConstants.NO_DEFAULT;
    private final String mdsAccountRangeFrom = BaseConstants.NO_DEFAULT;
    private final String mdsAccountRangeBillingICA = BaseConstants.NO_DEFAULT;
    private final String mdsAccountRangeBin = BaseConstants.NO_DEFAULT;
    private final String mdsAccountRangeCountry = BaseConstants.NO_DEFAULT;
    private final String mdsAccountRangeCurrency = BaseConstants.NO_DEFAULT;
    private final String mdsAccountRangeRtn = BaseConstants.NO_DEFAULT;

    //MDSAccountRangeUpdate.txContext
    public final static String PROCESS_ID = "MDSAccountRangeUpdate.txContext.ProcessId";
    public final static String WORK_PACKAGE_ID = "MDSAccountRangeUpdate.txContext.WorkPackageId";
    public final static String WORK_PACKAGE_DESCRIPTION = "MDSAccountRangeUpdate.txContext.WPDescription";
    public final static String WORK_PACKAGE_EFFECTIVE_DATE = "MDSAccountRangeUpdate.txContext.WPEffectiveDate";
    public final static String WORK_PACKAGE_STATE = "MDSAccountRangeUpdate.txContext.WPState";
    public final static String WORK_PACKAGE_PRIORITY = "MDSAccountRangeUpdate.txContext.WPPriority";

    //MDSAccountRangeUpdate.mdsAccountRange
    public final static String MDS_ACCOUNT_RANGE_ACTION = "MDSAccountRangeUpdate.mdsAccountRange.Action";
    public final static String MDS_ACCOUNT_RANGE_FROM = "MDSAccountRangeUpdate.mdsAccountRange.AccountRangeFrom";
    public final static String MDS_ACCOUNT_RANGE_BILLING_ICA = "MDSAccountRangeUpdate.mdsAccountRange.BillingICA";
    public final static String MDS_ACCOUNT_RANGE_BIN = "MDSAccountRangeUpdate.mdsAccountRange.MDSBIN";
    public final static String MDS_ACCOUNT_RANGE_COUNTRY = "MDSAccountRangeUpdate.mdsAccountRange.Country";
    public final static String MDS_ACCOUNT_RANGE_CURRENCY = "MDSAccountRangeUpdate.mdsAccountRange.Currency";
    public final static String MDS_ACCOUNT_RANGE_RTN = "MDSAccountRangeUpdate.mdsAccountRange.RTN";


    @Override
    public MapOfObjects buildDefaultRequestMap() {

        MapOfObjects defaultMap = new MapOfObjects();
        defaultMap.put(PROCESS_ID, processId);
        defaultMap.put(WORK_PACKAGE_ID, workPackageId);
        defaultMap.put(WORK_PACKAGE_DESCRIPTION, workPackageDescription);
        defaultMap.put(WORK_PACKAGE_EFFECTIVE_DATE, workPackageEffectiveDate);
        defaultMap.put(WORK_PACKAGE_STATE, workPackageState);
        defaultMap.put(WORK_PACKAGE_PRIORITY, workPackagePriority);
        defaultMap.put(MDS_ACCOUNT_RANGE_ACTION, mdsAccountRangeAction);
        defaultMap.put(MDS_ACCOUNT_RANGE_FROM, mdsAccountRangeFrom);
        defaultMap.put(MDS_ACCOUNT_RANGE_BILLING_ICA, mdsAccountRangeBillingICA);
        defaultMap.put(MDS_ACCOUNT_RANGE_BIN, mdsAccountRangeBin);
        defaultMap.put(MDS_ACCOUNT_RANGE_COUNTRY, mdsAccountRangeCountry);
        defaultMap.put(MDS_ACCOUNT_RANGE_CURRENCY, mdsAccountRangeCurrency);
        defaultMap.put(MDS_ACCOUNT_RANGE_RTN, mdsAccountRangeRtn);
        return defaultMap;
    }

    @Override
    public MimicRequestTypeCode getRequestTypeCode() {
        return MimicRequestTypeCode.MPS_GET_WP_INFO;
    }

    //todo: waiting on goli to provide snippet for soap vs json
}
