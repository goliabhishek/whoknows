package com.mastercard.mdcc.test.validator.mps;

import com.mastercard.mdcc.test.mdccdb.common.enumeration.MimicRequestTypeCode;
import com.mastercard.mdcc.test.validator.AbstractMimicActivityRequestValidator;
import com.mastercard.mdcc.test.validator.kms.KmsConstants;
import com.mastercard.tokenservices.test.automation.common.constants.BaseConstants;
import com.mastercard.tokenservices.test.automation.common.map.MapOfObjects;

public class GetTokenAccounRangeRequestValidator extends AbstractMimicActivityRequestValidator {

    private final String processId = MpsConstants.PROCESS_ID;
    private final String brandProduct = BaseConstants.NO_DEFAULT;
    private final String accountRange = BaseConstants.NO_DEFAULT;
    private final String owner = BaseConstants.NO_DEFAULT;

    //GetTokenAccountRange
    public final static String PROCESS_ID = "GetTokenAccountRange.dataContext.ProcessId";
    public final static String BRAND_PRODUCT = "GetTokenAccountRange.BrandProduct";
    public final static String ACCOUNT_RANGE = "GetTokenAccountRange.AccountRange";
    public final static String OWNER = "GetTokenAccountRange.Owner";


    @Override
    public MapOfObjects buildDefaultRequestMap() {

        MapOfObjects defaultMap = new MapOfObjects();
        defaultMap.put(PROCESS_ID, processId);
        defaultMap.put(BRAND_PRODUCT, brandProduct);
        defaultMap.put(ACCOUNT_RANGE, accountRange);
        defaultMap.put(OWNER, owner);
        return defaultMap;
    }

    @Override
    public MimicRequestTypeCode getRequestTypeCode() {
        return MimicRequestTypeCode.MPS_GET_TKN_RNG;
    }

    //todo: waiting on goli to provide snippet for soap vs json
}
