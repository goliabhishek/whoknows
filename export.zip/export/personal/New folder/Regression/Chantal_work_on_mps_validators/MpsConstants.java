package com.mastercard.mdcc.test.validator.mps;

public interface MpsConstants {

    String PROCESS_ID = "MPSMDCC";


}
