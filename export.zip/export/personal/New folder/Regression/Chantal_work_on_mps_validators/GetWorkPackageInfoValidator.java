package com.mastercard.mdcc.test.validator.mps;

import com.mastercard.mdcc.test.mdccdb.common.enumeration.MimicRequestTypeCode;
import com.mastercard.mdcc.test.validator.AbstractMimicActivityRequestValidator;
import com.mastercard.tokenservices.test.automation.common.constants.BaseConstants;
import com.mastercard.tokenservices.test.automation.common.map.MapOfObjects;

public class GetWorkPackageInfoValidator extends AbstractMimicActivityRequestValidator {

    private final String processId = MpsConstants.PROCESS_ID;
    private final String workPackageId = BaseConstants.NO_DEFAULT;

    //GetWorkPackageInfo
    public final static String PROCESS_ID = "GetWorkPackageInfo.dataContext.ProcessId";
    public final static String WORK_PACKAGE_ID = "GetWorkPackageInfo.WorkPackageId";

    @Override
    public MapOfObjects buildDefaultRequestMap() {

        MapOfObjects defaultMap = new MapOfObjects();
        defaultMap.put(PROCESS_ID, processId);
        defaultMap.put(WORK_PACKAGE_ID, workPackageId);
        return defaultMap;
    }

    @Override
    public MimicRequestTypeCode getRequestTypeCode() {
        return MimicRequestTypeCode.MPS_GET_WP_INFO;
    }

    //todo: waiting on goli to provide snippet for soap vs json
}
