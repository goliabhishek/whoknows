CREATE OR REPLACE PACKAGE            PKG_DATA_MANAGEMENT
AS
   /***************************************************************************
       NAME:    PKG_DATA_MANAGEMENT
       PURPOSE: Package used for new automated testing framework
       -------------------------------------------------------------------------
       REVISIONS:
       Version     DATE     DESCRIPTION
       -------  ----------  ----------------------------------------------------
         1.0    03/30/2016  Version created for inital flyway testing
         1.1    05/30/2016  S194390: added support for TSP (no dpans) Account 
                            Ranges
         1.2    06/08/2016  Added support for APPL_USER
         1.3    08/15/2017  Fix to PRC_ACCT_RNG_ADD_FPAN to support TSP.
         1.4    08/18/2017  Add support for new WLT_PRVDR_CUST_MAP table.
         1.5    08/18/2017  Add support for new REDIG_NOTIF_TOKEN table.
         1.6    08/22/2017  Add support to optionally clone CLNT data when 
                            cloning a customer.
         1.7    08/24/2017  Add support for deleting external TSP tokens.
         1.8    10/20/2017  Added support for PRDCT_CONFIG_ACS_CTRL table.
         1.9    11/30/2017  Added support for PRTNR_FTR when cloning CLNT.
   ****************************************************************************/

   PROCEDURE PRC_ACCT_RNG_CLONE (
                     in_base_rng_strt_num             IN NUMBER,   --required
                     in_new_fpan_rng_strt_num         IN NUMBER,   --required
                     in_new_tsp_sw                    IN VARCHAR2, --required
                     in_new_partn_num                 IN NUMBER,   --optional
                     in_new_card_len_num              IN NUMBER,   --optional
                     in_new_cust_id                   IN NUMBER,   --optional
                     in_new_config_uuid               IN VARCHAR2, --optional
                     in_new_idv_rule_set_id           IN NUMBER,   --optional
                     in_new_ntwrk_msg_ids             IN VARCHAR2, --optional
                     in_new_dvc_dpan_rng_strt_num     IN NUMBER,   --optional
                     in_new_cof_dpan_rng_strt_num     IN NUMBER,   --optional
                     out_rtn_cd                      OUT NUMBER,
                     out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_ACCT_RNG_ADD_DPAN (
                     in_fpan_rng_strt_num            IN  NUMBER,   --required
                     in_new_dpan_rng_strt_num        IN  NUMBER,   --required
                     in_new_token_serv_cd            IN  VARCHAR2, --required
                     in_partn_num                    IN  NUMBER,   --optional
                     out_rtn_cd                      OUT NUMBER,
                     out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_ACCT_RNG_ADD_FPAN (
                     in_base_rng_strt_num             IN NUMBER,   --required
                     in_new_fpan_rng_strt_num         IN NUMBER,   --required
                     in_new_tsp_sw                    IN VARCHAR2, --required
                     in_new_two_srs_token_enbl_sw     IN VARCHAR2, --required
                     in_new_partn_num                 IN NUMBER,   --optional
                     in_new_card_len_num              IN NUMBER,   --optional
                     in_new_cust_id                   IN NUMBER,   --optional
                     in_new_config_uuid               IN VARCHAR2, --optional
                     in_new_idv_rule_set_id           IN NUMBER,   --optional
                     out_rtn_cd                       OUT NUMBER,
                     out_rtn_msg                      OUT VARCHAR2);
   PROCEDURE PRC_ACCT_RNG_DELETE (
                    in_rng_strt_num                 IN  NUMBER, --required
                    in_partn_num                    IN  NUMBER, --optional
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_ACCT_RNG_CLONE_WID (
                    in_new_rng_strt_num             IN  NUMBER, --required
                    in_new_partn_num                IN  NUMBER, --optional
                    in_base_wlt_prvdr_id            IN  NUMBER, --required
                    in_cloned_wlt_prvdr_id          IN  NUMBER, --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_ACCT_RNG_CLONE_MWA (
                    in_new_rng_strt_num             IN  NUMBER,   --required
                    in_new_partn_num                IN  NUMBER,   --optional
                    in_base_mbl_wlt_id              IN  VARCHAR2, --required
                    in_cloned_mbl_wlt_id            IN  VARCHAR2, --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_ACCT_RNG_SET_NTWRK_MSG (
                    in_fpan_rng_strt_num            IN  NUMBER,   --required
                    in_ntwrk_msg_ids                IN  VARCHAR2, --required
                    in_token_serv_cd                IN  VARCHAR2, --required
                    in_partn_num                    IN  NUMBER,   --optional
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_CLNT_CLONE (
                    in_base_clnt_id                 IN  VARCHAR, --required
                    in_new_clnt_id                  IN  VARCHAR, --required
                    in_clone_cust_data_sw           IN  VARCHAR, --required
                    in_merchant_type_sw             IN  VARCHAR, --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_CLNT_ADD (
                    in_base_clnt_id                 IN  VARCHAR, --required
                    in_new_clnt_id                  IN  VARCHAR, --required
                    in_clone_cust_data_sw           IN  VARCHAR, --required
                    in_merchant_type_sw             IN  VARCHAR, --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_CLNT_DELETE (
                    in_clnt_id                      IN  VARCHAR,  --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_CUST_ADD (
                    in_base_cust_id                 IN  NUMBER,   --required
                    in_new_cust_id                  IN  NUMBER,   --required
                    in_new_prefix                   IN  VARCHAR2, --required 
                    in_clone_clnt_data_sw           IN  VARCHAR,  --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_CUST_CLONE (
                    in_base_cust_id                 IN  NUMBER,   --required
                    in_new_cust_id                  IN  NUMBER,   --required
                    in_new_prefix                   IN  VARCHAR2, --required 
                    in_clone_clnt_data_sw           IN  VARCHAR,  --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_CUST_DELETE (
                    in_cust_id                      IN  VARCHAR2,  --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_CUST_CLNT_CLONE (
                     in_base_cust_id                  IN NUMBER,   --required
                     in_new_cust_id                   IN NUMBER,   --required
                     in_base_clnt_id                  IN VARCHAR2, --required
                     in_new_clnt_id                   IN VARCHAR2, --required
                     out_rtn_cd                      OUT NUMBER,
                     out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_CUST_CLNT_ADD (
                    in_cust_id                      IN  NUMBER,   --required
                    in_clnt_id                      IN  VARCHAR2, --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_CUST_CLNT_DELETE (
                    in_cust_id                      IN  NUMBER,   --required
                    in_clnt_id                      IN  VARCHAR2, --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_PRDCT_CONFIG_CLONE (
                     in_base_config_uuid             IN VARCHAR2, --required
                     in_new_config_uuid              IN VARCHAR2, --required
                     in_new_cust_id                  IN VARCHAR2, --optional
                     in_new_config_cd                IN VARCHAR2, --optional
                     out_rtn_cd                      OUT NUMBER,
                     out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_PRDCT_CONFIG_ADD (
                    in_base_config_uuid             IN  VARCHAR,  --required
                    in_new_config_uuid              IN  VARCHAR,  --required
                    in_new_cust_id                  IN  NUMBER,   --optional
                    in_new_config_cd                IN  VARCHAR,  --optional
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_PRDCT_CONFIG_DELETE (
                    in_config_uuid                  IN  VARCHAR,   --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_TOKEN_RQSTR_CLONE (
                     in_base_token_rqstr_id           IN  NUMBER,   --required
                     in_new_token_rqstr_id            IN  NUMBER,   --required
                     in_new_token_rqstr_nam           IN  VARCHAR2, --optional
                     in_new_partn_num                 IN  NUMBER,   --optional
                     in_new_token_assurance_lvl_num   IN  NUMBER,   --optional
                     out_rtn_cd                       OUT NUMBER,
                     out_rtn_msg                      OUT VARCHAR2);
   PROCEDURE PRC_TOKEN_RQSTR_ADD (
                    in_base_token_rqstr_id            IN  NUMBER,   --required
                    in_new_token_rqstr_id             IN  NUMBER,   --required
                    in_new_token_rqstr_nam            IN  VARCHAR2, --optional
                    in_new_partn_num                  IN  NUMBER,   --optional
                    in_new_token_assurance_lvl_num    IN  NUMBER,   --optional
                    out_rtn_cd                        OUT NUMBER,
                    out_rtn_msg                       OUT VARCHAR2);
   PROCEDURE PRC_TOKEN_RQSTR_DELETE (
                    in_token_rqstr_id               IN  NUMBER, --required
                    in_partn_num                    IN  NUMBER, --optional                        
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_WLT_PRVDR_ADD (
                    in_base_wlt_prvdr_id            IN  NUMBER,  --required
                    in_new_wlt_prvdr_id             IN  NUMBER,  --required
                    in_new_wlt_prvdr_name           IN  VARCHAR, --optional
                    in_new_partn_num                IN  NUMBER,  --optional
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_WLT_PRVDR_CLONE (
                    in_base_wlt_prvdr_id            IN  NUMBER,   --required
                    in_new_wlt_prvdr_id             IN  NUMBER,   --required
                    in_new_wlt_prvdr_name           IN  VARCHAR2, --optional
                    in_new_partn_num                IN  NUMBER,   --optional
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_WLT_PRVDR_DELETE (
                    in_wlt_prvdr_id                 IN  NUMBER, --required
                    in_partn_num                    IN  NUMBER, --optional                        
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_MBL_WLT_APPL_ADD (
                    in_base_mbl_wlt_id              IN  VARCHAR2, --required
                    in_new_mbl_wlt_id               IN  VARCHAR2, --required
                    in_new_mbl_wlt_name             IN  VARCHAR2, --optional
                    in_new_wlt_prvdr_id             IN  NUMBER,   --optional
                    in_partn_num                    IN  NUMBER,   --optional
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_MBL_WLT_APPL_CLONE (
                     in_base_mbl_wlt_id             IN  VARCHAR2, --required
                     in_new_mbl_wlt_id              IN  VARCHAR2, --required
                     in_new_mbl_wlt_name            IN  VARCHAR2, --optional
                     in_new_wlt_prvdr_id            IN  NUMBER,   --optional
                     in_new_partn_num               IN  NUMBER,   --optional
                     out_rtn_cd                     OUT NUMBER,
                     out_rtn_msg                    OUT VARCHAR2);
   PROCEDURE PRC_MBL_WLT_APPL_DELETE (
                    in_mbl_wlt_id                   IN  VARCHAR,  --required
                    in_partn_num                    IN  NUMBER,   --optional
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_APPL_USER_CLONE (
                    in_base_clnt_appl_id            IN VARCHAR2, --required
                    in_new_clnt_appl_id             IN VARCHAR2, --required
                    in_base_token_rqstr_id          IN NUMBER,   --required
                    in_new_token_rqstr_id           IN NUMBER,   --required
                    in_new_wlt_prvdr_id             IN NUMBER,   --optional
                    in_new_sys_user_id              IN VARCHAR2, --optional
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_APPL_USER_ADD (
                    in_base_clnt_appl_id            IN VARCHAR2, --required
                    in_new_clnt_appl_id             IN VARCHAR2, --required
                    in_base_token_rqstr_id          IN NUMBER,   --required
                    in_new_token_rqstr_id           IN NUMBER,   --required
                    in_new_wlt_prvdr_id             IN NUMBER,   --optional
                    in_new_sys_user_id              IN VARCHAR2, --optional
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_APPL_USER_DELETE (
                    in_clnt_appl_id                 IN VARCHAR2, --required
                    in_token_rqstr_id               IN NUMBER,   --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_DELETE_TOKEN (
                    in_map_id                       IN  NUMBER,   --required
                    in_dpan                         IN  VARCHAR2, --optional                        
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_DELETE_TOKEN_BY_FPAN_RNG (
                    in_fpan_rng_strt_num            IN  NUMBER,   --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
   PROCEDURE PRC_DELETE_DPAN_POOL_DATA (
                    in_fpan_rng_strt_num            IN  NUMBER,   --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);
 PROCEDURE PRC_WHITE_CARD_DELETE (
                    in_fpan_rng_strt_num            IN  NUMBER,   --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2);

   PROCEDURE PRVT_DELETE_ACCT_RNG_MWA_DATA(
                      in_rng_strt_num               IN  NUMBER,    --optional
                      in_partn_num                  IN  NUMBER,    --optional
                      in_mbl_wlt_appl_id            IN  VARCHAR2); --required
   PROCEDURE PRVT_DELETE_ACCT_RNG_WID_DATA(
                      in_rng_strt_num               IN  NUMBER,    --optional
                      in_partn_num                  IN  NUMBER,    --optional
                      in_wlt_prvdr_id               IN  NUMBER);   --required
                      
   FUNCTION GENERATE_CLONED_ID (
                      in_base_id                    IN  VARCHAR2,  --required
                      in_prefix                     IN  VARCHAR2,  --required
                      in_max_len                    IN  NUMBER)   --required
                      RETURN VARCHAR2;

END PKG_DATA_MANAGEMENT;






/


CREATE OR REPLACE PACKAGE BODY            PKG_DATA_MANAGEMENT
AS
   -- Global constants for this package
   gvc_const_pkg_name   CONSTANT VARCHAR2 (200) := 'PKG_DATA_MANAGEMENT';

   PROCEDURE PRC_ACCT_RNG_CLONE (
                     in_base_rng_strt_num             IN NUMBER,   --required
                     in_new_fpan_rng_strt_num         IN NUMBER,   --required
                     in_new_tsp_sw                    IN VARCHAR2, --required
                     in_new_partn_num                 IN NUMBER,   --optional
                     in_new_card_len_num              IN NUMBER,   --optional
                     in_new_cust_id                   IN NUMBER,   --optional
                     in_new_config_uuid               IN VARCHAR2, --optional
                     in_new_idv_rule_set_id           IN NUMBER,   --optional
                     in_new_ntwrk_msg_ids             IN VARCHAR2, --optional
                     in_new_dvc_dpan_rng_strt_num     IN NUMBER,   --optional
                     in_new_cof_dpan_rng_strt_num     IN NUMBER,   --optional
                     out_rtn_cd                      OUT NUMBER,
                     out_rtn_msg                     OUT VARCHAR2)

   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_ACCT_RNG_CLONE';
      v_dvc_dpan                      VARCHAR2 (19);
      v_cof_dpan                      VARCHAR2 (19);
      v_server_host                   VARCHAR2(100);
      v_two_srs_token_enbl_sw         FPAN_ACCT_RNG.TWO_SRS_TOKEN_ENBL_SW%TYPE;
      REQUIRED_PARM_NULL              EXCEPTION;
      MUTUALLY_EXCLUSIVE_PARMS        EXCEPTION;
      BAD_RETURN                      EXCEPTION;

   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ...');
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- purely for trouble-shooting:
      --------------------------------------------------------------------------
      SELECT sys_context('USERENV', 'SERVER_HOST') INTO v_server_host FROM DUAL;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_server_host='||v_server_host);

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_rng_strt_num IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_base_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_fpan_rng_strt_num IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_new_fpan_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_tsp_sw IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_new_tsp_sw cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- check mutually exclusive parameters:
      --------------------------------------------------------------------------
      IF in_new_tsp_sw = 'Y' THEN
          IF in_new_dvc_dpan_rng_strt_num IS NOT NULL OR in_new_cof_dpan_rng_strt_num IS NOT NULL THEN
              out_rtn_msg := vc_proc_name || ': in_new_tsp_sw = Y but dpan range(s) provided!';
              RAISE MUTUALLY_EXCLUSIVE_PARMS;
          END IF;
      ELSE 
          IF in_new_dvc_dpan_rng_strt_num IS NULL AND in_new_cof_dpan_rng_strt_num IS NULL THEN
              out_rtn_msg := vc_proc_name || ': in_new_tsp_sw = N but no dpan ranges(s) provided!';
              RAISE MUTUALLY_EXCLUSIVE_PARMS;
          END IF;
      END IF;

      --------------------------------------------------------------------------
      -- first delete existing data for new fpan range:
      --------------------------------------------------------------------------
      PRC_ACCT_RNG_DELETE(in_new_fpan_rng_strt_num, 
                          in_new_partn_num,
                          out_rtn_cd,
                          out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       

      --------------------------------------------------------------------------
      -- then before creating the new fpan range ... look at dpan data passed
      -- to determine what the value should be TWO_SRS_TOKEN_ENBL_SW:
      --------------------------------------------------------------------------
      v_two_srs_token_enbl_sw := 'N';
      IF in_new_tsp_sw = 'N' THEN
          v_dvc_dpan := ' ';
          IF in_new_dvc_dpan_rng_strt_num IS NOT NULL THEN
              v_dvc_dpan := TO_CHAR(in_new_dvc_dpan_rng_strt_num);
          END IF;
          v_cof_dpan := ' ';
          IF in_new_cof_dpan_rng_strt_num IS NOT NULL THEN
              v_cof_dpan := TO_CHAR(in_new_cof_dpan_rng_strt_num);
          END IF;
          IF SUBSTR(v_dvc_dpan,1,1) = '2' OR SUBSTR(v_cof_dpan,1,1) = '2' THEN
              v_two_srs_token_enbl_sw := 'Y';
          END IF;
      END IF;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_two_srs_token_enbl_sw='
          ||v_two_srs_token_enbl_sw);

      --------------------------------------------------------------------------
      -- now create the new fpan range:
      --------------------------------------------------------------------------
      PRC_ACCT_RNG_ADD_FPAN(in_base_rng_strt_num, 
                            in_new_fpan_rng_strt_num,
                            in_new_tsp_sw,
                            v_two_srs_token_enbl_sw,
                            in_new_partn_num, 
                            in_new_card_len_num,
                            in_new_cust_id, 
                            in_new_config_uuid,
                            in_new_idv_rule_set_id,
                            out_rtn_cd,
                            out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       

      --------------------------------------------------------------------------
      -- override the cloned network/issuer configuration (if requested):
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': in_new_ntwrk_msg_ids='
          ||in_new_ntwrk_msg_ids);
      IF in_new_ntwrk_msg_ids IS NOT NULL THEN
          PRC_ACCT_RNG_SET_NTWRK_MSG(in_new_fpan_rng_strt_num,
                                     in_new_ntwrk_msg_ids, 
                                     '098', 
                                     in_new_partn_num,
                                     out_rtn_cd,
                                     out_rtn_msg);
          IF out_rtn_cd <> 0 THEN
              RAISE BAD_RETURN;
          END IF;                       
          
          PRC_ACCT_RNG_SET_NTWRK_MSG(in_new_fpan_rng_strt_num,
                                     in_new_ntwrk_msg_ids, 
                                     '100', 
                                     in_new_partn_num,
                                     out_rtn_cd,
                                     out_rtn_msg);
          IF out_rtn_cd <> 0 THEN
              RAISE BAD_RETURN;
          END IF;     
      END IF;

      --------------------------------------------------------------------------
      -- and finally create the new dpan ranges (if applicable):
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': in_new_tsp_sw='
          ||in_new_tsp_sw);
      IF in_new_tsp_sw = 'N' THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': in_new_dvc_dpan_rng_strt_num='
              ||in_new_dvc_dpan_rng_strt_num);
          IF in_new_dvc_dpan_rng_strt_num IS NOT NULL THEN                 
              PRC_ACCT_RNG_ADD_DPAN(in_new_fpan_rng_strt_num, 
                                    in_new_dvc_dpan_rng_strt_num, 
                                    '098',
                                    in_new_partn_num,
                                    out_rtn_cd,
                                    out_rtn_msg);
             IF out_rtn_cd <> 0 THEN
                 RAISE BAD_RETURN;
             END IF;    
          END IF;                   

          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': in_new_cof_dpan_rng_strt_num='
              ||in_new_cof_dpan_rng_strt_num);
          IF in_new_cof_dpan_rng_strt_num IS NOT NULL THEN                 
              PRC_ACCT_RNG_ADD_DPAN(in_new_fpan_rng_strt_num, 
                                    in_new_cof_dpan_rng_strt_num, 
                                    '100',
                                    in_new_partn_num,
                                    out_rtn_cd,
                                    out_rtn_msg);
              IF out_rtn_cd <> 0 THEN
                 RAISE BAD_RETURN;
              END IF;
          END IF;
      END IF;                      
                          
      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_new_fpan_rng_strt_num 
                     || in_new_partn_num || ' successfully cloned!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;
      WHEN MUTUALLY_EXCLUSIVE_PARMS THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;
      WHEN BAD_RETURN THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1003;
          ROLLBACK;
      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1000;
         out_rtn_msg := vc_proc_name || ': ' || in_new_fpan_rng_strt_num
                        || in_new_partn_num || ' not cloned, Oracle error = '
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_ACCT_RNG_CLONE;
   PROCEDURE PRC_ACCT_RNG_ADD_DPAN (
                      in_fpan_rng_strt_num            IN  NUMBER,   --required
                      in_new_dpan_rng_strt_num        IN  NUMBER,   --required
                      in_new_token_serv_cd            IN  VARCHAR2, --required
                      in_partn_num                    IN  NUMBER,   --optional
                      out_rtn_cd                      OUT NUMBER,
                      out_rtn_msg                     OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_ACCT_RNG_ADD_DPAN';
      v_active_partn_num              ACTV_PARTN.PARTN_NUM%TYPE;
      v_partn_num                     ACTV_PARTN.PARTN_NUM%TYPE;
      v_fpan_rng_strt_num             FPAN_ACCT_RNG.RNG_STRT_NUM%TYPE;
      v_new_dpan_rng_strt_num         DPAN_ACCT_RNG.RNG_STRT_NUM%TYPE;
      v_new_dpan_rng_end_num          DPAN_ACCT_RNG.RNG_END_NUM%TYPE;
      v_new_srs_num                   DPAN_ACCT_RNG.SRS_NUM%TYPE;    
      v_count                         NUMBER;
      v_dpan_rng_strt_num             VARCHAR2(19);
      INVALID_TOKEN_SERV_CD           EXCEPTION;
      REQUIRED_PARM_NULL              EXCEPTION;
      NOT_FOUND                       EXCEPTION;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ...');
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- get active partition:
      --------------------------------------------------------------------------
      SELECT partn_num INTO v_active_partn_num FROM ACTV_PARTN;
      IF in_partn_num IS NULL THEN
          v_partn_num := v_active_partn_num;
      ELSE
          v_partn_num := in_partn_num;
      END IF;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_active_partn_num: '|| v_active_partn_num);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_partn_num: '|| v_partn_num);

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_fpan_rng_strt_num IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_fpan_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_dpan_rng_strt_num IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_new_dpan_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_token_serv_cd IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_new_token_serv_cd cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
     
      --------------------------------------------------------------------------
      -- reformat ranges into 19 digit values:
      --------------------------------------------------------------------------
      v_fpan_rng_strt_num          := RPAD (in_fpan_rng_strt_num, 19, '0');
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_fpan_rng_strt_num: '|| v_fpan_rng_strt_num);
      v_new_dpan_rng_strt_num      := RPAD (in_new_dpan_rng_strt_num, 19, '0');
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_new_dpan_rng_strt_num: '|| v_new_dpan_rng_strt_num);
      v_new_dpan_rng_end_num       := RPAD (in_new_dpan_rng_strt_num, 19, '9');
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_new_dpan_rng_end_num: '|| v_new_dpan_rng_end_num);

      --------------------------------------------------------------------------
      -- edit token_serv_cd:
      --------------------------------------------------------------------------
      IF in_new_token_serv_cd <> '098' AND in_new_token_serv_cd <> '100' THEN
          out_rtn_msg := vc_proc_name || ': invalid in_new_token_serv_cd: ' || in_new_token_serv_cd;
          RAISE INVALID_TOKEN_SERV_CD;
      END IF;

      --------------------------------------------------------------------------
      -- make sure fpan range already exists:
      --------------------------------------------------------------------------
      SELECT COUNT(*) INTO v_count FROM FPAN_ACCT_RNG 
       WHERE PARTN_NUM = v_partn_num 
         AND RNG_STRT_NUM = v_fpan_rng_strt_num;
      IF v_count = 0 THEN
          out_rtn_msg := vc_proc_name || ': v_partn_num=' || v_partn_num 
                         || ', v_fpan_rng_strt_num=' || v_fpan_rng_strt_num 
                         || ' not found in FPAN_ACCT_RNG!';
          RAISE NOT_FOUND;
      END IF;      

      --------------------------------------------------------------------------
      -- determine SRS_NUM based on first digit of dpan range:
      --------------------------------------------------------------------------
      v_dpan_rng_strt_num := TO_CHAR(v_new_dpan_rng_strt_num);
      v_new_srs_num := SUBSTR(v_dpan_rng_strt_num,1,1);

      --------------------------------------------------------------------------
      -- insert DPAN_ACCT_RNG:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': INSERT INTO DPAN_ACCT_RNG: '
          || v_partn_num || ', ' 
          || v_new_dpan_rng_strt_num || ', '
          || v_new_dpan_rng_end_num || ', '
          || v_fpan_rng_strt_num || ', '
          || in_new_token_serv_cd);
      INSERT INTO DPAN_ACCT_RNG 
          (DCMSN_SW, FPAN_RNG_STRT_NUM, PARTN_NUM, RNG_END_NUM, RNG_STRT_NUM, 
           RPLCTN_UPDT_TS, SRS_NUM, TOKEN_SERV_CD)
      VALUES ('N', v_fpan_rng_strt_num, v_partn_num, v_new_dpan_rng_end_num,
              v_new_dpan_rng_strt_num, SYSDATE, v_new_srs_num, 
              in_new_token_serv_cd);

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || v_partn_num || ',' ||
                     v_new_dpan_rng_strt_num || ',' || in_new_token_serv_cd ||
                     ' added!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;
      WHEN NOT_FOUND THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;
      WHEN INVALID_TOKEN_SERV_CD THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1004;
          ROLLBACK;
      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || v_partn_num || ',' ||
                        v_new_dpan_rng_strt_num || ',' || in_new_token_serv_cd ||
                        ' ADD FAILED, ORACLE ERROR = ' || 
                        SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_ACCT_RNG_ADD_DPAN;
   PROCEDURE PRC_ACCT_RNG_ADD_FPAN (
                     in_base_rng_strt_num             IN NUMBER,   --required
                     in_new_fpan_rng_strt_num         IN NUMBER,   --required
                     in_new_tsp_sw                    IN VARCHAR2, --required
                     in_new_two_srs_token_enbl_sw     IN VARCHAR2, --required
                     in_new_partn_num                 IN NUMBER,   --optional
                     in_new_card_len_num              IN NUMBER,   --optional
                     in_new_cust_id                   IN NUMBER,   --optional
                     in_new_config_uuid               IN VARCHAR2, --optional
                     in_new_idv_rule_set_id           IN NUMBER,   --optional
                     out_rtn_cd                       OUT NUMBER,
                     out_rtn_msg                      OUT VARCHAR2)
   IS
      TYPE MSG_ARRAY_TYPE IS VARRAY(5) OF VARCHAR2(250); 

      vc_proc_name                    VARCHAR2 (50) := 'PRC_ACCT_RNG_ADD_FPAN';
      v_active_partn_num              ACTV_PARTN.PARTN_NUM%TYPE;
      v_new_partn_num                 ACTV_PARTN.PARTN_NUM%TYPE;
      v_base_fpan_rng_strt_num        FPAN_ACCT_RNG.RNG_STRT_NUM%TYPE;
      v_new_fpan_rng_strt_num         FPAN_ACCT_RNG.RNG_STRT_NUM%TYPE;
      v_new_fpan_rng_end_num          FPAN_ACCT_RNG.RNG_END_NUM%TYPE;
      v_count                         NUMBER;
      v_idx                           INTEGER := 0;
      x                               INTEGER := 0;
      v_msg                           VARCHAR2(250);
      v_msg_concatenated              VARCHAR2(5000);
      v_wlt_prvdr_id_list             VARCHAR(100);
      v_wlt_prvdr_id                  VARCHAR(3);
      v_mbl_wlt_id_list               VARCHAR(100);
      v_mbl_wlt_id                    VARCHAR(30);
      v_cust_id_new_acct_rng          CUST.CUST_ID%TYPE;
      v_cust_id_prdct_config          CUST.CUST_ID%TYPE;
      v_cust_id_rules                 CUST.CUST_ID%TYPE;
      v_idv_rule_set_id               RULE_SET.RULE_SET_ID%TYPE;
      v_config_uuid                   PRDCT_CONFIG.CONFIG_UUID%TYPE;
      v_addl_message_info             MSG_ARRAY_TYPE;
      rec_acct_rng_accum              ACCT_RNG_ACCUM%ROWTYPE;
      rec_acct_rng_accum_curr_conv    ACCT_RNG_ACCUM_CURR_CONV%ROWTYPE;
      rec_acct_rng_lang               ACCT_RNG_LANG%ROWTYPE;
      rec_acct_rng_mbl_wlt_appl       ACCT_RNG_MBL_WLT_APPL%ROWTYPE;
      rec_acct_rng_mbl_wlt_appl_cvm   ACCT_RNG_MBL_WLT_APPL_CVM%ROWTYPE;
      rec_acct_rng_mdes_bitmap_parm   ACCT_RNG_MDES_BITMAP_PARM%ROWTYPE;
      rec_acct_rng_mdes_brnd_prdct    ACCT_RNG_MDES_BRND_PRDCT%ROWTYPE;
      rec_acct_rng_mdes_parm          ACCT_RNG_MDES_PARM%ROWTYPE;
      rec_acct_rng_ntwrk_msg          ACCT_RNG_NTWRK_MSG%ROWTYPE;
      rec_acct_rng_token_type         ACCT_RNG_TOKEN_TYPE%ROWTYPE;
      rec_acct_rng_token_type_pem     ACCT_RNG_TOKEN_TYPE_PEM%ROWTYPE;
      rec_acct_rng_wlt_prvdr          ACCT_RNG_WLT_PRVDR%ROWTYPE;
      rec_acct_rng_wlt_prvdr_config   ACCT_RNG_WLT_PRVDR_CONFIG%ROWTYPE;
      rec_ar_crdhldr_actv_cd_mthd     AR_CRDHLDR_ACTV_CD_MTHD%ROWTYPE;
      rec_fpan_acct_rng               FPAN_ACCT_RNG%ROWTYPE;
      rec_issr_tds_config             ISSR_TDS_CONFIG%ROWTYPE;
      
      REQUIRED_PARM_NULL              EXCEPTION;
      NOT_FOUND                       EXCEPTION;
      PARM_VALUE_MISMATCH             EXCEPTION;
      CUST_ID_MISMATCH                EXCEPTION;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ...');
      out_rtn_cd := 0;
      out_rtn_msg :=  vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- get active partition:
      --------------------------------------------------------------------------
      SELECT partn_num INTO v_active_partn_num FROM ACTV_PARTN;
      IF in_new_partn_num IS NULL THEN
          v_new_partn_num := v_active_partn_num;
      ELSE
          v_new_partn_num := in_new_partn_num;
      END IF;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': v_active_partn_num: '|| v_active_partn_num);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': v_new_partn_num: '|| v_new_partn_num);

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_rng_strt_num IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_base_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_fpan_rng_strt_num IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_new_fpan_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- reformat ranges into 19 digit values:
      --------------------------------------------------------------------------
      v_base_fpan_rng_strt_num := RPAD (in_base_rng_strt_num, 19, '0');
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': v_base_fpan_rng_strt_num: '|| v_base_fpan_rng_strt_num);
      v_new_fpan_rng_strt_num := RPAD (in_new_fpan_rng_strt_num, 19, '0');
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': v_new_fpan_rng_strt_num: '|| v_new_fpan_rng_strt_num);
      v_new_fpan_rng_end_num := RPAD (in_new_fpan_rng_strt_num, 19, '9');
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': v_new_fpan_rng_end_num: '|| v_new_fpan_rng_end_num);

      --------------------------------------------------------------------------
      -- make sure range to be cloned exists:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': checking that FPAN_ACCT_RNG=' || v_base_fpan_rng_strt_num
          || ' exists!');
      SELECT COUNT(*) INTO v_count FROM FPAN_ACCT_RNG 
       WHERE PARTN_NUM = v_active_partn_num 
         AND RNG_STRT_NUM = v_base_fpan_rng_strt_num;
      IF v_count = 0 THEN
          out_rtn_msg := vc_proc_name 
                         || ': v_active_partn_num=' || v_active_partn_num 
                         || ', v_base_fpan_rng_strt_num=' || v_base_fpan_rng_strt_num 
                         || ' not found in FPAN_ACCT_RNG!';
          RAISE NOT_FOUND;
      END IF;      


      --------------------------------------------------------------------------
      -- make sure that CUST_ID for the new cloned account range and matches  
      -- the CUST_ID for PRDCT_CONFIG/RULES that will be associated with the new
      -- cloned account range.
      --------------------------------------------------------------------------
    
      v_addl_message_info := MSG_ARRAY_TYPE('','','','','');
      
      -- determine CUST_ID that will be associated with new cloned account range:
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': checking CUST_IDs');      
      IF in_new_cust_id IS NULL THEN
          SELECT CUST_ID INTO v_cust_id_new_acct_rng FROM ACCT_RNG_MDES_PARM
           WHERE PARTN_NUM = v_active_partn_num
             AND RNG_STRT_NUM = v_base_fpan_rng_strt_num;
          v_idx := v_idx+1;
          v_addl_message_info(v_idx) := 'ACCT_RNG_MDES_PARM(' || 
              v_base_fpan_rng_strt_num || ').CUST_ID=' || v_cust_id_new_acct_rng;
      ELSE
          v_cust_id_new_acct_rng := in_new_cust_id;
          v_idx := v_idx+1;
          v_addl_message_info(v_idx) := 'ACCT_RNG_MDES_PARM(' || 
              v_new_fpan_rng_strt_num || ').CUST_ID=' || v_cust_id_new_acct_rng;
      END IF;
      
      --get PRDCT_CONFIG's CUST_ID for the PRDCT_CONFIG that will be associated
      --with the new cloned account range:
      IF in_new_config_uuid IS NULL THEN
          SELECT CONFIG_UUID INTO v_config_uuid
            FROM ACCT_RNG_MDES_BRND_PRDCT
           WHERE PARTN_NUM = v_active_partn_num
             AND RNG_STRT_NUM = v_base_fpan_rng_strt_num;
          v_idx := v_idx+1;
          v_addl_message_info(v_idx) := 'ACCT_RNG_MDES_BRND_PRDCT(' 
              || v_base_fpan_rng_strt_num || ').CONFIG_UUID=' || v_config_uuid;
          IF v_config_uuid IS NULL THEN
              v_cust_id_prdct_config := NULL;
          ELSE 
              SELECT CUST_ID INTO v_cust_id_prdct_config FROM PRDCT_CONFIG
               WHERE CONFIG_UUID = v_config_uuid;
              v_idx := v_idx+1;
              v_addl_message_info(v_idx) := 'PRDCT_CONFIG(' || v_config_uuid 
                  || ').CUST_ID=' || v_cust_id_prdct_config;
          END IF;
      ELSE
          v_idx := v_idx+1;
          v_addl_message_info(v_idx) := 'ACCT_RNG_MDES_BRND_PRDCT(' 
              || v_new_fpan_rng_strt_num || ').CONFIG_UUID=' || in_new_config_uuid;
          SELECT CUST_ID INTO v_cust_id_prdct_config FROM PRDCT_CONFIG
           WHERE CONFIG_UUID = in_new_config_uuid;
          v_idx := v_idx+1;
          v_addl_message_info(v_idx) := 'PRDCT_CONFIG(' || in_new_config_uuid 
              || ').CUST_ID=' || v_cust_id_prdct_config;
      END IF;
      
      --get RULE_SET's CUST_ID for the IDV_RULE_SET_ID that will be associated
      --with the new cloned account range:
      IF in_new_idv_rule_set_id IS NULL THEN
          SELECT IDV_RULE_SET_ID INTO v_idv_rule_set_id 
            FROM ACCT_RNG_MDES_PARM
           WHERE PARTN_NUM = v_active_partn_num
             AND RNG_STRT_NUM = v_base_fpan_rng_strt_num;
          v_idx := v_idx+1;
          v_addl_message_info(v_idx) := 'ACCT_RNG_MDES_PARM(' 
              || v_base_fpan_rng_strt_num || ').IDV_RULE_SET_ID=' 
              || v_idv_rule_set_id;
          IF v_idv_rule_set_id IS NULL THEN
              v_cust_id_rules := NULL;
          ELSE 
              SELECT CUST_ID INTO v_cust_id_rules FROM RULE_SET
               WHERE RULE_SET_ID = v_idv_rule_set_id;
              v_idx := v_idx+1;
              v_addl_message_info(v_idx) := 'RULE_SET(' || v_idv_rule_set_id 
                  || ').CUST_ID=' || v_cust_id_rules;
          END IF;
      ELSE
          v_idx := v_idx+1;
          v_addl_message_info(v_idx) := 'ACCT_RNG_MDES_PARM(' || v_new_fpan_rng_strt_num 
              || ').IDV_RULE_SET_ID=' || in_new_idv_rule_set_id;
          SELECT CUST_ID INTO v_cust_id_rules FROM RULE_SET
           WHERE RULE_SET_ID = in_new_idv_rule_set_id;
              v_idx := v_idx+1;
              v_addl_message_info(v_idx) := 'RULE_SET(' || in_new_idv_rule_set_id 
                  || ').CUST_ID=' || v_cust_id_rules;
      END IF;

      FOR v_idx in 1 .. 5 LOOP 
          v_msg := v_addl_message_info(v_idx);
          IF v_msg IS NOT NULL THEN
              x := x+1;
              IF X = 1 THEN
                  v_msg_concatenated := v_msg;
              ELSE 
                  v_msg_concatenated := v_msg_concatenated || '|' || v_msg;
              END IF;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg); 
          END IF;
      END LOOP;
      
			--now that we have the CUST_IDs ... make sure they are the same!
      IF v_cust_id_prdct_config IS NOT NULL THEN
          IF v_cust_id_prdct_config != v_cust_id_new_acct_rng THEN
               out_rtn_msg := vc_proc_name || ': ' || v_msg_concatenated || '|'
                         || 'v_cust_id_new_acct_rng=' || v_cust_id_new_acct_rng || '|'
                         || 'v_cust_id_prdct_config=' || v_cust_id_prdct_config || '|'
                         || 'CUST_ID MISMATCH!';
               RAISE CUST_ID_MISMATCH;
          END IF;
      END IF;
      IF v_cust_id_rules IS NOT NULL THEN
          IF v_cust_id_rules != v_cust_id_new_acct_rng THEN
               out_rtn_msg := vc_proc_name || v_msg_concatenated || '|'  
                         || 'v_cust_id_new_acct_rng=' || v_cust_id_new_acct_rng || '|'
                         || 'v_cust_id_rules=' || v_cust_id_rules || '|'
                         || 'CUST_ID MISMATCH!';
               RAISE CUST_ID_MISMATCH;
          END IF;
      END IF;

      --------------------------------------------------------------------------
      -- clone FPAN_ACCT_RNG:
      --------------------------------------------------------------------------
      SELECT *
        INTO rec_fpan_acct_rng
        FROM FPAN_ACCT_RNG
       WHERE PARTN_NUM = v_active_partn_num 
         AND RNG_STRT_NUM = v_base_fpan_rng_strt_num;

      rec_fpan_acct_rng.PARTN_NUM := v_new_partn_num;
      rec_fpan_acct_rng.RNG_END_NUM := v_new_fpan_rng_end_num;
      rec_fpan_acct_rng.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
      rec_fpan_acct_rng.TWO_SRS_TOKEN_ENBL_SW := in_new_two_srs_token_enbl_sw; 
      rec_fpan_acct_rng.RPLCTN_UPDT_TS := SYSDATE;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': INSERT INTO FPAN_ACCT_RNG: '
          || rec_fpan_acct_rng.PARTN_NUM || ', ' 
          || rec_fpan_acct_rng.RNG_STRT_NUM || ', ' 
          || rec_fpan_acct_rng.RNG_END_NUM);
      INSERT INTO FPAN_ACCT_RNG
           VALUES rec_fpan_acct_rng;

      --------------------------------------------------------------------------
      -- clone ACCT_RNG_MDES_PARM:
      --------------------------------------------------------------------------
      SELECT *
        INTO rec_acct_rng_mdes_parm
        FROM ACCT_RNG_MDES_PARM
       WHERE partn_num = v_active_partn_num 
         AND rng_strt_num = v_base_fpan_rng_strt_num;
      IF in_new_card_len_num IS NOT NULL THEN
          rec_acct_rng_mdes_parm.CARD_LEN_NUM := in_new_card_len_num;
      END IF;
      IF in_new_cust_id IS NOT NULL THEN
          rec_acct_rng_mdes_parm.CUST_ID := in_new_cust_id;
      END IF;
      IF in_new_idv_rule_set_id IS NOT NULL THEN
          rec_acct_rng_mdes_parm.IDV_RULE_SET_ID := in_new_idv_rule_set_id;
      END IF;
      rec_acct_rng_mdes_parm.PARTN_NUM := v_new_partn_num;
      rec_acct_rng_mdes_parm.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
      rec_acct_rng_mdes_parm.BIN_NUM := SUBSTR(v_new_fpan_rng_strt_num,1,8); 
      rec_acct_rng_mdes_parm.RPLCTN_UPDT_TS := SYSDATE;
      rec_acct_rng_mdes_parm.EXTRL_TSP_SW := in_new_tsp_sw;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': INSERT INTO ACCT_RNG_MDES_PARM: '
          || rec_acct_rng_mdes_parm.PARTN_NUM || ', ' 
          || rec_acct_rng_mdes_parm.RNG_STRT_NUM);
      INSERT INTO ACCT_RNG_MDES_PARM
           VALUES rec_acct_rng_mdes_parm;

      --------------------------------------------------------------------------
      -- clone ACCT_RNG_WLT_PRVDR:
      --------------------------------------------------------------------------
      FOR rec_acct_rng_wlt_prvdr IN
          (SELECT *
             FROM ACCT_RNG_WLT_PRVDR
            WHERE partn_num = v_active_partn_num 
              AND rng_strt_num = v_base_fpan_rng_strt_num)
      LOOP
          rec_acct_rng_wlt_prvdr.PARTN_NUM := v_new_partn_num;
          rec_acct_rng_wlt_prvdr.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
          rec_acct_rng_wlt_prvdr.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
              || ': INSERT INTO ACCT_RNG_WLT_PRVDR: '
              || rec_acct_rng_wlt_prvdr.PARTN_NUM || ', ' 
              || rec_acct_rng_wlt_prvdr.RNG_STRT_NUM || ', '
              || rec_acct_rng_wlt_prvdr.WLT_PRVDR_ID);
          INSERT INTO ACCT_RNG_WLT_PRVDR
               VALUES rec_acct_rng_wlt_prvdr;
      END LOOP;
      
      --------------------------------------------------------------------------
      -- clone ACCT_RNG_WLT_PRVDR_CONFIG (not partitioned):
      --------------------------------------------------------------------------
      FOR rec_acct_rng_wlt_prvdr_config IN
          (SELECT *
             FROM ACCT_RNG_WLT_PRVDR_CONFIG
            WHERE RNG_STRT_NUM = v_base_fpan_rng_strt_num)
      LOOP
          -- this table is not partitioned so we need to make sure that the 
          -- data doesn't already exist (ie. when new account range was cloned  
          -- previously for a different partition):
          SELECT COUNT(*) INTO v_count FROM ACCT_RNG_WLT_PRVDR_CONFIG
            WHERE RNG_STRT_NUM = v_new_fpan_rng_strt_num
              AND WLT_PRVDR_ID = rec_acct_rng_wlt_prvdr_config.wlt_prvdr_id;
          IF v_count = 0 THEN
              rec_acct_rng_wlt_prvdr_config.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
              rec_acct_rng_wlt_prvdr_config.RPLCTN_UPDT_TS := SYSDATE;
              rec_acct_rng_wlt_prvdr_config.UPDT_DT := SYSDATE;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
                  || ': INSERT INTO ACCT_RNG_WLT_PRVDR_CONFIG: '
                  || rec_acct_rng_wlt_prvdr_config.RNG_STRT_NUM || ', ' 
                  || rec_acct_rng_wlt_prvdr_config.WLT_PRVDR_ID);
              INSERT INTO ACCT_RNG_WLT_PRVDR_CONFIG
                   VALUES rec_acct_rng_wlt_prvdr_config;
          END IF;
      END LOOP;
      
      --------------------------------------------------------------------------
      -- clone ACCT_RNG_ACCUM:
      --------------------------------------------------------------------------
      FOR rec_acct_rng_accum IN
          (SELECT *
             FROM ACCT_RNG_ACCUM
            WHERE partn_num = v_active_partn_num 
              AND rng_strt_num = v_base_fpan_rng_strt_num)
      LOOP
          rec_acct_rng_accum.PARTN_NUM := v_new_partn_num;
          rec_acct_rng_accum.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
          rec_acct_rng_accum.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
              || ': INSERT INTO ACCT_RNG_ACCUM: '
              || rec_acct_rng_accum.PARTN_NUM || ', ' 
              || rec_acct_rng_accum.RNG_STRT_NUM || ', '
              || rec_acct_rng_accum.ACCUM_NUM || ', '
              || rec_acct_rng_accum.TOKEN_TYPE_CD || ', '
              || rec_acct_rng_accum.NUM_CURR_CD);
          INSERT INTO ACCT_RNG_ACCUM
               VALUES rec_acct_rng_accum;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone ACCT_RNG_ACCUM_CURR_CONV:
      --------------------------------------------------------------------------
      FOR rec_acct_rng_accum_curr_conv IN
          (SELECT *
             FROM ACCT_RNG_ACCUM_CURR_CONV
            WHERE partn_num = v_active_partn_num 
              AND rng_strt_num = v_base_fpan_rng_strt_num)
      LOOP
          rec_acct_rng_accum_curr_conv.PARTN_NUM := v_new_partn_num;
          rec_acct_rng_accum_curr_conv.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
          rec_acct_rng_accum_curr_conv.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
              || ': INSERT INTO ACCT_RNG_ACCUM_CURR_CONV: '
              || rec_acct_rng_accum_curr_conv.PARTN_NUM || ', ' 
              || rec_acct_rng_accum_curr_conv.RNG_STRT_NUM || ', '
              || rec_acct_rng_accum_curr_conv.ACCUM_NUM || ', '
              || rec_acct_rng_accum_curr_conv.TOKEN_TYPE_CD || ', '
              || rec_acct_rng_accum_curr_conv.NUM_CURR_CD);
          INSERT INTO ACCT_RNG_ACCUM_CURR_CONV
               VALUES rec_acct_rng_accum_curr_conv;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone ACCT_RNG_LANG:
      --------------------------------------------------------------------------
      FOR rec_acct_rng_lang IN
          (SELECT *
             FROM ACCT_RNG_LANG
            WHERE partn_num = v_active_partn_num 
              AND rng_strt_num = v_base_fpan_rng_strt_num)
      LOOP
          rec_acct_rng_lang.PARTN_NUM := v_new_partn_num;
          rec_acct_rng_lang.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
          rec_acct_rng_lang.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
              || ': INSERT INTO ACCT_RNG_LANG: '
              || rec_acct_rng_lang.PARTN_NUM || ', ' 
              || rec_acct_rng_lang.RNG_STRT_NUM || ','
              || rec_acct_rng_lang.TOKEN_TYPE_CD || ', '
              || rec_acct_rng_lang.PREF_NUM);
          INSERT INTO ACCT_RNG_LANG
               VALUES rec_acct_rng_lang;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone ACCT_RNG_MDES_BRND_PRDCT:
      --------------------------------------------------------------------------
      FOR rec_acct_rng_brnd_prdct IN
          (SELECT *
             FROM ACCT_RNG_MDES_BRND_PRDCT
            WHERE partn_num = v_active_partn_num 
              AND rng_strt_num = v_base_fpan_rng_strt_num)
      LOOP
          IF in_new_config_uuid IS NOT NULL THEN
              rec_acct_rng_brnd_prdct.CONFIG_UUID := in_new_config_uuid;
          END IF;
          rec_acct_rng_brnd_prdct.PARTN_NUM := v_new_partn_num;
          rec_acct_rng_brnd_prdct.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
          rec_acct_rng_brnd_prdct.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
              || ': INSERT INTO ACCT_RNG_MDES_BRND_PRDCT: '
              || rec_acct_rng_brnd_prdct.PARTN_NUM || ', ' 
              || rec_acct_rng_brnd_prdct.RNG_STRT_NUM || ', '
              || rec_acct_rng_brnd_prdct.BRND_PRDCT_CD);
          INSERT INTO ACCT_RNG_MDES_BRND_PRDCT
               VALUES rec_acct_rng_brnd_prdct;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone AR_CRDHLDR_ACTV_CD_MTHD:
      --------------------------------------------------------------------------
      FOR rec_ar_crdhldr_actv_cd_mthd IN
          (SELECT *
             FROM AR_CRDHLDR_ACTV_CD_MTHD
            WHERE partn_num = v_active_partn_num 
              AND rng_strt_num = v_base_fpan_rng_strt_num)
      LOOP
          rec_ar_crdhldr_actv_cd_mthd.PARTN_NUM := v_new_partn_num;
          rec_ar_crdhldr_actv_cd_mthd.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
          rec_ar_crdhldr_actv_cd_mthd.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
              || ': INSERT INTO AR_CRDHLDR_ACTV_CD_MTHD: '
              || rec_ar_crdhldr_actv_cd_mthd.PARTN_NUM || ', ' 
              || rec_ar_crdhldr_actv_cd_mthd.RNG_STRT_NUM || ', ' 
              || rec_ar_crdhldr_actv_cd_mthd.ACTV_CD_MTHD_CD);
          INSERT INTO AR_CRDHLDR_ACTV_CD_MTHD
               VALUES rec_ar_crdhldr_actv_cd_mthd;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone ACCT_RNG_MBL_WLT_APPL:
      --------------------------------------------------------------------------
      FOR rec_acct_rng_mbl_wlt_appl IN
          (SELECT *
             FROM ACCT_RNG_MBL_WLT_APPL
            WHERE partn_num = v_active_partn_num 
              AND rng_strt_num = v_base_fpan_rng_strt_num)
      LOOP
          rec_acct_rng_mbl_wlt_appl.PARTN_NUM := v_new_partn_num;
          rec_acct_rng_mbl_wlt_appl.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
          rec_acct_rng_mbl_wlt_appl.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
              || ': INSERT INTO ACCT_RNG_MBL_WLT_APPL: '
              || rec_acct_rng_mbl_wlt_appl.PARTN_NUM || ', ' 
              || rec_acct_rng_mbl_wlt_appl.RNG_STRT_NUM || ', ' 
              || rec_acct_rng_mbl_wlt_appl.WLT_PRVDR_ID || ', ' 
              || rec_acct_rng_mbl_wlt_appl.MBL_WLT_ID);
          INSERT INTO ACCT_RNG_MBL_WLT_APPL
               VALUES rec_acct_rng_mbl_wlt_appl;
      END LOOP;
   
      --------------------------------------------------------------------------
      -- clone ACCT_RNG_MBL_WLT_APPL_CVM:
      --------------------------------------------------------------------------
      FOR rec_acct_rng_mbl_wlt_appl_cvm IN
          (SELECT *
             FROM ACCT_RNG_MBL_WLT_APPL_CVM
            WHERE partn_num = v_active_partn_num 
              AND rng_strt_num = v_base_fpan_rng_strt_num)
      LOOP
          rec_acct_rng_mbl_wlt_appl_cvm.PARTN_NUM := v_new_partn_num;
          rec_acct_rng_mbl_wlt_appl_cvm.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
          rec_acct_rng_mbl_wlt_appl_cvm.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
              || ': INSERT INTO ACCT_RNG_MBL_WLT_APPL_CVM: '
              || rec_acct_rng_mbl_wlt_appl_cvm.PARTN_NUM || ', ' 
              || rec_acct_rng_mbl_wlt_appl_cvm.RNG_STRT_NUM || ', ' 
              || rec_acct_rng_mbl_wlt_appl_cvm.WLT_PRVDR_ID || ', ' 
              || rec_acct_rng_mbl_wlt_appl_cvm.MBL_WLT_ID);
          INSERT INTO ACCT_RNG_MBL_WLT_APPL_CVM
               VALUES rec_acct_rng_mbl_wlt_appl_cvm;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone ACCT_RNG_TOKEN_TYPE:
      --------------------------------------------------------------------------
      FOR rec_acct_rng_token_type IN
          (SELECT *
             FROM ACCT_RNG_TOKEN_TYPE
            WHERE partn_num = v_active_partn_num 
              AND rng_strt_num = v_base_fpan_rng_strt_num)
      LOOP
          rec_acct_rng_token_type.PARTN_NUM := v_new_partn_num;
          rec_acct_rng_token_type.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
          rec_acct_rng_token_type.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name  
              || ': INSERT INTO ACCT_RNG_TOKEN_TYPE: '
              || rec_acct_rng_token_type.PARTN_NUM || ', ' 
              || rec_acct_rng_token_type.RNG_STRT_NUM || ', ' 
              || rec_acct_rng_token_type.TOKEN_TYPE_CD);
          INSERT INTO ACCT_RNG_TOKEN_TYPE
               VALUES rec_acct_rng_token_type;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone ACCT_RNG_MDES_BITMAP_PARM:
      --------------------------------------------------------------------------
      FOR rec_acct_mdes_bitmap_parm IN
          (SELECT *
             FROM ACCT_RNG_MDES_BITMAP_PARM
            WHERE partn_num = v_active_partn_num 
              AND rng_strt_num = v_base_fpan_rng_strt_num)
      LOOP
          rec_acct_mdes_bitmap_parm.PARTN_NUM := v_new_partn_num;
          rec_acct_mdes_bitmap_parm.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
          rec_acct_mdes_bitmap_parm.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
              || ': INSERT INTO ACCT_RNG_MDES_BITMAP_PARM: '
              || rec_acct_mdes_bitmap_parm.PARTN_NUM || ', ' 
              || rec_acct_mdes_bitmap_parm.RNG_STRT_NUM || ', ' 
              || rec_acct_mdes_bitmap_parm.TOKEN_TYPE_CD || ', ' 
              || rec_acct_mdes_bitmap_parm.PARM_TYPE_NAM || ', ' 
              || rec_acct_mdes_bitmap_parm.PARM_BYTE_NUM || ', ' 
              || rec_acct_mdes_bitmap_parm.PARM_BIT_NUM);
          INSERT INTO ACCT_RNG_MDES_BITMAP_PARM
               VALUES rec_acct_mdes_bitmap_parm;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone ACCT_RNG_TOKEN_TYPE_PEM:
      --------------------------------------------------------------------------
      FOR rec_acct_token_type_pem IN
          (SELECT *
             FROM ACCT_RNG_TOKEN_TYPE_PEM
            WHERE partn_num = v_active_partn_num 
              AND rng_strt_num = v_base_fpan_rng_strt_num)
      LOOP
          rec_acct_token_type_pem.PARTN_NUM := v_new_partn_num;
          rec_acct_token_type_pem.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
          rec_acct_token_type_pem.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
              || ': INSERT INTO ACCT_RNG_TOKEN_TYPE_PEM: '
              || rec_acct_token_type_pem.PARTN_NUM || ', ' 
              || rec_acct_token_type_pem.RNG_STRT_NUM || ', ' 
              || rec_acct_token_type_pem.TOKEN_TYPE_CD || ', ' 
              || rec_acct_token_type_pem.POS_ENT_MODE_CD || ', ' 
              || rec_acct_token_type_pem.EXPIR_DT_TXT);
          INSERT INTO ACCT_RNG_TOKEN_TYPE_PEM
               VALUES rec_acct_token_type_pem;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone ACCT_RNG_NTWRK_MSG:
      --------------------------------------------------------------------------
      FOR rec_acct_rng_ntwrk_msg IN
          (SELECT *
             FROM ACCT_RNG_NTWRK_MSG
            WHERE partn_num = v_active_partn_num 
              AND rng_strt_num = v_base_fpan_rng_strt_num)
      LOOP
          rec_acct_rng_ntwrk_msg.PARTN_NUM := v_new_partn_num;
          rec_acct_rng_ntwrk_msg.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
          rec_acct_rng_ntwrk_msg.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
              || ': INSERT INTO ACCT_RNG_NTWRK_MSG: '
              || rec_acct_rng_ntwrk_msg.PARTN_NUM || ', ' 
              || rec_acct_rng_ntwrk_msg.RNG_STRT_NUM || ', ' 
              || rec_acct_rng_ntwrk_msg.NTWRK_MSG_ID || ', ' 
              || rec_acct_rng_ntwrk_msg.TOKEN_SERV_CD);
          INSERT INTO ACCT_RNG_NTWRK_MSG
               VALUES rec_acct_rng_ntwrk_msg;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone ISSR_TDS_CONFIG (not partitioned):
      --------------------------------------------------------------------------
      FOR rec_issr_tds_config IN
          (SELECT *
             FROM ISSR_TDS_CONFIG
            WHERE RNG_STRT_NUM = v_base_fpan_rng_strt_num)
      LOOP
          -- this table is not partitioned so we need to make sure that the 
          -- data doesn't already exist (ie. when new account range was cloned  
          -- previously for a different partition):
          SELECT COUNT(*) INTO v_count FROM ISSR_TDS_CONFIG
            WHERE RNG_STRT_NUM = v_new_fpan_rng_strt_num
              AND MBL_WLT_ID = rec_issr_tds_config.mbl_wlt_id;
          IF v_count = 0 THEN
              rec_issr_tds_config.RNG_STRT_NUM := v_new_fpan_rng_strt_num;
              rec_issr_tds_config.RPLCTN_UPDT_TS := SYSDATE;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
                  || ': INSERT INTO ISSR_TDS_CONFIG: '
                  || rec_issr_tds_config.RNG_STRT_NUM || ', ' 
                  || rec_issr_tds_config.WLT_PRVDR_ID || ', '
                  || rec_issr_tds_config.MBL_WLT_ID);
              INSERT INTO ISSR_TDS_CONFIG
                   VALUES rec_issr_tds_config;
          END IF;
      END LOOP;

           
      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || v_new_fpan_rng_strt_num || 
                           ' successfully added!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;
      WHEN NOT_FOUND THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;
      WHEN PARM_VALUE_MISMATCH THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1003;
          ROLLBACK;
      WHEN CUST_ID_MISMATCH THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1004;
          ROLLBACK;
      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || v_new_fpan_rng_strt_num ||
            ' not added, Oracle error = ' || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_ACCT_RNG_ADD_FPAN;
   PROCEDURE PRC_ACCT_RNG_DELETE (
                     in_rng_strt_num                 IN  NUMBER, --required
                     in_partn_num                    IN  NUMBER, --optional
                     out_rtn_cd                      OUT NUMBER,
                     out_rtn_msg                     OUT VARCHAR2)

   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_ACCT_RNG_DELETE';
      v_partn_num                     ACTV_PARTN.PARTN_NUM%TYPE;
      v_rng_strt_num                  FPAN_ACCT_RNG.RNG_STRT_NUM%TYPE;
      v_where_clause                  VARCHAR2(100);
      v_count                         NUMBER;
      rec_fpan_acct_rng               FPAN_ACCT_RNG%ROWTYPE;
      rows_deleted                    NUMBER := 0;
      REQUIRED_PARM_NULL              EXCEPTION;


   PROCEDURE LPRC_ACCT_RNG_DELETE IS
   BEGIN
      --------------------------------------------------------------------------
      -- delete partioned FPAN_ACCT_RNG children first:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_ACCUM_CURR_CONV ...');
      DELETE FROM ACCT_RNG_ACCUM_CURR_CONV
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_ACCUM_CURR_CONV rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_TOKEN_TYPE_PEM ...');
      DELETE FROM ACCT_RNG_TOKEN_TYPE_PEM
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_TOKEN_TYPE_PEM rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_ACCUM ...');
      DELETE FROM ACCT_RNG_ACCUM
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_ACCUM rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_LANG ...');
      DELETE FROM ACCT_RNG_LANG
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_LANG rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_MBL_WLT_APPL ...');
      DELETE FROM ACCT_RNG_MBL_WLT_APPL
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_MBL_WLT_APPL rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_MBL_WLT_APPL_CVM ...');
      DELETE FROM ACCT_RNG_MBL_WLT_APPL_CVM
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_MBL_WLT_APPL_CVM rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;
      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_MDES_BITMAP_PARM ...');
      DELETE FROM ACCT_RNG_MDES_BITMAP_PARM
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_MDES_BITMAP_PARM rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_MDES_BRND_PRDCT ...');
      DELETE FROM ACCT_RNG_MDES_BRND_PRDCT
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_MDES_BRND_PRDCT rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_NTWRK_MSG ...');
      DELETE FROM ACCT_RNG_NTWRK_MSG
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_NTWRK_MSG rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_WLT_PRVDR ...');
      DELETE FROM ACCT_RNG_WLT_PRVDR
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_WLT_PRVDR rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_TOKEN_TYPE ...');
      DELETE FROM ACCT_RNG_TOKEN_TYPE
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_TOKEN_TYPE rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM AR_CRDHLDR_ACTV_CD_MTHD ...');
      DELETE FROM AR_CRDHLDR_ACTV_CD_MTHD
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': AR_CRDHLDR_ACTV_CD_MTHD rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_MDES_PARM ...');
      DELETE FROM ACCT_RNG_MDES_PARM
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_MDES_PARM rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM DPAN_ACCT_RNG ...');
      DELETE FROM DPAN_ACCT_RNG
       WHERE FPAN_RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': DPAN_ACCT_RNG rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;
      
      --------------------------------------------------------------------------
      -- now delete partioned FPAN_ACCT_RNG:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM FPAN_ACCT_RNG ...');
      DELETE FROM FPAN_ACCT_RNG
       WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);     
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': FPAN_ACCT_RNG rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;
      
      --------------------------------------------------------------------------
      -- and finally delete non-partioned FPAN_ACCT_RNG children only if no more 
      -- partioned FPAN_ACCT_RNG rows exist:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': CHECKING NON-PARTIONED TABLES ...');
      SELECT COUNT(*) INTO v_count
        FROM FPAN_ACCT_RNG
       WHERE RNG_STRT_NUM = v_rng_strt_num;
      IF v_count = 0 THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ACCT_RNG_WLT_PRVDR_CONFIG ...');
          DELETE FROM ACCT_RNG_WLT_PRVDR_CONFIG
           WHERE RNG_STRT_NUM = v_rng_strt_num;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_WLT_PRVDR_CONFIG rows deleted: ' || SQL%ROWCOUNT);
          rows_deleted := SQL%ROWCOUNT + rows_deleted;

          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM ISSR_TDS_CONFIG ...');
          DELETE FROM ISSR_TDS_CONFIG
           WHERE RNG_STRT_NUM = v_rng_strt_num;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ISSR_TDS_CONFIG rows deleted: ' || SQL%ROWCOUNT);
          rows_deleted := SQL%ROWCOUNT + rows_deleted;

      ELSE
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_WLT_PRVDR_CONFIG rows deleted: 0 '
              || '(partioned FPAN_ACCT_RNG entries for '
              || v_rng_strt_num || ' still exist)');

          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ISSR_TDS_CONFIG rows deleted: 0 '
              || '(partioned FPAN_ACCT_RNG entries for '
              || v_rng_strt_num || ' still exist)');
      END IF;
   END; 
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ...');
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_rng_strt_num IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- reformat range into 19 digit value:
      --------------------------------------------------------------------------
      v_rng_strt_num     := RPAD (in_rng_strt_num, 19, '0');
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_rng_strt_num: '|| v_rng_strt_num);

      --------------------------------------------------------------------------
      -- now delete the account range:
      --------------------------------------------------------------------------
      SELECT COUNT(*) INTO v_count
        FROM FPAN_ACCT_RNG
        WHERE RNG_STRT_NUM = v_rng_strt_num
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM); 
      IF v_count > 0 THEN
          LPRC_ACCT_RNG_DELETE;
      END IF;
 
      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': TOTAL ROWS deleted: '|| rows_deleted);
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || v_rng_strt_num 
                     || in_partn_num || ' successfully deleted!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;
      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || v_rng_strt_num
                        || in_partn_num || ' failed, Oracle error = '
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_ACCT_RNG_DELETE;
   PROCEDURE PRC_ACCT_RNG_SET_NTWRK_MSG (
                      in_fpan_rng_strt_num           IN  NUMBER,   --required
                      in_ntwrk_msg_ids               IN  VARCHAR2, --required
                      in_token_serv_cd               IN  VARCHAR2, --required
                      in_partn_num                   IN  NUMBER,   --optional
                      out_rtn_cd                     OUT NUMBER,
                      out_rtn_msg                    OUT VARCHAR2)

   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_ACCT_RNG_SET_NTWRK_MSG';
      v_active_partn_num              ACTV_PARTN.PARTN_NUM%TYPE;
      v_partn_num                     ACTV_PARTN.PARTN_NUM%TYPE;
      v_fpan_rng_strt_num             FPAN_ACCT_RNG.RNG_STRT_NUM%TYPE;
      v_ntwrk_msg_id_list             VARCHAR(100);
      v_ntwrk_msg_id                  VARCHAR(3);
      v_count                         NUMBER;
      INVALID_TOKEN_SERV_CD           EXCEPTION;
      REQUIRED_PARM_NULL              EXCEPTION;      
      NOT_FOUND                       EXCEPTION;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_active_partn_num: '|| v_active_partn_num);
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- get active partition:
      --------------------------------------------------------------------------
      SELECT partn_num INTO v_active_partn_num FROM ACTV_PARTN;
      IF in_partn_num IS NULL THEN
          v_partn_num := v_active_partn_num;
      ELSE
          v_partn_num := in_partn_num;
      END IF;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_active_partn_num: '|| v_active_partn_num);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_partn_num: '|| v_partn_num);

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
       IF in_fpan_rng_strt_num IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_fpan_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_ntwrk_msg_ids IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_ntwrk_msg_ids cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_token_serv_cd IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_token_serv_cd cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- reformat range into 19 digit value:
      --------------------------------------------------------------------------
      v_fpan_rng_strt_num := RPAD (in_fpan_rng_strt_num, 19, '0');
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_fpan_rng_strt_num: '|| v_fpan_rng_strt_num);

      --------------------------------------------------------------------------
      -- edit token_serv_cd:
      --------------------------------------------------------------------------
      IF in_token_serv_cd <> '098' AND in_token_serv_cd <> '100' THEN
          out_rtn_msg := vc_proc_name || ': invalid in_token_serv_cd: '|| in_token_serv_cd;
          RAISE INVALID_TOKEN_SERV_CD;
      END IF;

      --------------------------------------------------------------------------
      -- make sure fpan range already exists:
      --------------------------------------------------------------------------
      SELECT COUNT(*) INTO v_count FROM FPAN_ACCT_RNG 
       WHERE PARTN_NUM = v_partn_num 
         AND RNG_STRT_NUM = v_fpan_rng_strt_num;
      IF v_count = 0 THEN
          out_rtn_msg := vc_proc_name || ': v_partn_num=' || v_partn_num || ', v_fpan_rng_strt_num=' 
                         || v_fpan_rng_strt_num || ' not found in FPAN_ACCT_RNG!';
          RAISE NOT_FOUND;
      END IF;      

      ------------ --------------------------------------------------------------
      -- first delete any existing ACCT_RNG_NTWKR_MSG rows:
      --------------------------------------------------------------------------
      DELETE FROM ACCT_RNG_NTWRK_MSG
      WHERE RNG_STRT_NUM = v_fpan_rng_strt_num
        AND PARTN_NUM = v_partn_num
        AND TOKEN_SERV_CD = in_token_serv_cd;

      --------------------------------------------------------------------------
      -- now re-insert ACCT_RNG_NTWKR_MSG rows:
      --------------------------------------------------------------------------
      v_ntwrk_msg_id_list := in_ntwrk_msg_ids;
      IF v_ntwrk_msg_id_list <> 'NONE' THEN
          FOR i IN 1 .. LENGTH(v_ntwrk_msg_id_list) - 
                    LENGTH(REPLACE(v_ntwrk_msg_id_list, ',','')) + 1 
          LOOP
              v_ntwrk_msg_id := REGEXP_SUBSTR(v_ntwrk_msg_id_list, '[^,]+', 1, i);
              PKG_UTILITIES.PRC_OUTPUT_DEBUG('PROCESSING NTWRK_MSG_ID: ' || v_ntwrk_msg_id);
              INSERT INTO ACCT_RNG_NTWRK_MSG
                  (NTWRK_MSG_ID, PARTN_NUM, RNG_STRT_NUM, RPLCTN_UPDT_TS, 
                   TOKEN_SERV_CD)
              VALUES (v_ntwrk_msg_id, v_partn_num, v_fpan_rng_strt_num, SYSDATE,
                     in_token_serv_cd);
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_partn_num || ',' 
                  || v_fpan_rng_strt_num || ',' 
                  || in_token_serv_cd || ',' 
                  || v_ntwrk_msg_id || ' added!'); 
          END LOOP;
      END IF;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': completed successfully!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
   
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN NOT_FOUND THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;
 
      WHEN INVALID_TOKEN_SERV_CD THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1004;
          ROLLBACK;
          
      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || v_partn_num || ',' ||
                        v_fpan_rng_strt_num || ',' || in_token_serv_cd ||
                        ' FAILED, ORACLE ERROR = ' || 
                        SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_ACCT_RNG_SET_NTWRK_MSG;
   PROCEDURE PRC_CLNT_ADD (
                     in_base_clnt_id                   IN  VARCHAR, --required
                     in_new_clnt_id                    IN  VARCHAR, --required
                     in_clone_cust_data_sw             IN  VARCHAR, --required
                     in_merchant_type_sw               IN  VARCHAR, --required
                     out_rtn_cd                        OUT NUMBER,
                     out_rtn_msg                       OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_CLNT_ADD';
      v_count                         NUMBER;
      rec_clnt                        CLNT%ROWTYPE;
      rec_clnt_appl                   CLNT_APPL%ROWTYPE;
      rec_clnt_crtfct                 CLNT_CRTFCT%ROWTYPE;
      rec_clnt_parm                   CLNT_PARM%ROWTYPE;
      rec_clnt_prvt_key               CLNT_PRVT_KEY%ROWTYPE;
      rec_cust_clnt                   CUST_CLNT%ROWTYPE;
      rec_cust_clnt_bin               CUST_CLNT_BIN%ROWTYPE;
      rec_prtnr_host                  PRTNR_HOST%ROWTYPE;
      rec_prtnr_ftr                   PRTNR_FTR%ROWTYPE;
      REQUIRED_PARM_NULL              EXCEPTION;
      NOT_FOUND                       EXCEPTION;
   
   PROCEDURE LPRC_CLNT_CUST_ADD IS
   BEGIN
      --------------------------------------------------------------------------
      -- clone CUST_CLNT:
      --------------------------------------------------------------------------
      FOR rec_cust_clnt IN
          (SELECT *
             FROM CUST_CLNT
            WHERE CLNT_ID = in_base_clnt_id)
      LOOP
          rec_cust_clnt.CLNT_ID := in_new_clnt_id;
          rec_cust_clnt.RPLCTN_UPDT_TS := SYSDATE;
          rec_cust_clnt.UPDT_DT := SYSDATE;
          rec_cust_clnt.UPDT_USER_ID := USER;
          INSERT INTO CUST_CLNT
               VALUES rec_cust_clnt;
      END LOOP;
      
      --------------------------------------------------------------------------
      -- clone CUST_CLNT_BIN:
      --------------------------------------------------------------------------
      FOR rec_cust_clnt_bin IN
          (SELECT *
             FROM CUST_CLNT_BIN
            WHERE CLNT_ID = in_base_clnt_id)
      LOOP
          rec_cust_clnt_bin.CLNT_ID := in_new_clnt_id;
          rec_cust_clnt_bin.RPLCTN_UPDT_TS := SYSDATE;
          rec_cust_clnt_bin.UPDT_DT := SYSDATE;
          rec_cust_clnt_bin.UPDT_USER_ID := USER;
          INSERT INTO CUST_CLNT_BIN
               VALUES rec_cust_clnt_bin;
      END LOOP;
   END LPRC_CLNT_CUST_ADD;
      
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_clnt_id IS NULL THEN
          out_rtn_msg := 'in_base_clnt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_clnt_id IS NULL THEN
          out_rtn_msg := 'in_new_clnt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_clone_cust_data_sw IS NULL THEN
          out_rtn_msg := 'in_clone_cust_data_sw cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_merchant_type_sw IS NULL THEN
          out_rtn_msg := 'in_merchant_type_sw cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- clone CLNT:
      --------------------------------------------------------------------------
      FOR rec_clnt IN
          (SELECT *
             FROM CLNT
            WHERE CLNT_ID = in_base_clnt_id)
      LOOP
          rec_clnt.CLNT_ID := in_new_clnt_id;
          rec_clnt.CLNT_NAM := rec_clnt.CLNT_NAM || ' CLONE';
          rec_clnt.RPLCTN_UPDT_TS := SYSDATE;
          INSERT INTO CLNT
               VALUES rec_clnt;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone CLNT_APPL:
      --------------------------------------------------------------------------
      FOR rec_clnt_appl IN
          (SELECT *
             FROM CLNT_APPL
            WHERE CLNT_ID = in_base_clnt_id)
      LOOP
          rec_clnt_appl.CLNT_ID := in_new_clnt_id;
          rec_clnt_appl.RPLCTN_UPDT_TS := SYSDATE;
          INSERT INTO CLNT_APPL
               VALUES rec_clnt_appl;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone CLNT_CRTFCT:
      --------------------------------------------------------------------------
      FOR rec_clnt_crtfct IN
          (SELECT *
             FROM CLNT_CRTFCT
            WHERE CLNT_ID = in_base_clnt_id)
      LOOP
          rec_clnt_crtfct.CLNT_ID := in_new_clnt_id;
          rec_clnt_crtfct.CRTE_TS := SYSDATE;
          rec_clnt_crtfct.EXPIR_DT := TRUNC(SYSDATE) + 60;
          rec_clnt_crtfct.RPLCTN_UPDT_TS := SYSDATE;
          rec_clnt_crtfct.UPDT_TS := SYSDATE;
          INSERT INTO CLNT_CRTFCT
               VALUES rec_clnt_crtfct;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone CLNT_PARM:
      --------------------------------------------------------------------------
      FOR rec_clnt_parm IN
          (SELECT *
             FROM CLNT_PARM
            WHERE CLNT_ID = in_base_clnt_id)
      LOOP
          rec_clnt_parm.CLNT_ID := in_new_clnt_id;
          rec_clnt_parm.RPLCTN_UPDT_TS := SYSDATE;
          INSERT INTO CLNT_PARM
               VALUES rec_clnt_parm;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone CLNT_PRVT_KEY:
      --------------------------------------------------------------------------
      FOR rec_clnt_prvt_key IN
          (SELECT *
             FROM CLNT_PRVT_KEY
            WHERE CLNT_ID = in_base_clnt_id)
      LOOP
          rec_clnt_prvt_key.CLNT_ID := in_new_clnt_id;
          rec_clnt_prvt_key.CRTE_TS := SYSDATE;
          rec_clnt_prvt_key.EXPIR_DT := TRUNC(SYSDATE) + 60;
          rec_clnt_prvt_key.RPLCTN_UPDT_TS := SYSDATE;
          rec_clnt_prvt_key.UPDT_TS := SYSDATE;
          INSERT INTO CLNT_PRVT_KEY
               VALUES rec_clnt_prvt_key;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone PRTNR_HOST:
      --------------------------------------------------------------------------
      IF in_merchant_type_sw = 'Y' THEN
          FOR rec_prtnr_host IN
              (SELECT *
                 FROM PRTNR_HOST
                WHERE PRTNR_ID = in_base_clnt_id)
          LOOP
              rec_prtnr_host.PRTNR_ID := in_new_clnt_id;
              rec_prtnr_host.RPLCTN_UPDT_TS := SYSDATE;
              INSERT INTO PRTNR_HOST
                   VALUES rec_prtnr_host;
          END LOOP;
      END IF;

      --------------------------------------------------------------------------
      -- clone PRTNR_FTR:
      --------------------------------------------------------------------------
      FOR rec_prtnr_ftr IN
          (SELECT *
             FROM PRTNR_FTR
            WHERE PRTNR_ID = in_base_clnt_id)
      LOOP
          rec_prtnr_ftr.PRTNR_ID := in_new_clnt_id;
          rec_prtnr_ftr.RPLCTN_UPDT_TS := SYSDATE;
          INSERT INTO PRTNR_FTR
               VALUES rec_prtnr_ftr;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone CUST_CLNT and CUST_CLNT_BIN ... if requested:
      --------------------------------------------------------------------------
      IF in_clone_cust_data_sw = 'Y' THEN
          LPRC_CLNT_CUST_ADD;
      END IF;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_new_clnt_id || 
                           ' successfully added!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN NOT_FOUND THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;

      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_clnt_id ||
            ' not added, Oracle error = ' || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_CLNT_ADD;
   PROCEDURE PRC_CLNT_DELETE (
                        in_clnt_id                        IN  VARCHAR,  --required
                        out_rtn_cd                        OUT NUMBER,
                        out_rtn_msg                       OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2(50) := 'PRC_CLNT_DELETE';
      rows_deleted                    NUMBER := 0;
      REQUIRED_PARM_NULL              EXCEPTION;

   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
       IF in_clnt_id IS NULL THEN
          out_rtn_msg := 'in_clnt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- delete CLNT children first:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM CUST_CLNT_BIN ...');
      DELETE FROM CUST_CLNT_BIN
       WHERE CLNT_ID = in_clnt_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CUST_CLNT_BIN rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM CUST_CLNT ...');
      DELETE FROM CUST_CLNT
       WHERE CLNT_ID = in_clnt_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CUST_CLNT rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM CLNT_APPL ...');
      DELETE FROM CLNT_APPL
       WHERE CLNT_ID = in_clnt_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CLNT_APPL rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM CLNT_CRTFCT ...');
      DELETE FROM CLNT_CRTFCT
       WHERE CLNT_ID = in_clnt_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CLNT_CRTFCT rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM CLNT_PARM ...');
      DELETE FROM CLNT_PARM
       WHERE CLNT_ID = in_clnt_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CLNT_PARM rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM CLNT_PRVT_KEY ...');
      DELETE FROM CLNT_PRVT_KEY
       WHERE CLNT_ID = in_clnt_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CLNT_PRVT_KEY rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      --------------------------------------------------------------------------
      -- now delete CLNT:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM CLNT ...');
      DELETE FROM CLNT
       WHERE CLNT_ID = in_clnt_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CLNT rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      --------------------------------------------------------------------------
      -- not technically children but ...
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM PRTNR_HOST ...');
      DELETE FROM PRTNR_HOST
       WHERE PRTNR_ID = in_clnt_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('PRTNR_HOST rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM PRTNR_FTR ...');
      DELETE FROM PRTNR_FTR
       WHERE PRTNR_ID = in_clnt_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('PRTNR_FTR rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;


      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOTAL ROWS deleted: '|| rows_deleted);
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_clnt_id 
                     || ' successfully deleted!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_clnt_id
                        || ' not deleted, Oracle error = ' 
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_CLNT_DELETE;
   PROCEDURE PRC_CLNT_CLONE (
                     in_base_clnt_id                   IN  VARCHAR, --required
                     in_new_clnt_id                    IN  VARCHAR, --required
                     in_clone_cust_data_sw             IN  VARCHAR, --required
                     in_merchant_type_sw               IN  VARCHAR, --required
                     out_rtn_cd                        OUT NUMBER,
                     out_rtn_msg                       OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_CLNT_CLONE';
      REQUIRED_PARM_NULL              EXCEPTION;
      BAD_RETURN                      EXCEPTION;

   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ...');
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_clnt_id IS NULL THEN
          out_rtn_msg := 'in_base_clnt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_clnt_id IS NULL THEN
          out_rtn_msg := 'in_new_clnt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_clone_cust_data_sw IS NULL THEN
          out_rtn_msg := 'in_clone_cust_data_sw cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_merchant_type_sw IS NULL THEN
          out_rtn_msg := 'in_merchant_type_sw cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      
      --------------------------------------------------------------------------
      -- clone client by calling other procedures:
      --------------------------------------------------------------------------
      PRC_CLNT_DELETE(in_new_clnt_id,
                      out_rtn_cd,
                      out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;

      PRC_CLNT_ADD(in_base_clnt_id,
                   in_new_clnt_id,
                   in_clone_cust_data_sw,
                   in_merchant_type_sw,
                   out_rtn_cd,
                   out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_new_clnt_id 
                     || ' successfully cloned!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;
      WHEN BAD_RETURN THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1003;
          ROLLBACK;
      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1000;
         out_rtn_msg := vc_proc_name || ': ' || in_new_clnt_id
                        || ' not cloned, Oracle error = '
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

    END PRC_CLNT_CLONE;
   PROCEDURE PRC_CUST_ADD (
                        in_base_cust_id                   IN  NUMBER,   --required
                        in_new_cust_id                    IN  NUMBER,   --required
                        in_new_prefix                     IN  VARCHAR2, --required
                        in_clone_clnt_data_sw             IN  VARCHAR,  --required
                        out_rtn_cd                        OUT NUMBER,
                        out_rtn_msg                       OUT VARCHAR2)
    IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_CUST_ADD';
      v_count                         NUMBER;
      rec_cust                        CUST%ROWTYPE;
      rec_cust_parm                   CUST_PARM%ROWTYPE;
      rec_prdct_config                PRDCT_CONFIG%ROWTYPE;
      rec_cust_clnt                   CUST_CLNT%ROWTYPE;
      rec_wlt_prvdr_cust_map          WLT_PRVDR_CUST_MAP%ROWTYPE;
      v_cloned_uuid                   PRDCT_CONFIG.CONFIG_UUID%TYPE;
      v_max_len_config_uuid           NUMBER := 36;
      
      REQUIRED_PARM_NULL              EXCEPTION;
      NOT_FOUND                       EXCEPTION;
      BAD_RETURN                      EXCEPTION;
       
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ...');
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_cust_id IS NULL THEN
          out_rtn_msg := 'in_base_cust_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_cust_id IS NULL THEN
          out_rtn_msg := 'in_new_cust_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_prefix IS NULL THEN
          out_rtn_msg := 'in_new_prefix cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_clone_clnt_data_sw IS NULL THEN
          out_rtn_msg := 'in_clone_clnt_data_sw cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- make sure customer to be cloned exists:
      --------------------------------------------------------------------------
      SELECT COUNT(*) INTO v_count FROM CUST 
       WHERE CUST_ID = in_base_cust_id; 
      IF v_count = 0 THEN
          out_rtn_msg := 'in_base_cust_id=' || in_base_cust_id 
                          || ' not found in CUST!';
          RAISE NOT_FOUND;
      END IF;      

      --------------------------------------------------------------------------
      -- clone CUST:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': CLONING CUST');
      SELECT *
        INTO rec_cust
        FROM CUST
       WHERE CUST_ID = in_base_cust_id;

      rec_cust.CUST_ID := in_new_cust_id;
      rec_cust.RPLCTN_UPDT_TS := SYSDATE;

      INSERT INTO CUST
           VALUES rec_cust;

      --------------------------------------------------------------------------
      -- clone CUST_PARM:
      --------------------------------------------------------------------------
      FOR rec_cust_parm IN
          (SELECT *
             FROM CUST_PARM
            WHERE CUST_ID = in_base_cust_id)
      LOOP
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': CLONING CUST_PARM FOR CUST_PARM_NAM='
              ||rec_cust_parm.CUST_PARM_NAM);
          rec_cust_parm.CUST_ID := in_new_cust_id;
          rec_cust_parm.RPLCTN_UPDT_TS := SYSDATE;
          rec_cust_parm.UPDT_DT := SYSDATE;
          rec_cust_parm.UPDT_USER_ID := vc_proc_name;
          INSERT INTO CUST_PARM
               VALUES rec_cust_parm;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone customer's PRDCT_CONFIG data:
      --------------------------------------------------------------------------
       FOR rec_prdct_config IN (SELECT * FROM PRDCT_CONFIG 
                                 WHERE CUST_ID = in_base_cust_id
                                 ORDER BY CONFIG_UUID)
       LOOP
           v_cloned_uuid := GENERATE_CLONED_ID(rec_prdct_config.CONFIG_UUID, 
                                               in_new_prefix, 
                                               v_max_len_config_uuid);
           PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': CLONING PRDCT_CONFIG FOR CONFIG_UUID='
              ||rec_prdct_config.CONFIG_UUID);
           PRC_PRDCT_CONFIG_CLONE(rec_prdct_config.CONFIG_UUID,
                                  v_cloned_uuid,
                                  in_new_cust_id,
                                  NULL,
                                  out_rtn_cd,
                                  out_rtn_msg);
          IF out_rtn_cd <> 0 THEN
              RAISE BAD_RETURN;
          END IF;                       
      END LOOP;

      --------------------------------------------------------------------------
      -- clone WLT_PRVDR_CUST_MAP:
      --------------------------------------------------------------------------
       FOR rec_wlt_prvdr_cust_map IN (SELECT * FROM WLT_PRVDR_CUST_MAP 
                                      WHERE CUST_ID = in_base_cust_id)
       LOOP
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': CLONING PRDCT_CONFIG FOR WLT_PRVDR_ID='
              ||rec_wlt_prvdr_cust_map.WLT_PRVDR_ID);
          rec_wlt_prvdr_cust_map.CUST_ID := in_new_cust_id;
          rec_wlt_prvdr_cust_map.RPLCTN_UPDT_TS := SYSDATE;
          INSERT INTO WLT_PRVDR_CUST_MAP
               VALUES rec_wlt_prvdr_cust_map;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone customer's RULES data -> NO SUPPORT AT THIS TIME!!
      --------------------------------------------------------------------------

      --------------------------------------------------------------------------
      -- clone CUST_CLNT (if requested):
      --------------------------------------------------------------------------
       IF in_clone_clnt_data_sw = 'Y' THEN
           FOR rec_cust_clnt IN (SELECT * FROM CUST_CLNT
                                      WHERE CUST_ID = in_base_cust_id)
           LOOP
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': CLONING CUST_CLN FOR CLNT='
                  ||rec_cust_clnt.CLNT_ID);
              rec_cust_clnt.CUST_ID := in_new_cust_id;
              rec_cust_clnt.RPLCTN_UPDT_TS := SYSDATE;
              rec_cust_clnt.UPDT_DT := SYSDATE;
              rec_cust_clnt.UPDT_USER_ID := USER;
              INSERT INTO CUST_CLNT  VALUES rec_cust_clnt;
          END LOOP;
      END IF;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': COMPLETED!');
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_new_cust_id || 
                           ' successfully added!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN NOT_FOUND THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;
          
      WHEN BAD_RETURN THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1003;
          ROLLBACK;

      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_cust_id ||
            ' not added, Oracle error = ' || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_CUST_ADD;
   PROCEDURE PRC_CUST_CLONE (
                        in_base_cust_id                   IN  NUMBER,   --required
                        in_new_cust_id                    IN  NUMBER,   --required
                        in_new_prefix                     IN  VARCHAR2, --required
                        in_clone_clnt_data_sw             IN  VARCHAR,  --required
                        out_rtn_cd                        OUT NUMBER,
                        out_rtn_msg                       OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_CUST_CLONE';
      REQUIRED_PARM_NULL              EXCEPTION;
      BAD_RETURN                      EXCEPTION;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_cust_id IS NULL THEN
          out_rtn_msg := 'in_base_cust_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_cust_id IS NULL THEN
          out_rtn_msg := 'in_new_cust_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_prefix IS NULL THEN
          out_rtn_msg := 'in_new_prefix cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_clone_clnt_data_sw IS NULL THEN
          out_rtn_msg := 'in_clone_clnt_data_sw cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      
      --------------------------------------------------------------------------
      -- clone cust by calling other procedures:
      --------------------------------------------------------------------------
      PRC_CUST_DELETE(in_new_cust_id,
                      out_rtn_cd,
                      out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF; 

      PRC_CUST_ADD(in_base_cust_id, 
                   in_new_cust_id, 
                   in_new_prefix,
                   in_clone_clnt_data_sw,
                   out_rtn_cd,
                   out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF; 

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_new_cust_id || 
                           ' successfully added!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN BAD_RETURN THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1003;
          ROLLBACK;

      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_cust_id ||
            ' not added, Oracle error = ' || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_CUST_CLONE;
   PROCEDURE PRC_CUST_DELETE (
                        in_cust_id                        IN  VARCHAR2,      --required
                        out_rtn_cd                        OUT NUMBER,
                        out_rtn_msg                       OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2(50) := 'PRC_CUST_DELETE';
      rows_deleted                    NUMBER := 0;
      rec_prdct_config                PRDCT_CONFIG%ROWTYPE;
      REQUIRED_PARM_NULL              EXCEPTION;

   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
       IF in_cust_id IS NULL THEN
          out_rtn_msg := 'in_cust_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- delete CUST children first:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM CUST_CLNT ...');
      DELETE FROM CUST_CLNT
       WHERE CUST_ID = in_cust_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CUST_CLNT rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM CUST_PARM ...');
      DELETE FROM CUST_PARM
       WHERE CUST_ID = in_cust_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CUST_PARM rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM WLT_PRVDR_CUST_MAP ...');
      DELETE FROM WLT_PRVDR_CUST_MAP
       WHERE CUST_ID = in_cust_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('WLT_PRVDR_CUST_MAP rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM PRDCT_CONFIG ...');
      FOR rec_prdct_config IN
          (SELECT * FROM PRDCT_CONFIG WHERE CUST_ID = in_cust_id)
      LOOP
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM PRDCT_CONFIG_PARM ...');
          DELETE FROM PRDCT_CONFIG_PARM WHERE CONFIG_UUID = rec_prdct_config.CONFIG_UUID;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM PRDCT_CONFIG_ACS_CTRL ...');
          DELETE FROM PRDCT_CONFIG_ACS_CTRL WHERE CONFIG_UUID = rec_prdct_config.CONFIG_UUID;
      END LOOP;
      DELETE FROM PRDCT_CONFIG WHERE CUST_ID = in_cust_id;
      
      --PLACEHOLDER FOR NOW:
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM RULE_SET ...');
      -- add code
      
      DELETE FROM CUST_PARM
       WHERE CUST_ID = in_cust_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CUST_PARM rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM CUST_PARM ...');
      DELETE FROM CUST_PARM
       WHERE CUST_ID = in_cust_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CUST_PARM rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      --------------------------------------------------------------------------
      -- now delete CUST:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM CUST ...');
      DELETE FROM CUST
       WHERE CUST_ID = in_cust_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CUST rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOTAL ROWS deleted: '|| rows_deleted);
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_cust_id 
                     || ' successfully deleted!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_cust_id
                        || ' not deleted, Oracle error = ' 
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_CUST_DELETE;
   PROCEDURE PRC_CUST_CLNT_CLONE (
                     in_base_cust_id                  IN NUMBER,   --required
                     in_new_cust_id                   IN NUMBER,   --required
                     in_base_clnt_id                  IN VARCHAR2, --required
                     in_new_clnt_id                   IN VARCHAR2, --required
                     out_rtn_cd                      OUT NUMBER,
                     out_rtn_msg                     OUT VARCHAR2)

   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_CUST_CLNT_CLONE';
      REQUIRED_PARM_NULL              EXCEPTION;
      BAD_RETURN                      EXCEPTION;


   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
       IF in_base_cust_id IS NULL THEN
          out_rtn_msg := 'in_base_cust_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_cust_id IS NULL THEN
          out_rtn_msg := 'in_new_cust_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_base_clnt_id IS NULL THEN
          out_rtn_msg := 'in_base_clnt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_clnt_id IS NULL THEN
          out_rtn_msg := 'in_new_clnt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

          
      --------------------------------------------------------------------------
      -- clone account range by calling other procedures:
      --------------------------------------------------------------------------
      PRC_CUST_CLNT_DELETE(in_new_cust_id, 
                           in_new_clnt_id,
                           out_rtn_cd,
                           out_rtn_msg);
       IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       
                         
      PRC_CUST_DELETE(in_new_cust_id, 
                      out_rtn_cd,
                      out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       
                            
      PRC_CLNT_DELETE(in_new_clnt_id,
                      out_rtn_cd,
                      out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       
      
      PRC_CUST_ADD(in_base_cust_id,
                   in_new_cust_id,
                   'N',
                   null,
                   out_rtn_cd,
                   out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       
      
      PRC_CLNT_ADD(in_base_clnt_id,
                   in_new_clnt_id,
                   'N',
                   'N',
                   out_rtn_cd,
                   out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       
      
      PRC_CUST_CLNT_ADD(in_new_cust_id,
                        in_new_clnt_id,
                        out_rtn_cd,
                        out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       
 
      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_new_cust_id  
                     || in_new_clnt_id || ' successfully cloned!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
      
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN BAD_RETURN
      THEN
          ROLLBACK;
          
      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_cust_id
                        || in_new_clnt_id || ' not cloned, Oracle error = '
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_CUST_CLNT_CLONE;
   PROCEDURE PRC_CUST_CLNT_ADD (
                        in_cust_id                    IN  NUMBER,   --required
                        in_clnt_id                    IN  VARCHAR2, --required
                        out_rtn_cd                    OUT NUMBER,
                        out_rtn_msg                   OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_CUST_CLNT_ADD';
      v_count                         NUMBER;
      rec_clnt                        CLNT%ROWTYPE;
      rec_cust_clnt                   CUST_CLNT%ROWTYPE;
      REQUIRED_PARM_NULL              EXCEPTION;
      NOT_FOUND                       EXCEPTION;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
       IF in_cust_id IS NULL THEN
          out_rtn_msg := 'in_cust_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
       IF in_clnt_id IS NULL THEN
          out_rtn_msg := 'in_clnt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
     
      --------------------------------------------------------------------------
      -- make sure parent rows already exists:
      --------------------------------------------------------------------------
      SELECT COUNT(*) INTO v_count FROM CUST 
       WHERE CUST_ID = in_cust_id;
      IF v_count = 0 THEN
          out_rtn_msg := 'in_cust_id=' || in_cust_id  || ' not found in CUST!';
          RAISE NOT_FOUND;
      END IF;     
       
      SELECT COUNT(*) INTO v_count FROM CLNT 
       WHERE CLNT_ID = in_clnt_id;
      IF v_count = 0 THEN
          out_rtn_msg := 'in_clnt_id=' || in_clnt_id  || ' not found in CLNT!';
          RAISE NOT_FOUND;
      END IF;      

      --------------------------------------------------------------------------
      -- insert CUST_CLNT:
      --------------------------------------------------------------------------
      FOR rec_clnt IN
          (SELECT *
             FROM CLNT
            WHERE CLNT_ID = in_clnt_id)
      LOOP
          rec_cust_clnt.BIN_SW          := rec_clnt.BIN_SW;
          rec_cust_clnt.CLNT_ID         := rec_clnt.CLNT_ID;
          rec_cust_clnt.CUST_ID         := in_cust_id;
          rec_cust_clnt.MDES_SERV_CD    := rec_clnt.MDES_SERV_CD;
          rec_cust_clnt.RPLCTN_UPDT_TS  := SYSDATE;
          rec_cust_clnt.UPDT_DT         := SYSDATE;
          rec_cust_clnt.UPDT_USER_ID    := vc_proc_name; 
          INSERT INTO CUST_CLNT
               VALUES rec_cust_clnt;
      END LOOP;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_cust_id || ',' ||
                     in_clnt_id || ' added!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN NOT_FOUND THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;

      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_cust_id || ',' ||
                        in_clnt_id || ' ADD FAILED, ORACLE ERROR = ' || 
                        SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_CUST_CLNT_ADD;
   PROCEDURE PRC_CUST_CLNT_DELETE (
                        in_cust_id                        IN  NUMBER,   --required
                        in_clnt_id                        IN  VARCHAR2, --required
                        out_rtn_cd                        OUT NUMBER,
                        out_rtn_msg                       OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_CUST_CLNT_DELETE';
      rows_deleted                    NUMBER := 0;
      REQUIRED_PARM_NULL              EXCEPTION;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
       IF in_cust_id IS NULL THEN
          out_rtn_msg := 'in_cust_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
       IF in_clnt_id IS NULL THEN
          out_rtn_msg := 'in_clnt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
     
      --------------------------------------------------------------------------
      -- delete CUST_CLNT:
      --------------------------------------------------------------------------
      DELETE FROM CUST_CLNT 
       WHERE CUST_ID = in_cust_id 
         AND CLNT_ID = in_clnt_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CUST_CLNT rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;
         
      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOTAL ROWS deleted: '|| rows_deleted);
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_cust_id || ',' || in_clnt_id 
                     || ' successfully deleted!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
 
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_cust_id || ',' ||
                        in_clnt_id || ' ADD FAILED, ORACLE ERROR = ' || 
                        SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_CUST_CLNT_DELETE;
   PROCEDURE PRC_PRDCT_CONFIG_CLONE (
                     in_base_config_uuid             IN VARCHAR2, --required
                     in_new_config_uuid              IN VARCHAR2, --required
                     in_new_cust_id                  IN VARCHAR2, --optional
                     in_new_config_cd                IN VARCHAR2, --optional
                     out_rtn_cd                      OUT NUMBER,
                     out_rtn_msg                     OUT VARCHAR2)

   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_PRDCT_CONFIG_CLONE';
      REQUIRED_PARM_NULL              EXCEPTION;
      BAD_RETURN                      EXCEPTION;


   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
       IF in_base_config_uuid IS NULL THEN
          out_rtn_msg := 'in_base_config_uuid cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_config_uuid IS NULL THEN
          out_rtn_msg := 'in_new_config_uuid cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
          
      --------------------------------------------------------------------------
      -- clone account range by calling other procedures:
      --------------------------------------------------------------------------
      PRC_PRDCT_CONFIG_DELETE(in_new_config_uuid, 
                              out_rtn_cd,
                              out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       
                          
      PRC_PRDCT_CONFIG_ADD(in_base_config_uuid,
                           in_new_config_uuid,
                           in_new_cust_id,
                           in_new_config_cd,
                           out_rtn_cd,
                           out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_new_config_uuid  
                     || ' successfully cloned!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN BAD_RETURN THEN
          ROLLBACK;

      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_config_uuid
                        || ' not cloned, Oracle error = '
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_PRDCT_CONFIG_CLONE;
   PROCEDURE PRC_PRDCT_CONFIG_ADD (
                        in_base_config_uuid               IN  VARCHAR,  --required
                        in_new_config_uuid                IN  VARCHAR,  --required
                        in_new_cust_id                    IN  NUMBER,   --optional
                        in_new_config_cd                  IN  VARCHAR,  --optional
                        out_rtn_cd                        OUT NUMBER,
                        out_rtn_msg                       OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2(50) := 'PRC_PRDCT_CONFIG_ADD';
      rec_prdct_config                PRDCT_CONFIG%ROWTYPE;
      rec_prdct_config_parm           PRDCT_CONFIG_PARM%ROWTYPE;
      rec_prdct_config_acs_ctrl       PRDCT_CONFIG_ACS_CTRL%ROWTYPE;
      v_count                         NUMBER;
      INVALID_CONFIG_UUID             EXCEPTION;
      REQUIRED_PARM_NULL              EXCEPTION;
      NOT_FOUND                       EXCEPTION;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_config_uuid IS NULL THEN
          out_rtn_msg := 'in_base_config_uuid cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_config_uuid IS NULL THEN
          out_rtn_msg := 'in_new_config_uuid cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- make sure product config to be cloned exists:
      --------------------------------------------------------------------------
      SELECT COUNT(*) INTO v_count FROM PRDCT_CONFIG 
       WHERE config_uuid = in_base_config_uuid;
      IF v_count = 0 THEN
          out_rtn_msg := 'in_base_config_uuid=' || in_base_config_uuid 
                          || ' not found in PRDCT_CONFIG!';
          RAISE NOT_FOUND;
      END IF;      

      --------------------------------------------------------------------------
      -- clone PRDCT_CONFIG:
      --------------------------------------------------------------------------
      SELECT *
        INTO rec_prdct_config
        FROM PRDCT_CONFIG
       WHERE CONFIG_UUID = in_base_config_uuid;

      IF in_new_config_cd IS NOT NULL THEN
          rec_prdct_config.CONFIG_CD := in_new_config_cd;
      END IF;
      IF in_new_cust_id IS NOT NULL THEN
          rec_prdct_config.CUST_ID := in_new_cust_id;
      END IF;
      rec_prdct_config.CONFIG_UUID := in_new_config_uuid;
      
      rec_prdct_config.CONFIG_NAM := 'REGRESSION - ' || in_new_cust_id 
          || '/' || rec_prdct_config.CONFIG_CD;
      rec_prdct_config.RPLCTN_UPDT_TS := SYSDATE;
      rec_prdct_config.UPDT_TS := SYSDATE;
      rec_prdct_config.UPDT_USER_ID := vc_proc_name;

      INSERT INTO PRDCT_CONFIG
           VALUES rec_prdct_config;

      --------------------------------------------------------------------------
      -- clone children - PRDCT_CONFIG_PARM:
      --------------------------------------------------------------------------
      FOR rec_prdct_config_parm IN
          (SELECT *
             FROM PRDCT_CONFIG_PARM
            WHERE CONFIG_UUID = in_base_config_uuid
            ORDER BY PARM_NAM)
      LOOP
      rec_prdct_config_parm.CONFIG_UUID := in_new_config_uuid;
      rec_prdct_config_parm.RPLCTN_UPDT_TS := SYSDATE;
      rec_prdct_config_parm.UPDT_USER_ID := vc_proc_name;
          INSERT INTO PRDCT_CONFIG_PARM
               VALUES rec_prdct_config_parm;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone children - PRDCT_CONFIG_ACS_CTRL:
      --------------------------------------------------------------------------
      FOR rec_prdct_config_acs_ctrl IN
          (SELECT *
             FROM PRDCT_CONFIG_ACS_CTRL
            WHERE CONFIG_UUID = in_base_config_uuid
            ORDER BY ACS_LVL_CD, ACS_LVL_VAL)
      LOOP

      rec_prdct_config_acs_ctrl.CONFIG_UUID := in_new_config_uuid;
      rec_prdct_config_acs_ctrl.RPLCTN_UPDT_TS := SYSDATE;
      rec_prdct_config_acs_ctrl.UPDT_USER_ID := vc_proc_name;
      rec_prdct_config_acs_ctrl.UPDT_TS := SYSDATE;
          INSERT INTO PRDCT_CONFIG_PARM
               VALUES rec_prdct_config_acs_ctrl;
      END LOOP;
      
      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_new_config_uuid || 
                           ' successfully added!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN NOT_FOUND THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;
 
      WHEN INVALID_CONFIG_UUID THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1004;
          ROLLBACK;

      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_config_uuid ||
            ' not added, Oracle error = ' || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_PRDCT_CONFIG_ADD;
   PROCEDURE PRC_PRDCT_CONFIG_DELETE (
                        in_config_uuid                    IN  VARCHAR,   --required
                        out_rtn_cd                        OUT NUMBER,
                        out_rtn_msg                       OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2(50) := 'PRC_PRDCT_CONFIG_DELETE';
      rows_deleted                    NUMBER := 0;
      REQUIRED_PARM_NULL              EXCEPTION;

   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
       IF in_config_uuid IS NULL THEN
          out_rtn_msg := 'in_config_uuid cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- delete PRDCT_CONFIG children first:
      --------------------------------------------------------------------------
      DELETE FROM PRDCT_CONFIG_PARM
       WHERE CONFIG_UUID = in_config_uuid;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('PRDCT_CONFIG_PARM rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      DELETE FROM PRDCT_CONFIG_ACS_CTRL
       WHERE CONFIG_UUID = in_config_uuid;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('PRDCT_CONFIG_ACS_CTRL rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;
         
      --------------------------------------------------------------------------
      -- now delete PRDCT_CONFIG:
      --------------------------------------------------------------------------
      DELETE FROM PRDCT_CONFIG
       WHERE CONFIG_UUID = in_config_uuid;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('PRDCT_CONFIG rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOTAL ROWS deleted: '|| rows_deleted);
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_config_uuid 
                     || ' successfully deleted!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_config_uuid
                        || ' not deleted, Oracle error = ' 
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_PRDCT_CONFIG_DELETE;
   PROCEDURE PRC_TOKEN_RQSTR_CLONE (
                     in_base_token_rqstr_id           IN  NUMBER,   --required
                     in_new_token_rqstr_id            IN  NUMBER,   --required
                     in_new_token_rqstr_nam           IN  VARCHAR2, --optional
                     in_new_partn_num                 IN  NUMBER,   --optional
                     in_new_token_assurance_lvl_num   IN  NUMBER,   --optional
                     out_rtn_cd                       OUT NUMBER,
                     out_rtn_msg                      OUT VARCHAR2)

   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_TOKEN_RQSTR_CLONE';
      REQUIRED_PARM_NULL              EXCEPTION;
      BAD_RETURN                      EXCEPTION;


   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_token_rqstr_id IS NULL THEN
          out_rtn_msg := 'in_base_token_rqstr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_token_rqstr_id IS NULL THEN
          out_rtn_msg := 'in_new_token_rqstr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
          
      --------------------------------------------------------------------------
      -- clone account range by calling other procedures:
      --------------------------------------------------------------------------
      PRC_TOKEN_RQSTR_DELETE(in_new_token_rqstr_id, 
                             in_new_partn_num,
                             out_rtn_cd,
                             out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       
                          
      PRC_TOKEN_RQSTR_ADD(in_base_token_rqstr_id,
                          in_new_token_rqstr_id,
                          in_new_token_rqstr_nam,
                          in_new_partn_num,
                          in_new_token_assurance_lvl_num,
                          out_rtn_cd,
                          out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_new_token_rqstr_id  
                     || in_new_partn_num || ' successfully cloned!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
   
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN BAD_RETURN THEN
          ROLLBACK;

      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_token_rqstr_id
                        || in_new_partn_num || ' not cloned, Oracle error = '
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_TOKEN_RQSTR_CLONE;
   PROCEDURE PRC_TOKEN_RQSTR_ADD (
                     in_base_token_rqstr_id           IN  NUMBER,   --required
                     in_new_token_rqstr_id            IN  NUMBER,   --required
                     in_new_token_rqstr_nam           IN  VARCHAR2, --optional
                     in_new_partn_num                 IN  NUMBER,   --optional
                     in_new_token_assurance_lvl_num   IN  NUMBER,   --optional
                     out_rtn_cd                       OUT NUMBER,
                     out_rtn_msg                      OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_TOKEN_RQSTR_ADD';
      v_active_partn_num              ACTV_PARTN.PARTN_NUM%TYPE;
      v_new_partn_num                 ACTV_PARTN.PARTN_NUM%TYPE;
      v_count                         NUMBER;
      rec_token_rqstr                 TOKEN_RQSTR%ROWTYPE;
      rec_token_rqstr_grp_assn        TOKEN_RQSTR_GRP_ASSN%ROWTYPE;
      rec_token_rqstr_parm            TOKEN_RQSTR_PARM%ROWTYPE;
      rec_token_rqstr_token_type      TOKEN_RQSTR_TOKEN_TYPE%ROWTYPE;
      REQUIRED_PARM_NULL              EXCEPTION;
      NOT_FOUND                       EXCEPTION;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- get active partition:
      --------------------------------------------------------------------------
      SELECT partn_num INTO v_active_partn_num FROM ACTV_PARTN;
      IF in_new_partn_num IS NULL THEN
          v_new_partn_num := v_active_partn_num;
      ELSE
          v_new_partn_num := in_new_partn_num;
      END IF;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('v_active_partn_num: '|| v_active_partn_num);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('v_new_partn_num: '|| v_new_partn_num);

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_token_rqstr_id IS NULL THEN
          out_rtn_msg := 'in_base_token_rqstr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_token_rqstr_id IS NULL THEN
          out_rtn_msg := 'in_new_token_rqstr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- make sure token requestor to be cloned exists:
      --------------------------------------------------------------------------
      SELECT COUNT(*) INTO v_count FROM TOKEN_RQSTR 
       WHERE PARTN_NUM = v_active_partn_num 
         AND TOKEN_RQSTR_ID = in_base_token_rqstr_id;
      IF v_count = 0 THEN
          out_rtn_msg := 'v_active_partn_num=' || v_active_partn_num 
                         || ', in_base_token_rqstr_id=' || in_base_token_rqstr_id 
                         || ' not found in TOKEN_RQSTR!';
          RAISE NOT_FOUND;
      END IF;      

      --------------------------------------------------------------------------
      -- clone TOKEN_RQSTR (partitioned):
      --------------------------------------------------------------------------
      SELECT *
        INTO rec_token_rqstr
        FROM TOKEN_RQSTR
       WHERE PARTN_NUM = v_active_partn_num 
         AND TOKEN_RQSTR_ID = in_base_token_rqstr_id;
      IF in_new_token_rqstr_nam IS NULL THEN
          rec_token_rqstr.TOKEN_RQSTR_NAM := rec_token_rqstr.TOKEN_RQSTR_NAM || ' CLONE';
      ELSE
          rec_token_rqstr.TOKEN_RQSTR_NAM := in_new_token_rqstr_nam;
      END IF;
      IF in_new_token_assurance_lvl_num IS NOT NULL THEN
          rec_token_rqstr.token_assurance_lvl_num := in_new_token_assurance_lvl_num;
      END IF;
      rec_token_rqstr.PARTN_NUM := v_new_partn_num;
      rec_token_rqstr.TOKEN_RQSTR_ID := in_new_token_rqstr_id;
      rec_token_rqstr.RPLCTN_UPDT_TS := SYSDATE;

      INSERT INTO TOKEN_RQSTR
           VALUES rec_token_rqstr;

      --------------------------------------------------------------------------
      -- clone TOKEN_RQSTR_GRP_ASSN:
      --------------------------------------------------------------------------
      FOR rec_token_rqstr_grp_assn IN
          (SELECT *
             FROM TOKEN_RQSTR_GRP_ASSN
            WHERE TOKEN_RQSTR_ID = in_base_token_rqstr_id)
      LOOP
          -- not partitioned so make sure not already added when cloned for a
          -- different partition:
          SELECT COUNT(*) INTO v_count FROM TOKEN_RQSTR_GRP_ASSN
            WHERE TOKEN_RQSTR_ID = in_new_token_rqstr_id
              AND TOKEN_RQSTR_GRP_ID = rec_token_rqstr_grp_assn.token_rqstr_grp_id;
          IF v_count = 0 THEN
              rec_token_rqstr_grp_assn.TOKEN_RQSTR_ID := in_new_token_rqstr_id;
              rec_token_rqstr_grp_assn.RPLCTN_UPDT_TS := SYSDATE;
              INSERT INTO TOKEN_RQSTR_GRP_ASSN
                   VALUES rec_token_rqstr_grp_assn;
          END IF;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone TOKEN_RQSTR_PARM:
      --------------------------------------------------------------------------
      FOR rec_token_rqstr_parm IN
          (SELECT *
             FROM TOKEN_RQSTR_PARM
            WHERE TOKEN_RQSTR_ID = in_base_token_rqstr_id)
      LOOP
          -- not partitioned so make sure not already added when cloned for a
          -- different partition:
          SELECT COUNT(*) INTO v_count FROM TOKEN_RQSTR_PARM
            WHERE TOKEN_RQSTR_ID = in_new_token_rqstr_id
              AND PARM_NAM = rec_token_rqstr_parm.parm_nam;
          IF v_count = 0 THEN
              rec_token_rqstr_parm.TOKEN_RQSTR_ID := in_new_token_rqstr_id;
              rec_token_rqstr_parm.RPLCTN_UPDT_TS := SYSDATE;
              INSERT INTO TOKEN_RQSTR_PARM
                   VALUES rec_token_rqstr_parm;
          END IF;
      END LOOP;
      
      --------------------------------------------------------------------------
      -- clone TOKEN_RQSTR_TOKEN_TYPE (partitioned):
      --------------------------------------------------------------------------
      FOR rec_token_rqstr_token_type IN
          (SELECT *
             FROM TOKEN_RQSTR_TOKEN_TYPE
            WHERE PARTN_NUM = v_active_partn_num 
              AND TOKEN_RQSTR_ID = in_base_token_rqstr_id)
      LOOP
          rec_token_rqstr_token_type.PARTN_NUM := v_new_partn_num;
          rec_token_rqstr_token_type.TOKEN_RQSTR_ID := in_new_token_rqstr_id;
          rec_token_rqstr_token_type.RPLCTN_UPDT_TS := SYSDATE;
          INSERT INTO TOKEN_RQSTR_TOKEN_TYPE
               VALUES rec_token_rqstr_token_type;
      END LOOP;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_new_token_rqstr_id || 
                           ' successfully added!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN NOT_FOUND THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;

      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_token_rqstr_id ||
            ' not added, Oracle error = ' || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_TOKEN_RQSTR_ADD;
   PROCEDURE PRC_TOKEN_RQSTR_DELETE (
                 in_token_rqstr_id             IN  NUMBER, --required
                 in_partn_num                  IN  NUMBER, --optional                        
                 out_rtn_cd                    OUT NUMBER,
                 out_rtn_msg                   OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_TOKEN_RQSTR_DELETE';
      v_count                         NUMBER;
      v_rows_deleted                  NUMBER;
      rec_token_rqstr                 TOKEN_RQSTR%ROWTYPE;
      rec_token_rqstr_grp_assn        TOKEN_RQSTR_GRP_ASSN%ROWTYPE;
      rec_token_rqstr_parm            TOKEN_RQSTR_PARM%ROWTYPE;
      rec_token_rqstr_token_type      TOKEN_RQSTR_TOKEN_TYPE%ROWTYPE;
      v_msg                           VARCHAR2(1000);
      REQUIRED_PARM_NULL              EXCEPTION;

   PROCEDURE LPRC_TOKEN_RQSTR_DELETE IS
   BEGIN
      --------------------------------------------------------------------------
      -- delete partioned TOKEN_RQSTR children first:
      --------------------------------------------------------------------------
      DELETE FROM TOKEN_RQSTR_TOKEN_TYPE
       WHERE TOKEN_RQSTR_ID = in_token_rqstr_id
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOKEN_RQSTR_TOKEN_TYPE rows deleted: '|| SQL%ROWCOUNT);
      v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

      --------------------------------------------------------------------------
      -- now delete partioned TOKEN_RQSTR:
      --------------------------------------------------------------------------
      DELETE FROM TOKEN_RQSTR
       WHERE TOKEN_RQSTR_ID = in_token_rqstr_id
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOKEN_RQSTR rows deleted: '|| SQL%ROWCOUNT);
      v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

      --------------------------------------------------------------------------
      -- and finally delete non-partioned TOKEN_RQSTR children only if no more 
      -- partioned TOKEN_RQSTR rows exist:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('CHECKING NON-PARTIONED TABLES ...');
      SELECT COUNT(*) INTO v_count
        FROM TOKEN_RQSTR
       WHERE TOKEN_RQSTR_ID = in_token_rqstr_id;
      IF v_count = 0 THEN

          DELETE FROM TOKEN_RQSTR_GRP_ASSN
           WHERE TOKEN_RQSTR_ID = in_token_rqstr_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOKEN_RQSTR_GRP_ASSN rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

          DELETE FROM TOKEN_RQSTR_MERCH
           WHERE TOKEN_RQSTR_ID = in_token_rqstr_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOKEN_RQSTR_MERCH rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

          DELETE FROM TOKEN_RQSTR_PARM
           WHERE TOKEN_RQSTR_ID = in_token_rqstr_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOKEN_RQSTR_PARM rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;
      ELSE
          v_msg := ' deleted 0 (more partioned TOKEN_RQSTR entries for ' ||
                   in_token_rqstr_id || ' still exist)';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOKEN_RQSTR_GRP_ASSN' || v_msg);
          PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOKEN_RQSTR_MERCH' || v_msg);
          PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOKEN_RQSTR_PARM' || v_msg);
      END IF;
   END;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_token_rqstr_id IS NULL THEN
          out_rtn_msg := 'in_token_rqstr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- now delete the token requestor:
      --------------------------------------------------------------------------
      SELECT COUNT(*) INTO v_count
        FROM TOKEN_RQSTR
        WHERE TOKEN_RQSTR_ID = in_token_rqstr_id
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM); 
      IF v_count > 0 THEN
          LPRC_TOKEN_RQSTR_DELETE;
      END IF;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOTAL ROWS deleted: '|| v_rows_deleted);
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_token_rqstr_id 
                     || ' successfully deleted!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
       WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_token_rqstr_id
                        || ' not deleted, Oracle error = ' 
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_TOKEN_RQSTR_DELETE;
   PROCEDURE PRC_WLT_PRVDR_ADD (
                        in_base_wlt_prvdr_id            IN  NUMBER,  --required
                        in_new_wlt_prvdr_id             IN  NUMBER,  --required
                        in_new_wlt_prvdr_name           IN  VARCHAR, --optional
                        in_new_partn_num                IN  NUMBER,  --optional
                        out_rtn_cd                      OUT NUMBER,
                        out_rtn_msg                     OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_WLT_PRVDR_ADD';
      v_active_partn_num              ACTV_PARTN.PARTN_NUM%TYPE;
      v_partn_num                     ACTV_PARTN.PARTN_NUM%TYPE;
      rec_wlt_prvdr                   WLT_PRVDR%ROWTYPE;
      rec_wlt_prvdr_actv_cd_mthd      WLT_PRVDR_ACTV_CD_MTHD%ROWTYPE;
      rec_wlt_prvdr_algrthm_ver       WLT_PRVDR_ALGRTHM_VER%ROWTYPE;
      rec_wlt_prvdr_cardlet           WLT_PRVDR_CARDLET%ROWTYPE;
      rec_wlt_prvdr_dvc_type          WLT_PRVDR_DVC_TYPE%ROWTYPE;
      rec_wlt_prvdr_fpan_src          WLT_PRVDR_FPAN_SRC%ROWTYPE;
      rec_wlt_prvdr_parm              WLT_PRVDR_PARM%ROWTYPE;
      v_count                         NUMBER;
      v_id                            NUMBER;
      v_id_str                        VARCHAR2(25);
      v_wlt_prvdr_id_str              VARCHAR2(100);
      v_len                           NUMBER;
      v_actv_cd_mthd_cd               WLT_PRVDR_ACTV_CD_MTHD.ACTV_CD_MTHD_CD%TYPE;
      MAX_WLT_PRVDR_ID_LEN            NUMBER := 3;
      MAX_WLT_PRVDR_ACTV_CD_ID_LEN    NUMBER := 11;
      REQUIRED_PARM_NULL              EXCEPTION;
      INVALID_WLT_PRVDR_ID_LEN        EXCEPTION;
      NOT_FOUND                       EXCEPTION;
      INVALID_ACTV_CD_MTHD_CD         EXCEPTION;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ... ');
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- get active partition:
      --------------------------------------------------------------------------
      SELECT partn_num INTO v_active_partn_num FROM ACTV_PARTN;
      IF in_new_partn_num IS NULL THEN
          v_partn_num := v_active_partn_num;
      ELSE
          v_partn_num := in_new_partn_num;
      END IF;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_active_partn_num: '|| v_active_partn_num);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_partn_num: '|| v_partn_num);

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_wlt_prvdr_id IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_base_wlt_prvdr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_wlt_prvdr_id IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_new_wlt_prvdr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- additional check on new wlt_prvdr_id:
      --------------------------------------------------------------------------
      v_wlt_prvdr_id_str := TO_CHAR(in_new_wlt_prvdr_id);
      if LENGTH(v_wlt_prvdr_id_str) > MAX_WLT_PRVDR_ID_LEN THEN
          out_rtn_msg := 'length of in_new_wlt_prvdr_id=' ||  in_new_wlt_prvdr_id
                         || ' exceeds max of ' || MAX_WLT_PRVDR_ID_LEN;
          RAISE INVALID_WLT_PRVDR_ID_LEN;
      END IF;

      --------------------------------------------------------------------------
      -- make sure wallet provider to be cloned exists:
      --------------------------------------------------------------------------
      SELECT COUNT(*) INTO v_count FROM WLT_PRVDR 
       WHERE PARTN_NUM = v_active_partn_num 
         AND WLT_PRVDR_ID = in_base_wlt_prvdr_id;
      IF v_count = 0 THEN
          out_rtn_msg := vc_proc_name || ': v_active_partn_num=' || v_active_partn_num || 
                         ', in_base_wlt_prvdr_id=' || in_base_wlt_prvdr_id || 
                         ' not found in WLT_PRVDR!';
          RAISE NOT_FOUND;
      END IF;      

      --------------------------------------------------------------------------
      -- clone WLT_PRVDR (partioned):
      --------------------------------------------------------------------------
      SELECT * INTO rec_wlt_prvdr
        FROM WLT_PRVDR
       WHERE PARTN_NUM = v_active_partn_num 
         AND WLT_PRVDR_ID = in_base_wlt_prvdr_id;
      rec_wlt_prvdr.PARTN_NUM := v_partn_num;
      rec_wlt_prvdr.WLT_PRVDR_ID := in_new_wlt_prvdr_id;
      IF in_new_wlt_prvdr_name IS NULL THEN
          rec_wlt_prvdr.WLT_PRVDR_NAM := rec_wlt_prvdr.WLT_PRVDR_NAM || ' CLONE';
      ELSE
          rec_wlt_prvdr.WLT_PRVDR_NAM := in_new_wlt_prvdr_name;
      END IF;
      rec_wlt_prvdr.RPLCTN_UPDT_TS := SYSDATE;
      INSERT INTO WLT_PRVDR VALUES rec_wlt_prvdr;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': INSERTED INTO WLT_PRVDR');

      --------------------------------------------------------------------------
      -- clone WLT_PRVDR_ACTV_CD_MTHD (not partioned):
      --------------------------------------------------------------------------
      v_id := 0;
      v_len := MAX_WLT_PRVDR_ACTV_CD_ID_LEN - LENGTH(TO_CHAR(in_new_wlt_prvdr_id));
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_len=' || v_len);
      FOR rec_wlt_prvdr_actv_cd_mthd IN
          (SELECT *
             FROM WLT_PRVDR_ACTV_CD_MTHD
            WHERE WLT_PRVDR_ID = in_base_wlt_prvdr_id)
      LOOP
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
              || ': rec_wlt_prvdr_actv_cd_mthd.WLT_PRVDR_ID=' 
              || rec_wlt_prvdr_actv_cd_mthd.WLT_PRVDR_ID
              || ', rec_wlt_prvdr_actv_cd_mthd.ACTV_CD_MTHD_CD=' 
              || rec_wlt_prvdr_actv_cd_mthd.ACTV_CD_MTHD_CD);
          -- not partitioned so make sure not already added when cloned for a
          -- different partition:
          SELECT COUNT(*) INTO v_count FROM WLT_PRVDR_ACTV_CD_MTHD
            WHERE WLT_PRVDR_ID = in_new_wlt_prvdr_id
              AND ACTV_CD_MTHD_CD = rec_wlt_prvdr_actv_cd_mthd.ACTV_CD_MTHD_CD;
          IF v_count = 0 THEN
              v_actv_cd_mthd_cd := rec_wlt_prvdr_actv_cd_mthd.ACTV_CD_MTHD_CD;
              CASE (v_actv_cd_mthd_cd)
                  WHEN 'ACC' THEN
                      v_id := 1;
                  WHEN 'BAP' THEN
                      v_id := 2;
                  WHEN 'CLC' THEN
                      v_id := 3;
                  WHEN 'EMA' THEN
                      v_id := 4;
                  WHEN 'OBC' THEN
                      v_id := 5;
                  WHEN 'SMS' THEN
                      v_id := 6;
                  WHEN 'STC' THEN
                      v_id := 7;
                  WHEN 'WEB' THEN
                      v_id := 8;
                  ELSE
                      out_rtn_msg := vc_proc_name 
                          || ': v_actv_cd_mthd_cd=' || v_actv_cd_mthd_cd
                          || ' not supported ... code fix required!';
                      RAISE INVALID_ACTV_CD_MTHD_CD;
              END CASE;
              
              v_id_str := '000000000' || v_id;
--              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_id_str=' 
--                                             || v_id_str);
              v_id_str := SUBSTR(v_id_str, v_len*-1);
--              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_id_str=' 
--                                             || v_id_str);
              v_id_str := in_new_wlt_prvdr_id || v_id_str;
--              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_id_str=' 
--                                             || v_id_str);
              rec_wlt_prvdr_actv_cd_mthd.WLT_PRVDR_ACTV_CD_MTHD_ID := v_id_str;
              rec_wlt_prvdr_actv_cd_mthd.WLT_PRVDR_ID := in_new_wlt_prvdr_id;
              rec_wlt_prvdr_actv_cd_mthd.RPLCTN_UPDT_TS := SYSDATE;
              INSERT INTO WLT_PRVDR_ACTV_CD_MTHD
                   VALUES rec_wlt_prvdr_actv_cd_mthd;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
                  || ': INSERTED INTO WLT_PRVDR_ACTV_CD_MTHD' 
                  || ', ACTV_CD_MTHD_CD=' || rec_wlt_prvdr_actv_cd_mthd.ACTV_CD_MTHD_CD
                  || ', WLT_PRVDR_ACTV_CD_MTHD_ID=' || rec_wlt_prvdr_actv_cd_mthd.WLT_PRVDR_ACTV_CD_MTHD_ID);
          END IF;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone WLT_PRVDR_ALGRTHM_VER (not partioned):
      --------------------------------------------------------------------------
      FOR rec_wlt_prvdr_algrthm_ver IN
          (SELECT *
             FROM WLT_PRVDR_ALGRTHM_VER
            WHERE WLT_PRVDR_ID = in_base_wlt_prvdr_id)
      LOOP
          -- not partitioned so make sure not already added when cloned for a
          -- different partition:
          SELECT COUNT(*) INTO v_count FROM WLT_PRVDR_ALGRTHM_VER
            WHERE WLT_PRVDR_ID = in_new_wlt_prvdr_id
              AND WLT_PRVDR_ALGRTHM_VER_CD = rec_wlt_prvdr_algrthm_ver.WLT_PRVDR_ALGRTHM_VER_CD;
          IF v_count = 0 THEN
              rec_wlt_prvdr_algrthm_ver.WLT_PRVDR_ID := in_new_wlt_prvdr_id;
              rec_wlt_prvdr_algrthm_ver.RPLCTN_UPDT_TS := SYSDATE;
              INSERT INTO WLT_PRVDR_ALGRTHM_VER
                   VALUES rec_wlt_prvdr_algrthm_ver;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
                  || ': INSERTED INTO WLT_PRVDR_ALGRTHM_VER'
                  || ', WLT_PRVDR_ALGRTHM_VER_CD=' || rec_wlt_prvdr_algrthm_ver.WLT_PRVDR_ALGRTHM_VER_CD);

          END IF;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone WLT_PRVDR_CARDLET (not partioned):
      --------------------------------------------------------------------------
      FOR rec_wlt_prvdr_cardlet IN
          (SELECT *
             FROM WLT_PRVDR_CARDLET
            WHERE WLT_PRVDR_ID = in_base_wlt_prvdr_id)
      LOOP
          -- not partitioned so make sure not already added when cloned for a
          -- different partition:
          SELECT COUNT(*) INTO v_count FROM WLT_PRVDR_CARDLET
            WHERE WLT_PRVDR_ID = in_new_wlt_prvdr_id
              AND WLT_PRVDR_CARDLET_VER_ID = rec_wlt_prvdr_cardlet.WLT_PRVDR_CARDLET_VER_ID;
          IF v_count = 0 THEN
              rec_wlt_prvdr_cardlet.WLT_PRVDR_ID := in_new_wlt_prvdr_id;
              rec_wlt_prvdr_cardlet.RPLCTN_UPDT_TS := SYSDATE;
              INSERT INTO WLT_PRVDR_CARDLET
                   VALUES rec_wlt_prvdr_cardlet;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
                  || ': INSERTED INTO WLT_PRVDR_CARDLET'                  
                  || ', CARDLET_ID=' || rec_wlt_prvdr_cardlet.CARDLET_ID);

          END IF;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone WLT_PRVDR_DVC_TYPE (not partioned):
      --------------------------------------------------------------------------
      FOR rec_wlt_prvdr_dvc_type IN
          (SELECT *
             FROM WLT_PRVDR_DVC_TYPE
            WHERE WLT_PRVDR_ID = in_base_wlt_prvdr_id)
      LOOP
          -- not partitioned so make sure not already added when cloned for a
          -- different partition:
          SELECT COUNT(*) INTO v_count FROM WLT_PRVDR_DVC_TYPE
            WHERE WLT_PRVDR_ID = in_new_wlt_prvdr_id
              AND WLT_PRVDR_DVC_TYPE_CD = rec_wlt_prvdr_dvc_type.WLT_PRVDR_DVC_TYPE_CD
              AND TOKEN_TYPE_CD = rec_wlt_prvdr_dvc_type.TOKEN_TYPE_CD;
          IF v_count = 0 THEN
              rec_wlt_prvdr_dvc_type.WLT_PRVDR_ID := in_new_wlt_prvdr_id;
              rec_wlt_prvdr_dvc_type.RPLCTN_UPDT_TS := SYSDATE;
              INSERT INTO WLT_PRVDR_DVC_TYPE
                   VALUES rec_wlt_prvdr_dvc_type;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
                  || ': INSERTED INTO WLT_PRVDR_DVC_TYPE'
                  || ', WLT_PRVDR_DVC_TYPE_CD=' || rec_wlt_prvdr_dvc_type.WLT_PRVDR_DVC_TYPE_CD
                  || ', TOKEN_TYPE_CD=' || rec_wlt_prvdr_dvc_type.TOKEN_TYPE_CD);
          END IF;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone WLT_PRVDR_FPAN_SRC (not partioned):
      --------------------------------------------------------------------------
      FOR rec_wlt_prvdr_fpan_src IN
          (SELECT *
             FROM WLT_PRVDR_FPAN_SRC
            WHERE WLT_PRVDR_ID = in_base_wlt_prvdr_id)
      LOOP
          -- not partitioned so make sure not already added when cloned for a
          -- different partition:
          SELECT COUNT(*) INTO v_count FROM WLT_PRVDR_FPAN_SRC
            WHERE WLT_PRVDR_ID = in_new_wlt_prvdr_id
              AND WLT_PRVDR_FPAN_SRC_CD = rec_wlt_prvdr_fpan_src.WLT_PRVDR_FPAN_SRC_CD;
          IF v_count = 0 THEN
              rec_wlt_prvdr_fpan_src.WLT_PRVDR_ID := in_new_wlt_prvdr_id;
              rec_wlt_prvdr_fpan_src.RPLCTN_UPDT_TS := SYSDATE;
              INSERT INTO WLT_PRVDR_FPAN_SRC
                   VALUES rec_wlt_prvdr_fpan_src;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
                  || ': INSERTED INTO WLT_PRVDR_FPAN_SRC'
                  || ', WLT_PRVDR_FPAN_SRC_CD=' || rec_wlt_prvdr_fpan_src.WLT_PRVDR_FPAN_SRC_CD);
          END IF;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone WLT_PRVDR_PARM (not partioned):
      --------------------------------------------------------------------------
      FOR rec_wlt_prvdr_parm IN
          (SELECT *
             FROM WLT_PRVDR_PARM
            WHERE WLT_PRVDR_ID = in_base_wlt_prvdr_id)
      LOOP
          -- not partitioned so make sure not already added when cloned for a
          -- different partition:
          SELECT COUNT(*) INTO v_count FROM WLT_PRVDR_PARM
            WHERE WLT_PRVDR_ID = in_new_wlt_prvdr_id
              AND PARM_NAM = rec_wlt_prvdr_parm.PARM_NAM;
          IF v_count = 0 THEN
              rec_wlt_prvdr_parm.PARM_ID := WLT_PRVDR_PARM_ID_SEQ.NEXTVAL;
              rec_wlt_prvdr_parm.WLT_PRVDR_ID := in_new_wlt_prvdr_id;
              rec_wlt_prvdr_parm.RPLCTN_UPDT_TS := SYSDATE;
              INSERT INTO WLT_PRVDR_PARM
                   VALUES rec_wlt_prvdr_parm;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
                  || ': INSERTED INTO WLT_PRVDR_PARM'
                  || ', PARM_NAM=' || rec_wlt_prvdr_parm.PARM_NAM);
          END IF;
      END LOOP;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': PARTN_NUM=' || v_partn_num || 
                     ', WLT_PRVDR_ID=' || in_new_wlt_prvdr_id || 
                     ',WLT_PRVDR_NAM="' || in_new_wlt_prvdr_name || 
                     '" completed!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;
      WHEN NOT_FOUND THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;
      WHEN INVALID_WLT_PRVDR_ID_LEN THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1003;
          ROLLBACK;
      WHEN INVALID_ACTV_CD_MTHD_CD THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1004;
          ROLLBACK;
      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_wlt_prvdr_id ||
            ' failed, Oracle error = ' || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_WLT_PRVDR_ADD;
   PROCEDURE PRC_WLT_PRVDR_CLONE (
                     in_base_wlt_prvdr_id             IN  NUMBER,   --required
                     in_new_wlt_prvdr_id              IN  NUMBER,   --required
                     in_new_wlt_prvdr_name            IN  VARCHAR2, --optional
                     in_new_partn_num                 IN  NUMBER,   --optional
                     out_rtn_cd                       OUT NUMBER,
                     out_rtn_msg                      OUT VARCHAR2)

   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_WLT_PRVDR_CLONE';
      REQUIRED_PARM_NULL              EXCEPTION;
      BAD_RETURN                      EXCEPTION;


   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ... ');
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_wlt_prvdr_id IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_base_wlt_prvdr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_wlt_prvdr_id IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_new_wlt_prvdr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
          
      --------------------------------------------------------------------------
      -- clone wallet provider by calling other procedures:
      --------------------------------------------------------------------------
      PRC_WLT_PRVDR_DELETE(in_new_wlt_prvdr_id, 
                             in_new_partn_num,
                             out_rtn_cd,
                             out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       
                          
      PRC_WLT_PRVDR_ADD(in_base_wlt_prvdr_id,
                          in_new_wlt_prvdr_id,
                          in_new_wlt_prvdr_name,
                          in_new_partn_num,
                          out_rtn_cd,
                          out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': PARTN_NUM=' || in_new_partn_num || 
                     ', WLT_PRVDR_ID=' || in_new_wlt_prvdr_id || 
                     ',WLT_PRVDR_NAM="' || in_new_wlt_prvdr_name || 
                     '" completed!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;
      WHEN BAD_RETURN THEN
          ROLLBACK;
      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_wlt_prvdr_id
                        || in_new_partn_num || ' failed, Oracle error = '
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_WLT_PRVDR_CLONE;
   PROCEDURE PRC_WLT_PRVDR_DELETE (
                 in_wlt_prvdr_id               IN  NUMBER, --required
                 in_partn_num                  IN  NUMBER, --optional                        
                 out_rtn_cd                    OUT NUMBER,
                 out_rtn_msg                   OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_WLT_PRVDR_DELETE';
      vc_local_proc_name              VARCHAR2 (50);
      v_count                         NUMBER;
      v_rows_deleted                  NUMBER := 0;
      rec_wlt_prvdr                   WLT_PRVDR%ROWTYPE;
      rec_mbl_wlt_appl                MBL_WLT_APPL%ROWTYPE;
      rec_acct_rng_mbl_wlt_appl       ACCT_RNG_MBL_WLT_APPL%ROWTYPE;
      rec_acct_rng_mbl_wlt_appl_cvm   ACCT_RNG_MBL_WLT_APPL_CVM%ROWTYPE;
      rec_acct_rng_wlt_prvdr          ACCT_RNG_WLT_PRVDR%ROWTYPE;
      rec_acct_rng_wlt_prvdr_config   ACCT_RNG_WLT_PRVDR_CONFIG%ROWTYPE;
      rec_wlt_prvdr_actv_cd_mthd      WLT_PRVDR_ACTV_CD_MTHD%ROWTYPE;
      rec_wlt_prvdr_algrthm_ver       WLT_PRVDR_ALGRTHM_VER%ROWTYPE;
      rec_wlt_prvdr_cardlet           WLT_PRVDR_CARDLET%ROWTYPE;
      rec_wlt_prvdr_dvc_type          WLT_PRVDR_DVC_TYPE%ROWTYPE;
      rec_wlt_prvdr_fpan_src          WLT_PRVDR_FPAN_SRC%ROWTYPE;
      rec_wlt_prvdr_parm              WLT_PRVDR_PARM%ROWTYPE;
      v_msg                           VARCHAR2(1000);
      REQUIRED_PARM_NULL              EXCEPTION;
      BAD_RETURN                      EXCEPTION;

   PROCEDURE LPRC_WLT_PRVDR_DELETE IS
   BEGIN
   
      --------------------------------------------------------------------------
      -- initialization:
      --------------------------------------------------------------------------
      vc_local_proc_name := 'LPRC_WLT_PRVDR_DELETE';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': STARTING ...');

      --------------------------------------------------------------------------
      -- first delete all the account range data associated with the wallet
      -- provider to be deleted:
      --------------------------------------------------------------------------
      PRVT_DELETE_ACCT_RNG_WID_DATA(NULL, in_partn_num, in_wlt_prvdr_id); 
      
      --------------------------------------------------------------------------
      -- now continue with deleting partioned WLT_PRVDR children:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name 
          || ': RETRIEVING MBL_WLT_APPL FOR ' || in_wlt_prvdr_id || ' ...');
          
      FOR rec_mbl_wlt_appl IN
          (SELECT *
             FROM MBL_WLT_APPL
            WHERE WLT_PRVDR_ID = in_wlt_prvdr_id
              AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM))
      LOOP
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name 
              || ': rec_mbl_wlt_appl.MBL_WLT_ID = ' 
              || rec_mbl_wlt_appl.MBL_WLT_ID);
      
          PRC_MBL_WLT_APPL_DELETE(rec_mbl_wlt_appl.MBL_WLT_ID, 
                                  in_partn_num,
                                  out_rtn_cd,
                                  out_rtn_msg);
          IF out_rtn_cd <> 0 THEN
              RAISE BAD_RETURN;
          END IF;                       
      END LOOP;
      
      --------------------------------------------------------------------------
      -- now delete partioned WLT_PRVDR:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': DELETE FROM WLT_PRVDR ...');
      DELETE FROM WLT_PRVDR
       WHERE WLT_PRVDR_ID = in_wlt_prvdr_id
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR rows deleted: '|| SQL%ROWCOUNT);
      v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

      --------------------------------------------------------------------------
      -- and finally delete non-partioned WLT_PRVDR children only if no more 
      -- partioned WLT_PRVDR rows exist:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': CHECKING NON-PARTIONED TABLES ...');
      SELECT COUNT(*) INTO v_count
        FROM WLT_PRVDR
       WHERE WLT_PRVDR_ID = in_wlt_prvdr_id;
      IF v_count = 0 THEN

          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': DELETE FROM WLT_PRVDR_ACTV_CD_MTHD ...');
          DELETE FROM WLT_PRVDR_ACTV_CD_MTHD
           WHERE WLT_PRVDR_ID = in_wlt_prvdr_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_ACTV_CD_MTHD rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': DELETE FROM WLT_PRVDR_ALGRTHM_VER ...');
          DELETE FROM WLT_PRVDR_ALGRTHM_VER
           WHERE WLT_PRVDR_ID = in_wlt_prvdr_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_ALGRTHM_VER rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': DELETE FROM WLT_PRVDR_CARDLET ...');
          DELETE FROM WLT_PRVDR_CARDLET
           WHERE WLT_PRVDR_ID = in_wlt_prvdr_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_CARDLET rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': DELETE FROM WLT_PRVDR_DVC_TYPE ...');
          DELETE FROM WLT_PRVDR_DVC_TYPE
           WHERE WLT_PRVDR_ID = in_wlt_prvdr_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_DVC_TYPE rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': DELETE FROM WLT_PRVDR_FPAN_SRC ...');
          DELETE FROM WLT_PRVDR_FPAN_SRC
           WHERE WLT_PRVDR_ID = in_wlt_prvdr_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_FPAN_SRC rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': DELETE FROM WLT_PRVDR_PARM ...');
          DELETE FROM WLT_PRVDR_PARM
           WHERE WLT_PRVDR_ID = in_wlt_prvdr_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_PARM rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': DELETE FROM WLT_PRVDR_CUST_MAP ...');
          DELETE FROM WLT_PRVDR_CUST_MAP
           WHERE WLT_PRVDR_ID = in_wlt_prvdr_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_CUST_MAP rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;
          
      ELSE
          v_msg := ' rows deleted: 0 (partioned WLT_PRVDR entries for ' ||
                   in_wlt_prvdr_id || ' still exist)';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_ACTV_CD_MTHD' || v_msg);
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_ALGRTHM_VER' || v_msg);
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_CARDLET' || v_msg);
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_DVC_TYPE' || v_msg);
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_FPAN_SRC' || v_msg);
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_PARM' || v_msg);
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': WLT_PRVDR_CUST_MAP' || v_msg);
      END IF;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': COMPLETED');
   END;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ... ');
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_wlt_prvdr_id IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_wlt_prvdr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- now delete the wallet provider:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': in_wlt_prvdr_id = ' || in_wlt_prvdr_id
          || ', in_partn_num = ' || in_partn_num);
      SELECT COUNT(*) INTO v_count
        FROM WLT_PRVDR
        WHERE WLT_PRVDR_ID = in_wlt_prvdr_id
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM); 
      IF v_count > 0 THEN
          LPRC_WLT_PRVDR_DELETE;
      END IF;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': TOTAL ROWS deleted: '|| v_rows_deleted);
      COMMIT;
      out_rtn_msg := vc_proc_name || ': PARTN_NUM = ' || in_partn_num 
                     || ', WLT_PRVDR_ID="' || in_wlt_prvdr_id 
                     || '" completed!';                     
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
       WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN BAD_RETURN THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1003;
          ROLLBACK;

      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_wlt_prvdr_id
                        || ' failed, Oracle error = ' 
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_WLT_PRVDR_DELETE;
   PROCEDURE PRC_MBL_WLT_APPL_ADD (
                        in_base_mbl_wlt_id              IN  VARCHAR2,  --required
                        in_new_mbl_wlt_id               IN  VARCHAR2,  --required
                        in_new_mbl_wlt_name             IN  VARCHAR2,  --optional
                        in_new_wlt_prvdr_id             IN  NUMBER,    --optional
                        in_partn_num                    IN  NUMBER,    --optional
                        out_rtn_cd                      OUT NUMBER,
                        out_rtn_msg                     OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_MBL_WLT_APPL_ADD';
      v_active_partn_num              ACTV_PARTN.PARTN_NUM%TYPE;
      v_partn_num                     ACTV_PARTN.PARTN_NUM%TYPE;
      rec_mbl_wlt_appl                MBL_WLT_APPL%ROWTYPE;
      rec_mbl_wlt_appl_cpbl           MBL_WLT_APPL_CPBL%ROWTYPE;
      rec_mbl_wlt_appl_crdntl_mgr     MBL_WLT_APPL_CRDNTL_MGR%ROWTYPE;
      rec_mbl_wlt_appl_parm           MBL_WLT_APPL_PARM%ROWTYPE;
      rec_prtnr_host                  PRTNR_HOST%ROWTYPE;
      v_count                         NUMBER;
      REQUIRED_PARM_NULL              EXCEPTION;
      NOT_FOUND                       EXCEPTION;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ... ');
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';
      

      --------------------------------------------------------------------------
      -- get active partition:
      --------------------------------------------------------------------------
      SELECT partn_num INTO v_active_partn_num FROM ACTV_PARTN;
      IF in_partn_num IS NULL THEN
          v_partn_num := v_active_partn_num;
      ELSE
          v_partn_num := in_partn_num;
      END IF;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_active_partn_num: '|| v_active_partn_num);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': v_partn_num: '|| v_partn_num);

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_mbl_wlt_id IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_base_mbl_wlt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_mbl_wlt_id IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_new_mbl_wlt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      
      --------------------------------------------------------------------------
      -- make sure mobile wallet to be cloned exists:
      --------------------------------------------------------------------------
      SELECT COUNT(*) INTO v_count FROM MBL_WLT_APPL 
       WHERE PARTN_NUM = v_active_partn_num 
         AND MBL_WLT_ID = in_base_mbl_wlt_id;
      IF v_count = 0 THEN
          out_rtn_msg := vc_proc_name || ': v_active_partn_num=' || v_active_partn_num 
                         || ', in_base_mbl_wlt_id=' || in_base_mbl_wlt_id 
                         || ' not found in MBL_WLT_APPL!';
          RAISE NOT_FOUND;
      END IF;      

      --------------------------------------------------------------------------
      -- clone MBL_WLT_APPL (partioned):
      --------------------------------------------------------------------------
      SELECT * INTO rec_mbl_wlt_appl FROM MBL_WLT_APPL
       WHERE PARTN_NUM = v_active_partn_num 
         AND MBL_WLT_ID = in_base_mbl_wlt_id;
      rec_mbl_wlt_appl.PARTN_NUM := v_partn_num;
      rec_mbl_wlt_appl.MBL_WLT_ID := in_new_mbl_wlt_id;
      IF in_new_mbl_wlt_name IS NULL THEN
          rec_mbl_wlt_appl.MBL_WLT_NAM := rec_mbl_wlt_appl.MBL_WLT_NAM || ' CLONE';
      ELSE
          rec_mbl_wlt_appl.MBL_WLT_NAM := in_new_mbl_wlt_name;
      END IF;
      IF in_new_wlt_prvdr_id IS NULL THEN
          rec_mbl_wlt_appl.WLT_PRVDR_ID := rec_mbl_wlt_appl.WLT_PRVDR_ID;
      ELSE
          rec_mbl_wlt_appl.WLT_PRVDR_ID := in_new_wlt_prvdr_id;
      END IF;
      rec_mbl_wlt_appl.RPLCTN_UPDT_TS := SYSDATE;
      INSERT INTO MBL_WLT_APPL VALUES rec_mbl_wlt_appl;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': INSERTED INTO MBL_WLT_APPL');

      --------------------------------------------------------------------------
      -- clone MBL_WLT_APPL_CPBL (partioned):
      --------------------------------------------------------------------------
      FOR rec_mbl_wlt_appl_cpbl IN
          (SELECT * FROM MBL_WLT_APPL_CPBL
            WHERE PARTN_NUM = v_active_partn_num 
              AND MBL_WLT_ID = in_base_mbl_wlt_id)
      LOOP
          rec_mbl_wlt_appl_cpbl.PARTN_NUM := v_partn_num;
          rec_mbl_wlt_appl_cpbl.MBL_WLT_ID := in_new_mbl_wlt_id;
          rec_mbl_wlt_appl_cpbl.RPLCTN_UPDT_TS := SYSDATE;
          INSERT INTO MBL_WLT_APPL_CPBL VALUES rec_mbl_wlt_appl_cpbl;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': INSERTED INTO MBL_WLT_APPL_CPBL');
      END LOOP;

      --------------------------------------------------------------------------
      -- clone MBL_WLT_APPL_CRDNTL_MGR (not partioned):
      --------------------------------------------------------------------------
      FOR rec_mbl_wlt_appl_crdntl_mgr IN
          (SELECT * FROM MBL_WLT_APPL_CRDNTL_MGR
            WHERE MBL_WLT_ID = in_base_mbl_wlt_id)
      LOOP
          -- not partitioned so make sure not already added when cloned for a
          -- different partition:
          SELECT COUNT(*) INTO v_count FROM MBL_WLT_APPL_CRDNTL_MGR
            WHERE MBL_WLT_ID = in_new_mbl_wlt_id
              AND CRDNTL_MGR_ID = rec_mbl_wlt_appl_crdntl_mgr.CRDNTL_MGR_ID;
          IF v_count = 0 THEN
              rec_mbl_wlt_appl_crdntl_mgr.MBL_WLT_ID := in_new_mbl_wlt_id;
              rec_mbl_wlt_appl_crdntl_mgr.RPLCTN_UPDT_TS := SYSDATE;
              INSERT INTO MBL_WLT_APPL_CRDNTL_MGR VALUES rec_mbl_wlt_appl_crdntl_mgr;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': INSERTED INTO MBL_WLT_APPL_CRDNTL_MGR');
          END IF;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone MBL_WLT_APPL_PARM (not partioned):
      --------------------------------------------------------------------------
      FOR rec_mbl_wlt_appl_parm IN
          (SELECT * FROM MBL_WLT_APPL_PARM
            WHERE MBL_WLT_ID = in_base_mbl_wlt_id)
      LOOP
          -- not partitioned so make sure not already added when cloned for a
          -- different partition:
          SELECT COUNT(*) INTO v_count FROM MBL_WLT_APPL_PARM
            WHERE MBL_WLT_ID = in_new_mbl_wlt_id
              AND PARM_NAM = rec_mbl_wlt_appl_parm.PARM_NAM;
          IF v_count = 0 THEN
              rec_mbl_wlt_appl_parm.MBL_WLT_APPL_PARM_ID := MBL_WLT_APPL_PARM_ID_SEQ.NEXTVAL;
              rec_mbl_wlt_appl_parm.MBL_WLT_ID := in_new_mbl_wlt_id;
              rec_mbl_wlt_appl_parm.RPLCTN_UPDT_TS := SYSDATE;
              INSERT INTO MBL_WLT_APPL_PARM VALUES rec_mbl_wlt_appl_parm;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': INSERTED INTO MBL_WLT_APPL_PARM');
          END IF;
      END LOOP;

      --------------------------------------------------------------------------
      -- clone PRTNR_HOST (not partioned):
      --------------------------------------------------------------------------
      FOR rec_prtnr_host IN
          (SELECT * FROM prtnr_host
            WHERE PRTNR_ID = in_base_mbl_wlt_id)
      LOOP
          -- not partitioned so make sure not already added when cloned for a
          -- different partition:
          SELECT COUNT(*) INTO v_count FROM prtnr_host
            WHERE PRTNR_ID = in_new_mbl_wlt_id
              AND PRTNR_TYPE_CD = rec_prtnr_host.PRTNR_TYPE_CD
              AND HOST_PATH_TXT = rec_prtnr_host.HOST_PATH_TXT;
          IF v_count = 0 THEN
              rec_prtnr_host.PRTNR_ID := in_new_mbl_wlt_id;
              rec_prtnr_host.RPLCTN_UPDT_TS := SYSDATE;
              INSERT INTO prtnr_host VALUES rec_prtnr_host;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': INSERTED INTO prtnr_host');
          END IF;
      END LOOP;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': PARTN_NUM=' || v_partn_num || 
                     ', MBL_WLT_ID="' || in_new_mbl_wlt_id || 
                     '", MBL_WLT_NAM="' || in_new_mbl_wlt_name || 
                     '" completed!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;
      WHEN NOT_FOUND THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;
      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_mbl_wlt_id ||
            ' failed, Oracle error = ' || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
   END PRC_MBL_WLT_APPL_ADD;
   PROCEDURE PRC_MBL_WLT_APPL_CLONE (
                     in_base_mbl_wlt_id           IN  VARCHAR2,   --required
                     in_new_mbl_wlt_id            IN  VARCHAR2,   --required
                     in_new_mbl_wlt_name          IN  VARCHAR2,   --optional
                     in_new_wlt_prvdr_id          IN  NUMBER,     --optional
                     in_new_partn_num             IN  NUMBER,     --optional
                     out_rtn_cd                   OUT NUMBER,
                     out_rtn_msg                  OUT VARCHAR2)

   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_MBL_WLT_APPL_CLONE';
      REQUIRED_PARM_NULL              EXCEPTION;
      BAD_RETURN                      EXCEPTION;

   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ... ');
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_base_mbl_wlt_id IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_base_mbl_wlt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_mbl_wlt_id IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_new_mbl_wlt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
          
      --------------------------------------------------------------------------
      -- clone account range by calling other procedures:
      --------------------------------------------------------------------------
      PRC_MBL_WLT_APPL_DELETE(in_new_mbl_wlt_id, 
                              in_new_partn_num,
                              out_rtn_cd,
                              out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       
                          
      PRC_MBL_WLT_APPL_ADD(in_base_mbl_wlt_id,
                           in_new_mbl_wlt_id,
                           in_new_mbl_wlt_name,
                           in_new_wlt_prvdr_id,
                           in_new_partn_num,
                           out_rtn_cd,
                           out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': PARTN_NUM=' || in_new_partn_num || 
                     ', MBL_WLT_ID="' || in_new_mbl_wlt_id || 
                     '", MBL_WLT_NAM="' || in_new_mbl_wlt_name || 
                     '" completed!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;
      WHEN BAD_RETURN THEN
          ROLLBACK;
      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_mbl_wlt_id
                        || in_new_partn_num || ' failed, Oracle error = '
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_MBL_WLT_APPL_CLONE;
   PROCEDURE PRC_MBL_WLT_APPL_DELETE (
                        in_mbl_wlt_id                   IN  VARCHAR,  --required
                        in_partn_num                    IN  NUMBER,   --optional
                        out_rtn_cd                      OUT NUMBER,
                        out_rtn_msg                     OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_MBL_WLT_APPL_DELETE';
      vc_local_proc_name              VARCHAR2 (50);
      v_partn_num                     ACTV_PARTN.PARTN_NUM%TYPE;
      v_count                         NUMBER;
      v_rows_deleted                  NUMBER := 0;    
      v_msg                           VARCHAR2(1000);
      REQUIRED_PARM_NULL              EXCEPTION;


   PROCEDURE LPRC_MBL_WLT_APPL_DELETE IS
   BEGIN

      vc_local_proc_name := 'LPRC_MBL_WLT_APPL_DELETE';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': STARTING ...');

      --------------------------------------------------------------------------
      -- first delete all the account range data associated with the mobile
      -- wallet application to be deleted:
      --------------------------------------------------------------------------
      PRVT_DELETE_ACCT_RNG_MWA_DATA(NULL, in_partn_num, in_mbl_wlt_id); 
      
      --------------------------------------------------------------------------
      -- deleted partioned MBL_WLT_APPL children first:
      --------------------------------------------------------------------------
      DELETE FROM MBL_WLT_APPL_CPBL
       WHERE MBL_WLT_ID = in_mbl_wlt_id
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': MBL_WLT_APPL_CPBL rows deleted: '|| SQL%ROWCOUNT);
      v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;
 
      --------------------------------------------------------------------------
      -- now deleted partioned MBL_WLT_APPL:
      --------------------------------------------------------------------------
      DELETE FROM MBL_WLT_APPL
       WHERE MBL_WLT_ID = in_mbl_wlt_id
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': MBL_WLT_APPL rows deleted: '|| SQL%ROWCOUNT);
      v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

      --------------------------------------------------------------------------
      -- and finally delete non-partioned MBL_WLT_APPL children only if no more 
      -- partioned MBL_WLT_APPL rows exist:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': CHECKING NON-PARTIONED TABLES ...');
      SELECT COUNT(*) INTO v_count
        FROM MBL_WLT_APPL
       WHERE MBL_WLT_ID = in_mbl_wlt_id;

      IF v_count = 0 THEN

          --MBL_WLT_APPL_CRDNTL_MGR:
          DELETE FROM MBL_WLT_APPL_CRDNTL_MGR
           WHERE MBL_WLT_ID = in_mbl_wlt_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': MBL_WLT_APPL_CRDNTL_MGR rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

          --MBL_WLT_APPL_PARM:
          DELETE FROM MBL_WLT_APPL_PARM
           WHERE MBL_WLT_ID = in_mbl_wlt_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': MBL_WLT_APPL_PARM rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

          --PRTNR_HOST:
          DELETE FROM PRTNR_HOST
           WHERE PRTNR_ID = in_mbl_wlt_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': PRTNR_HOST rows deleted: '
                                         || SQL%ROWCOUNT);
          v_rows_deleted := SQL%ROWCOUNT + v_rows_deleted;

      ELSE
          v_msg := ' rows deleted: 0 (partioned MBL_WLT_APPL entries for "' ||
                   in_mbl_wlt_id || '" still exist)';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': MBL_WLT_APPL_CRDNTL_MGR' || v_msg);
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': MBL_WLT_APPL_PARM' || v_msg);
      END IF;
      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': COMPLETED');
   END; 

   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ... ');
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';


      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DEBUG 001 ... ');

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_mbl_wlt_id IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_mbl_wlt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      
      --------------------------------------------------------------------------
      -- now delete the mobile wallet application:
      --------------------------------------------------------------------------
      SELECT COUNT(*) INTO v_count
        FROM MBL_WLT_APPL
        WHERE MBL_WLT_ID = in_mbl_wlt_id
         AND PARTN_NUM = NVL(in_partn_num, PARTN_NUM); 
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DEBUG 002 ... ');
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DEBUG CALLING LPRC_MBL_WLT_APPL_DELETE ... ');
      IF v_count > 0 THEN
          LPRC_MBL_WLT_APPL_DELETE;
      END IF;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': TOTAL ROWS deleted: '|| v_rows_deleted);
      COMMIT;
      out_rtn_msg := vc_proc_name || ': PARTN_NUM = ' || in_partn_num 
                     || ', MBL_WLT_ID="' || in_mbl_wlt_id 
                     || '" completed!';                     
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
       WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;
      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_mbl_wlt_id
                        || ' failed, Oracle error = ' 
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_MBL_WLT_APPL_DELETE;
   PROCEDURE PRC_DELETE_TOKEN (
                 in_map_id                     IN  NUMBER,   --required
                 in_dpan                       IN  VARCHAR2, --optional                        
                 out_rtn_cd                    OUT NUMBER,
                 out_rtn_msg                   OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_DELETE_TOKEN';
      v_msg                           VARCHAR2(1000);
      v_dvc_pan_data_enc_id           PAN_DVC_MAP.DVC_PAN_DATA_ENC_ID%TYPE;
      v_fund_pan_data_enc_id          PAN_DVC_MAP.FUND_PAN_DATA_ENC_ID%TYPE;
      v_extrl_tsp_sw                  PAN_DVC_MAP.EXTRL_TSP_SW%TYPE;
      v_dvc_notif_id                  DVC_NOTIF.dvc_notif_id%TYPE;
      v_dpan_strt                     DPAN_ACCT_RNG.rng_strt_num%TYPE;
      v_dpan_end                      DPAN_ACCT_RNG.RNG_END_NUM%TYPE;
      v_fpan_strt                     DPAN_ACCT_RNG.fpan_rng_strt_num%TYPE;
      v_wlt_prvdr_id                  PAN_DVC_MAP.WLT_PRVDR_ID%TYPE;
      v_paymt_appl_instance_id        PAN_DVC_MAP.PAYMT_APPL_INSTNCE_ID%TYPE;
      REQUIRED_PARM_NULL              EXCEPTION;     
      NOT_FOUND                       EXCEPTION;
      
      
      PROCEDURE LPRC_DPAN_CLEANUP (
          in_dpan                     IN  VARCHAR2)
      IS
          v_cnt_recycle               NUMBER;
          v_len_dpan                  NUMBER;
          v_msg                       VARCHAR2(1000);
          NOT_FOUND                   EXCEPTION;
      BEGIN
          v_msg := vc_proc_name || ': starting LPRC_DPAN_CLEANUP';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          v_msg := vc_proc_name || ': processing in_dpan = ' || in_dpan;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

          ----------------------------------------------------------------------
          -- retrieve DPAN's account range data:
          ----------------------------------------------------------------------
          v_msg := vc_proc_name || ': retrieving DPAN_ACCT_RNG data';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          SELECT DISTINCT RNG_STRT_NUM, RNG_END_NUM, FPAN_RNG_STRT_NUM
            INTO v_dpan_strt, v_dpan_end, v_fpan_strt
            FROM DPAN_ACCT_RNG_VW
           WHERE RPAD(in_dpan,19,0) BETWEEN rng_strt_num AND rng_end_num;
          v_msg := vc_proc_name || ': DPAN_ACCT_RNG data retrieved';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

          ----------------------------------------------------------------------
          -- determine if DPAN has been previously recycled:
          ----------------------------------------------------------------------
          v_msg := vc_proc_name || ': retrieving SITE_DPAN_RECYCLE count';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          SELECT COUNT (*)
            INTO v_cnt_recycle                                          
            FROM SITE_DPAN_RECYCLE
           WHERE DVC_PAN = in_dpan;
          v_msg := vc_proc_name || ': v_cnt_recycle count = ' || v_cnt_recycle;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
 
          ----------------------------------------------------------------------
          -- recycle DPAN (if not already recycled):
          ----------------------------------------------------------------------
          IF v_cnt_recycle = 0 THEN
              v_msg := vc_proc_name || ': inserting SITE_DPAN_RECYCLE data';
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
              v_len_dpan := LENGTH (in_dpan);
              INSERT INTO SITE_DPAN_RECYCLE (
                   CNSM_SITE_CD, CREATE_TIMESTAMP, DPAN_RNG_STRT_NUM,
                   DVC_PAN, DVC_PAN_LEN_NUM, ORIG_SITE_CD, POOL_ID)
                    VALUES ('1', SYSDATE, v_dpan_strt,
                            in_dpan, v_len_dpan, NULL, NULL);
              v_msg := vc_proc_name || ': SITE_DPAN_RECYCLE data inserted';
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          ELSE
              v_msg := vc_proc_name || ': DPAN already recycled!';
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          END IF;

          ----------------------------------------------------------------------
          -- and now remove any AMS mock entries associated with DPAN:
          ----------------------------------------------------------------------
          DELETE FROM AMS_MCK_ALT_PYMNT_CRDNTL
               WHERE dvc_pan = in_dpan;
          v_msg := vc_proc_name || ': AMS_MCK_ALT_PYMNT_CRDNTL rows deleted: '|| SQL%ROWCOUNT;            
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

          DELETE FROM AMS_MOCK_EVENT
               WHERE dvc_pan = in_dpan;
          v_msg := vc_proc_name || ': AMS_MOCK_EVENT rows deleted: '|| SQL%ROWCOUNT;            
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

          DELETE FROM AMS_MCK_MAP
               WHERE dvc_pan = in_dpan;
          v_msg := vc_proc_name || ': AMS_MCK_MAP rows deleted: '|| SQL%ROWCOUNT;            
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

          v_msg := vc_proc_name || ': completed LPRC_DPAN_CLEANUP';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
      END;
      
      PROCEDURE LPRC_DVC_CLEANUP (
          in_dvc_notif_id                   IN  NUMBER,
          in_paymt_appl_instnce_id          IN  VARCHAR2,
          in_wlt_prvdr_id                   IN  NUMBER)
      IS
          v_cnt_dvc_notif                   NUMBER;
          v_cnt_dvc_from_dvc_notif          NUMBER;
          v_cnt_dvc_from_pan_dvc_map        NUMBER;
          v_msg                             VARCHAR2(1000);
      BEGIN
          v_msg := vc_proc_name || ': starting LPRC_DVC_CLEANUP';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          v_msg := vc_proc_name || ': processing DVC_NOTIF_ID=' || in_dvc_notif_id
              || ', in_paymt_appl_instnce_id=' || in_paymt_appl_instnce_id
              || ', in_wlt_prvdr_id=' || in_wlt_prvdr_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
      
          ----------------------------------------------------------------------
          -- delete DVC_NOTIF if no other tokens are associated with it:
          ----------------------------------------------------------------------
          v_msg := vc_proc_name || ': retrieving PAN_DVC_MAP_DVC_NOTIF count for '
                   || 'in_dvc_notif_id = ' || in_dvc_notif_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          SELECT COUNT (*)
            INTO v_cnt_dvc_notif
            FROM PAN_DVC_MAP_DVC_NOTIF
           WHERE dvc_notif_id = in_dvc_notif_id;
          v_msg := vc_proc_name || ': v_cnt_dvc_notif count = ' || v_cnt_dvc_notif;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

          IF v_cnt_dvc_notif = 0 THEN
             DELETE FROM DVC_NOTIF
                   WHERE PAYMT_APPL_INSTNCE_ID = in_paymt_appl_instnce_id
                     AND WLT_PRVDR_ID = in_wlt_prvdr_id;
              v_msg := vc_proc_name || ': DVC_NOTIF rows deleted: '|| SQL%ROWCOUNT;            
             PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          ELSE
              v_msg := vc_proc_name || ': DVC_NOTIF not deleted!';
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          END IF;

          ----------------------------------------------------------------------
          -- now delete DVC if it has no more children (DVC_NOTIF/PAv_DVC_MAP):
          ----------------------------------------------------------------------
          v_msg := vc_proc_name || ': retrieving DVC_NOTIF count';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          SELECT COUNT (*)
            INTO v_cnt_dvc_from_dvc_notif
            FROM DVC_NOTIF
           WHERE PAYMT_APPL_INSTNCE_ID = in_paymt_appl_instnce_id
             AND WLT_PRVDR_ID = in_wlt_prvdr_id;
          v_msg := vc_proc_name || ': v_cnt_dvc_from_dvc_notif = ' || v_cnt_dvc_from_dvc_notif;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

          v_msg := vc_proc_name || ': retrieving PAN_DVC_MAP count';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          SELECT COUNT (*)
            INTO v_cnt_dvc_from_pan_dvc_map
            FROM PAN_DVC_MAP
           WHERE PAYMT_APPL_INSTNCE_ID = in_paymt_appl_instnce_id
            AND WLT_PRVDR_ID = in_wlt_prvdr_id;
          v_msg := vc_proc_name || ': v_cnt_dvc_from_pan_dvc_map = ' || v_cnt_dvc_from_pan_dvc_map;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

          IF v_cnt_dvc_from_dvc_notif = 0 AND v_cnt_dvc_from_pan_dvc_map = 0 THEN
          
              DELETE FROM API_ACTVTY
               WHERE PAYMT_APPL_INSTNCE_ID = in_paymt_appl_instnce_id
                 AND WLT_PRVDR_ID = in_wlt_prvdr_id;
              v_msg := vc_proc_name || ': API_ACTVTY rows deleted: '|| SQL%ROWCOUNT;            
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);                

              DELETE FROM DVC_ID_MAP
               WHERE PAYMT_APPL_INSTNCE_ID = in_paymt_appl_instnce_id
                 AND WLT_PRVDR_ID = in_wlt_prvdr_id;
              v_msg := vc_proc_name || ': DVC_ID_MAP rows deleted: '|| SQL%ROWCOUNT;            
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);                

              DELETE FROM DVC
               WHERE PAYMT_APPL_INSTNCE_ID = in_paymt_appl_instnce_id
                 AND WLT_PRVDR_ID = in_wlt_prvdr_id;
              v_msg := vc_proc_name || ': DVC rows deleted: '|| SQL%ROWCOUNT;            
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);                
          ELSE
              v_msg := vc_proc_name || ': DVC data not deleted';
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

              v_msg := vc_proc_name || ': ' || v_cnt_dvc_from_dvc_notif
                       || ' DVC_NOTIF rows still exist for '
                       || 'PAYMT_APPL_INSTNCE_ID = ' || in_paymt_appl_instnce_id
                       || ', WLT_PRVDR_ID = ' || in_wlt_prvdr_id;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          
              v_msg := vc_proc_name || ': ' || v_cnt_dvc_from_dvc_notif 
                       || ' PAN_DVC_MAP rows still exist for '
                       || 'PAYMT_APPL_INSTNCE_ID = ' || in_paymt_appl_instnce_id
                       || ', WLT_PRVDR_ID = ' || in_wlt_prvdr_id;
              PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
 
          END IF;
          v_msg := vc_proc_name || ': completed LPRC_DVC_CLEANUP';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
      END;
      
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ...');
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_map_id IS NULL THEN
          out_rtn_msg := vc_proc_name || 'in_map_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      --from SOAPU ... passing null value instead of 'NULL' so commenting
      --out for now:
--      IF in_dpan IS NULL THEN
--          out_rtn_msg := vc_proc_name || 'in_dpan cannot be null!';
--          RAISE REQUIRED_PARM_NULL;
--      END IF;
           
     --------------------------------------------------------------------------
      -- retrieve key data(keys to other tables) from PAN_DVC_MAP:
      --------------------------------------------------------------------------
      BEGIN
          v_msg := vc_proc_name || ': processing MAP_ID = ' || in_map_id 
                   || ', DPAN = ' || in_dpan;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
        
          v_msg := vc_proc_name || ': retrieving PAN_DVC_MAP data';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          SELECT DVC_PAN_DATA_ENC_ID,
                 FUND_PAN_DATA_ENC_ID,
                 WLT_PRVDR_ID,
                 PAYMT_APPL_INSTNCE_ID,
                 EXTRL_TSP_SW
            INTO v_dvc_pan_data_enc_id,
                 v_fund_pan_data_enc_id,
                 v_wlt_prvdr_id,
                 v_paymt_appl_instance_id,
                 v_extrl_tsp_sw
            FROM PAN_DVC_MAP
           WHERE map_id = in_map_id;
          v_msg := vc_proc_name || ': PAN_DVC_MAP data retrieved';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          v_msg := vc_proc_name 
              || ': v_dvc_pan_data_enc_id = ' || v_dvc_pan_data_enc_id
              || ',v_fund_pan_data_enc_id = ' || v_fund_pan_data_enc_id
              || ',v_wlt_prvdr_id = ' || v_wlt_prvdr_id
              || ',v_paymt_appl_instance_id = ' || v_paymt_appl_instance_id
              || ',v_extrl_tsp_sw = ' || v_extrl_tsp_sw;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
              out_rtn_msg := ': no PAN_DVC_MAP found for MAP_ID = '
                       || in_map_id;
              RAISE NOT_FOUND;
      END;

      --------------------------------------------------------------------------
      -- retrieve/save DVC_NOTIF_ID:
      --------------------------------------------------------------------------
      v_msg := vc_proc_name || ': retrieving PAN_DVC_MAP_DVC_NOTIF.DVC_NOTIF_ID';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
      BEGIN
         SELECT DVC_NOTIF_ID
           INTO v_dvc_notif_id
           FROM PAN_DVC_MAP_DVC_NOTIF
          WHERE map_id = in_map_id;
          v_msg := vc_proc_name || ': DVC_NOTIF_ID retrieved';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
         EXCEPTION
             WHEN NO_DATA_FOUND THEN
             v_dvc_notif_id := 0;
      END;
      v_msg := vc_proc_name || ': n_dvc_notif_id = ' || v_dvc_notif_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      --------------------------------------------------------------------------
      -- delete PAN_DVC_MAP "grandchildern":
      --------------------------------------------------------------------------
      DELETE FROM SCHED_RETRY_TASK
            WHERE PRVSN_RQST_ID IN (
                      SELECT PRVSN_RQST_ID
                        FROM PRVSN_RQST
                       WHERE MAP_ID = in_map_id);
      v_msg := vc_proc_name || ': SCHED_RETRY_TASK rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);                

      DELETE FROM SYNC_CHNG
            WHERE PRVSN_RQST_ID IN (
                      SELECT PRVSN_RQST_ID
                        FROM PRVSN_RQST
                       WHERE MAP_ID = in_map_id);
      v_msg := vc_proc_name || ': SYNC_CHNG rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);                

      --------------------------------------------------------------------------
      -- delete PAN_DVC_MAP childern":
      --------------------------------------------------------------------------
      DELETE FROM CARD_MASTER_KEY
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': CARD_MASTER_KEY rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM PAN_DVC_MAP_SPND
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': PAN_DVC_MAP_SPND rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM PAN_DVC_MAP_ISSR_ACTN
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': PAN_DVC_MAP_ISSR_ACTN rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM API_ACTVTY
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': API_ACTVTY rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM CUST_SERV_CMNT
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': CUST_SERV_CMNT rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM PAN_DVC_MAP_ACTVTY
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': PAN_DVC_MAP_ACTVTY rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM PAN_MAP_RESP_HOST
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': PAN_MAP_RESP_HOST rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM PAN_DVC_MAP_ACTV_CD_MTHD
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': PAN_DVC_MAP_ACTV_CD_MTHD rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM PAN_DVC_MAP_DVC_NOTIF
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': PAN_DVC_MAP_DVC_NOTIF rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM PAN_DVC_MAP_PAR
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': PAN_DVC_MAP_PAR rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM PAN_DVC_MAP_PERSO
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': PAN_DVC_MAP_PERSO rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM PRVSN_RQST
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': PRVSN_RQST rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM REDIG_NOTIF_TOKEN
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': REDIG_NOTIF_TOKEN rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      -- RESRV_DPAN: believe stage3 is the only environment that has data ...
      DELETE FROM RESRV_DPAN
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': RESRV_DPAN rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM TRAN
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': TRAN rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM TOKEN_RQSTR_DEL
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': TOKEN_RQSTR_DEL rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      --------------------------------------------------------------------------
      -- delete PAN_DVC_MAP and other associated data:
      --------------------------------------------------------------------------
      DELETE FROM PAN_DVC_MAP
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': PAN_DVC_MAP rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM PAN_DVC_MAP_AUD
            WHERE MAP_ID = in_map_id;
      v_msg := vc_proc_name || ': PAN_DVC_MAP_AUD rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM PAN_DATA_ENC
            WHERE PAN_DATA_ENC_ID = v_dvc_pan_data_enc_id;
      v_msg := vc_proc_name || ': PAN_DATA_ENC rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      DELETE FROM PAN_DATA_ENC
            WHERE PAN_DATA_ENC_ID = v_fund_pan_data_enc_id;
      v_msg := vc_proc_name || ': PAN_DATA_ENC rows deleted: '|| SQL%ROWCOUNT;            
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      --------------------------------------------------------------------------
      -- DPAN cleanup:
      --------------------------------------------------------------------------
      --from SOAPU ... passing null value instead of 'NULL' so commenting
      --out for now:
      IF v_extrl_tsp_sw = 'N' AND in_dpan IS NOT NULL AND in_dpan <> 'NULL' THEN
          LPRC_DPAN_CLEANUP(in_dpan);
      END IF;

      --------------------------------------------------------------------------
      -- DVC_NOTIF cleanup:
      --------------------------------------------------------------------------
      LPRC_DVC_CLEANUP(v_dvc_notif_id,
                       v_paymt_appl_instance_id,
                       v_wlt_prvdr_id);

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': MAP_ID = ' || in_map_id || ', DPAN = ' 
                     || in_dpan || ' successfully deleted!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

      EXCEPTION
          WHEN NOT_FOUND THEN
              PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
              out_rtn_cd := -1002;
              ROLLBACK;
          
          WHEN REQUIRED_PARM_NULL THEN
              PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
              out_rtn_cd := -1001;
              ROLLBACK;
      
          WHEN OTHERS THEN
              ROLLBACK;
              out_rtn_cd := -1001;
              out_rtn_msg := vc_proc_name || ' Failed with Oracle error= '
                     || SUBSTR (SQLERRM, 1, 150);

                     
   END PRC_DELETE_TOKEN;
   PROCEDURE PRC_APPL_USER_CLONE (
                    in_base_clnt_appl_id            IN VARCHAR2, --required
                    in_new_clnt_appl_id             IN VARCHAR2, --required
                    in_base_token_rqstr_id          IN NUMBER,   --required
                    in_new_token_rqstr_id           IN NUMBER,   --required
                    in_new_wlt_prvdr_id             IN NUMBER,   --optional
                    in_new_sys_user_id              IN VARCHAR2, --optional
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2 (50) := 'PRC_APPL_USER_CLONE';
      REQUIRED_PARM_NULL              EXCEPTION;
      BAD_RETURN                      EXCEPTION;


   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
       IF in_base_clnt_appl_id IS NULL THEN
          out_rtn_msg := 'in_base_clnt_appl_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_clnt_appl_id IS NULL THEN
          out_rtn_msg := 'in_new_clnt_appl_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
       IF in_base_token_rqstr_id IS NULL THEN
          out_rtn_msg := 'in_base_token_rqstr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_token_rqstr_id IS NULL THEN
          out_rtn_msg := 'in_new_token_rqstr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
          
      --------------------------------------------------------------------------
      -- clone account range by calling other procedures:
      --------------------------------------------------------------------------
      PRC_APPL_USER_DELETE(in_new_clnt_appl_id, 
                           in_new_token_rqstr_id,
                           out_rtn_cd,
                           out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       
                          
      PRC_APPL_USER_ADD(in_base_clnt_appl_id,
                        in_new_clnt_appl_id,
                        in_base_token_rqstr_id,
                        in_new_token_rqstr_id,
                        in_new_wlt_prvdr_id,
                        in_new_sys_user_id,
                        out_rtn_cd,
                        out_rtn_msg);
      IF out_rtn_cd <> 0 THEN
          RAISE BAD_RETURN;
      END IF;                       

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_new_clnt_appl_id  || ', '
                     || in_new_token_rqstr_id || ' successfully cloned!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN BAD_RETURN THEN
          ROLLBACK;

      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_clnt_appl_id || ', ' 
                        || in_new_token_rqstr_id || ' not cloned, Oracle error = '
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_APPL_USER_CLONE;
   PROCEDURE PRC_APPL_USER_ADD (
                    in_base_clnt_appl_id            IN VARCHAR2, --required
                    in_new_clnt_appl_id             IN VARCHAR2, --required
                    in_base_token_rqstr_id          IN NUMBER,   --required
                    in_new_token_rqstr_id           IN NUMBER,   --required
                    in_new_wlt_prvdr_id             IN NUMBER,   --optional
                    in_new_sys_user_id              IN VARCHAR2, --optional
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2(50) := 'PRC_APPL_USER_ADD';
      rec_appl_user                   APPL_USER%ROWTYPE;
      v_count                         NUMBER;
      INVALID_CONFIG_UUID             EXCEPTION;
      REQUIRED_PARM_NULL              EXCEPTION;
      NOT_FOUND                       EXCEPTION;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
       IF in_base_clnt_appl_id IS NULL THEN
          out_rtn_msg := 'in_base_clnt_appl_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_clnt_appl_id IS NULL THEN
          out_rtn_msg := 'in_new_clnt_appl_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
       IF in_base_token_rqstr_id IS NULL THEN
          out_rtn_msg := 'in_base_token_rqstr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_new_token_rqstr_id IS NULL THEN
          out_rtn_msg := 'in_new_token_rqstr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- make sure appl_user row to be cloned exists:
      --------------------------------------------------------------------------
      SELECT COUNT(*) INTO v_count FROM APPL_USER
       WHERE CLNT_APPL_ID = in_base_clnt_appl_id
         AND TOKEN_RQSTR_ID = in_base_token_rqstr_id;
      IF v_count = 0 THEN
          out_rtn_msg := 'in_base_clnt_appl_id=' || in_base_clnt_appl_id || ', '
                         || 'in_base_token_rqstr_id=' || in_base_token_rqstr_id
                         || ' not found in APPL_USER!';
          RAISE NOT_FOUND;
      END IF;      

      --------------------------------------------------------------------------
      -- clone APPL_USER:
      --------------------------------------------------------------------------
      SELECT *
        INTO rec_appl_user
        FROM APPL_USER
       WHERE CLNT_APPL_ID = in_base_clnt_appl_id
         AND TOKEN_RQSTR_ID = in_base_token_rqstr_id;

      rec_appl_user.CLNT_APPL_ID := in_new_clnt_appl_id;
      rec_appl_user.TOKEN_RQSTR_ID := in_new_token_rqstr_id;
      IF in_new_wlt_prvdr_id IS NOT NULL THEN
          rec_appl_user.WLT_PRVDR_ID := in_new_wlt_prvdr_id;
      END IF;
      IF in_new_sys_user_id IS NOT NULL THEN
          rec_appl_user.SYS_USER_ID := in_new_sys_user_id;
      END IF;
      rec_appl_user.RPLCTN_UPDT_TS := SYSDATE;
      rec_appl_user.USER_ID := USER_ID_SEQ.NEXTVAL;

      INSERT INTO APPL_USER
           VALUES rec_appl_user;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_new_clnt_appl_id  || ', '
                     || in_new_token_rqstr_id || ' successfully added!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN NOT_FOUND THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;
 
      WHEN INVALID_CONFIG_UUID THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1004;
          ROLLBACK;

      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_new_clnt_appl_id || ', ' 
                        || in_new_token_rqstr_id || ' not added, Oracle error = '
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_APPL_USER_ADD;
   PROCEDURE PRC_APPL_USER_DELETE (
                    in_clnt_appl_id                 IN VARCHAR2, --required
                    in_token_rqstr_id               IN NUMBER,   --required
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2(50) := 'PRC_APPL_USER_DELETE';
      rows_deleted                    NUMBER := 0;
      REQUIRED_PARM_NULL              EXCEPTION;

   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
       IF in_clnt_appl_id IS NULL THEN
          out_rtn_msg := 'in_clnt_appl_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
       IF in_token_rqstr_id IS NULL THEN
          out_rtn_msg := 'in_token_rqstr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- delete APPL_USER:
      --------------------------------------------------------------------------
      DELETE FROM APPL_USER
       WHERE CLNT_APPL_ID = in_clnt_appl_id
         AND TOKEN_RQSTR_ID = in_token_rqstr_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('APPL_USER rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOTAL ROWS deleted: '|| rows_deleted);
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_clnt_appl_id  || ', '
                     || in_token_rqstr_id || ' successfully deleted!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_clnt_appl_id || ', ' 
                        || in_token_rqstr_id || ' not deleted, Oracle error = '
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_APPL_USER_DELETE;              
   PROCEDURE PRC_DELETE_TOKEN_BY_FPAN_RNG (
                 in_fpan_rng_strt_num          IN  NUMBER,   --required
                 out_rtn_cd                    OUT NUMBER,
                 out_rtn_msg                   OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2(50) := 'PRC_DELETE_TOKEN_BY_FPAN_RNG';
      v_cnt_fpan_acct_rng             NUMBER;
      v_rows_deleted                  NUMBER;
      v_count                         NUMBER;
      v_fpan_rng_strt_num             FPAN_ACCT_RNG.RNG_STRT_NUM%TYPE;
      v_fpan_rng_end_num              FPAN_ACCT_RNG.RNG_END_NUM%TYPE;
      rec_pan_dvc_map                 PAN_DVC_MAP%ROWTYPE;   
      rec_ams_mck_map                 AMS_MCK_MAP%ROWTYPE;   
      v_msg                           VARCHAR2(1000);
      REQUIRED_PARM_NULL              EXCEPTION;
      NOT_FOUND                       EXCEPTION;
      BAD_RETURN                      EXCEPTION;

   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ...');
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_fpan_rng_strt_num IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_fpan_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- reformat range into 19 digit value:
      --------------------------------------------------------------------------
      v_fpan_rng_strt_num := RPAD(in_fpan_rng_strt_num, 19, '0');
      v_fpan_rng_end_num  := RPAD(in_fpan_rng_strt_num, 19, '9');
      v_msg := vc_proc_name || ': v_fpan_rng_strt_num = ' || v_fpan_rng_strt_num
        || ', v_fpan_rng_end_num = ' || v_fpan_rng_end_num;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      --------------------------------------------------------------------------
      -- delete mappings associated with input range:
      --------------------------------------------------------------------------
      v_msg := vc_proc_name || ': retrieving PAN_DVC_MAP rows';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
      FOR rec_pan_dvc_map IN
          (SELECT *
             FROM PAN_DVC_MAP
            WHERE FPAN_RNG_STRT_NUM = v_fpan_rng_strt_num)
      LOOP
          v_msg := vc_proc_name || ': PAN_DVC_MAP.MAP_ID = ' || 
                   rec_pan_dvc_map.MAP_ID;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          PRC_DELETE_TOKEN(rec_pan_dvc_map.MAP_ID, 
                           'NULL',
                           out_rtn_cd,
                           out_rtn_msg);
          IF out_rtn_cd <> 0 THEN
              RAISE BAD_RETURN;
          END IF;                   
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(' ');
      END LOOP;

      --------------------------------------------------------------------------
      -- delete ams mock data associated with input range:
      --------------------------------------------------------------------------
      v_msg := vc_proc_name || ': retrieving AMS_MCK_MAP rows';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
      FOR rec_ams_mck_map IN
          (SELECT *
             FROM AMS_MCK_MAP
            WHERE RPAD(FUND_PAN,19,'0') >= v_fpan_rng_strt_num
              AND RPAD(FUND_PAN,19,'0') <= v_fpan_rng_end_num)
      LOOP
          v_msg := vc_proc_name || ': AMS_MCK_MAP.FUND_PAN = ' || 
                   rec_ams_mck_map.FUND_PAN || ', AMS_MCK_MAP.DVC_PAN = ' ||
                   rec_ams_mck_map.DVC_PAN;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          
          DELETE FROM AMS_MOCK_EVENT
                WHERE DVC_PAN = rec_ams_mck_map.DVC_PAN;
          v_msg := vc_proc_name || ': AMS_MOCK_EVENT rows deleted: '|| SQL%ROWCOUNT;            
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
               
          DELETE FROM AMS_MCK_MAP
                WHERE DVC_PAN = rec_ams_mck_map.DVC_PAN;
          v_msg := vc_proc_name || ': AMS_MCK_MAP rows deleted: '|| SQL%ROWCOUNT;            
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          
      END LOOP;
      
      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      out_rtn_msg := vc_proc_name || ': for ' || in_fpan_rng_strt_num 
                    || ' completed succeessfully!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(out_rtn_msg);
      COMMIT;

   EXCEPTION
   
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;
   
      WHEN NOT_FOUND THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1002;
          ROLLBACK;
   
      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1000;
         out_rtn_msg := vc_proc_name || ': ' || in_fpan_rng_strt_num
                        || ' failed, Oracle error = ' 
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG(out_rtn_msg);
     
   END PRC_DELETE_TOKEN_BY_FPAN_RNG;
   PROCEDURE PRC_DELETE_DPAN_POOL_DATA (
                 in_fpan_rng_strt_num    IN  NUMBER,   --required
                 out_rtn_cd              OUT NUMBER,
                 out_rtn_msg             OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2(50) := 'PRC_DELETE_DPAN_POOL_DATA';
      v_count                         NUMBER;
      v_fpan_rng_strt_num             FPAN_ACCT_RNG.RNG_STRT_NUM%TYPE;
      rec_dpan_acct_rng               DPAN_ACCT_RNG%ROWTYPE;
      v_msg                           VARCHAR2(1000);
      rows_deleted                    NUMBER := 0;
      REQUIRED_PARM_NULL              EXCEPTION;


   PROCEDURE LPRC_DELETE_DPAN_POOL (
       in_dpan_rng_strt_num           IN DPAN_ACCT_RNG.RNG_STRT_NUM%TYPE)
   IS
       BEGIN
          v_msg := vc_proc_name || ': starting LPRC_DELETE_DPAN_POOL';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          v_msg := vc_proc_name || ': processing in_dpan = ' || in_dpan_rng_strt_num;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      --------------------------------------------------------------------------
      -- delete dpan pool data:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM SITE_DPAN_RECYCLE ...');
      DELETE FROM SITE_DPAN_RECYCLE WHERE DPAN_RNG_STRT_NUM = in_dpan_rng_strt_num;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': SITE_DPAN_RECYCLE rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;
      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM SITE_DPAN_POOL ...');
      DELETE FROM SITE_DPAN_POOL WHERE DPAN_RNG_STRT_NUM = in_dpan_rng_strt_num;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': SITE_DPAN_POOL rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;
      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM SITE_DPAN_POOL_NXT ...');
      DELETE FROM SITE_DPAN_POOL_NXT WHERE DPAN_RNG_STRT_NUM = in_dpan_rng_strt_num;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': SITE_DPAN_POOL_NXT rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;
      
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM SITE_DPAN_RNG_DEPLT ...');
      DELETE FROM SITE_DPAN_RNG_DEPLT WHERE DPAN_RNG_STRT_NUM = in_dpan_rng_strt_num;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': SITE_DPAN_RNG_DEPLT rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      v_msg := vc_proc_name || ': completed LPRC_DELETE_DPAN_POOL';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
   END;


   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ...');
      out_rtn_cd := 0;

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_fpan_rng_strt_num IS NULL THEN
          out_rtn_msg := vc_proc_name || ': in_fpan_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- reformat range into 19 digit value:
      --------------------------------------------------------------------------
      v_fpan_rng_strt_num := RPAD(in_fpan_rng_strt_num, 19, '0');
      v_msg := vc_proc_name || ': v_fpan_rng_strt_num = ' || v_fpan_rng_strt_num;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);

      --------------------------------------------------------------------------
      -- process all the dpan ranges for this fpan:
      --------------------------------------------------------------------------
      
      v_msg := vc_proc_name || ': DEBUGGING .... ';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
      
      FOR rec_dpan_acct_rng IN
          (SELECT * FROM DPAN_ACCT_RNG 
            WHERE FPAN_RNG_STRT_NUM = v_fpan_rng_strt_num)
      LOOP
          v_msg := vc_proc_name || ': rec_dpan_acct_rng.RNG_STRT_NUM = ' 
              || rec_dpan_acct_rng.RNG_STRT_NUM;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          v_msg := vc_proc_name || ': calling local procedure now ...';
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(v_msg);
          LPRC_DELETE_DPAN_POOL(rec_dpan_acct_rng.RNG_STRT_NUM);
      END LOOP;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': completed successfully.';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION
      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;
      WHEN OTHERS THEN
         ROLLBACK;
         out_rtn_cd  := -1000;
         out_rtn_msg := vc_proc_name || ': ' || in_fpan_rng_strt_num
                        || ' failed, Oracle error = ' || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG(out_rtn_msg);
     
   END PRC_DELETE_DPAN_POOL_DATA;
   PROCEDURE PRC_WHITE_CARD_DELETE (
                        in_rng_strt_num                    IN  VARCHAR2,      --required
                        out_rtn_cd                        OUT NUMBER,
                        out_rtn_msg                       OUT VARCHAR2)
   IS
      vc_proc_name                    VARCHAR2(50) := 'PRC_WHITE_CARD_DELETE';
      rows_deleted                    NUMBER := 0;
      REQUIRED_PARM_NULL              EXCEPTION;

   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';

      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
       IF in_rng_strt_num IS NULL THEN
          out_rtn_msg := 'in_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

  
      --------------------------------------------------------------------------
      -- delete WHITE_CARD:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': DELETE FROM WHITE_CARD...');
      DELETE FROM WHITE_CARD
       WHERE RNG_STRT_NUM = in_rng_strt_num;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('WHITE_CARD rows deleted: '|| SQL%ROWCOUNT);
      rows_deleted := SQL%ROWCOUNT + rows_deleted;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG('TOTAL ROWS deleted: '|| rows_deleted);
      COMMIT;
      out_rtn_msg := vc_proc_name || ': ' || in_rng_strt_num
                     || ' successfully deleted!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   EXCEPTION

      WHEN REQUIRED_PARM_NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
          out_rtn_cd := -1001;
          ROLLBACK;

      WHEN OTHERS
      THEN
         ROLLBACK;
         out_rtn_cd  := -1;
         out_rtn_msg := vc_proc_name || ': ' || in_rng_strt_num
                        || ' not deleted, Oracle error = ' 
                        || SUBSTR (SQLERRM, 1, 150);
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);

   END PRC_WHITE_CARD_DELETE;
//
   PROCEDURE PRC_ACCT_RNG_CLONE_WID (
                    in_new_rng_strt_num             IN  NUMBER,   --required
                    in_new_partn_num                IN  NUMBER,   --optional
                    in_base_wlt_prvdr_id            IN  NUMBER,
                    in_cloned_wlt_prvdr_id          IN  NUMBER,
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2)
    IS
      vc_proc_name                    VARCHAR2(50) := 'PRC_ACCT_RNG_CLONE_WID';
      vc_local_proc_name              VARCHAR2 (50);
      v_active_partn_num              ACTV_PARTN.PARTN_NUM%TYPE;
      v_new_partn_num                 ACTV_PARTN.PARTN_NUM%TYPE;
      v_new_rng_strt_num              ACCT_RNG_MBL_WLT_APPL.RNG_STRT_NUM%TYPE;
      rec_acct_rng_wlt_prvdr          ACCT_RNG_WLT_PRVDR%ROWTYPE;
      rec_acct_rng_wlt_prvdr_config   ACCT_RNG_WLT_PRVDR_CONFIG%ROWTYPE;
      v_wlt_prvdr_id                  MBL_WLT_APPL.WLT_PRVDR_ID%TYPE;
      v_count                         NUMBER;
      rows_deleted                    NUMBER := 0;
      NOT_FOUND                       EXCEPTION;
      REQUIRED_PARM_NULL              EXCEPTION;
   
   PROCEDURE LPRC_ACCT_RNG_CLONE_WID IS
   BEGIN
      --------------------------------------------------------------------------
      -- start local procedure:
      --------------------------------------------------------------------------
      vc_local_proc_name := 'LPRC_ACCT_RNG_CLONE_WID';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': STARTING ...');

      --------------------------------------------------------------------------
      -- first delete any account range data associated with this wallet 
      -- provider id:
      --------------------------------------------------------------------------
      PRVT_DELETE_ACCT_RNG_WID_DATA(v_new_rng_strt_num,
                                    v_new_partn_num,
                                    in_cloned_wlt_prvdr_id);

      --------------------------------------------------------------------------
      -- and now clone the wallet provider:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || 
          ': RETRIEVING BASE ACCT_RNG_WLT_PRVDR  ' 
          || v_new_partn_num || ', ' 
          || v_new_rng_strt_num || ', ' 
          || in_base_wlt_prvdr_id);
      SELECT * INTO rec_acct_rng_wlt_prvdr
        FROM ACCT_RNG_WLT_PRVDR
       WHERE RNG_STRT_NUM = v_new_rng_strt_num
         AND PARTN_NUM = v_new_partn_num
         AND WLT_PRVDR_ID = in_base_wlt_prvdr_id;

      rec_acct_rng_wlt_prvdr.WLT_PRVDR_ID := in_cloned_wlt_prvdr_id;
      rec_acct_rng_wlt_prvdr.RPLCTN_UPDT_TS := SYSDATE;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name 
              || ': INSERTING INTO ACCT_RNG_WLT_PRVDR: '
              || rec_acct_rng_wlt_prvdr.PARTN_NUM || ', ' 
              || rec_acct_rng_wlt_prvdr.RNG_STRT_NUM || ', ' 
              || rec_acct_rng_wlt_prvdr.WLT_PRVDR_ID);
          INSERT INTO ACCT_RNG_WLT_PRVDR
               VALUES rec_acct_rng_wlt_prvdr;

      --------------------------------------------------------------------------
      -- and clone ACCT_RNG_WLT_PRVDR_CONFIG:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || 
          ': RETRIEVING BASE ACCT_RNG_WLT_PRVDR_CONFIG  ' 
          || v_new_rng_strt_num || ', ' 
          || in_base_wlt_prvdr_id);
      FOR rec_acct_rng_wlt_prvdr_config IN
          (SELECT *
             FROM ACCT_RNG_WLT_PRVDR_CONFIG
            WHERE RNG_STRT_NUM = v_new_rng_strt_num 
              AND WLT_PRVDR_ID = in_base_wlt_prvdr_id)
      LOOP
          rec_acct_rng_wlt_prvdr_config.WLT_PRVDR_ID := in_cloned_wlt_prvdr_id;
          rec_acct_rng_wlt_prvdr_config.RPLCTN_UPDT_TS := SYSDATE;
          rec_acct_rng_wlt_prvdr_config.UPDT_DT := SYSDATE;

          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name 
              || ': INSERTING INTO ACCT_RNG_WLT_PRVDR_CONFIG: '
              || rec_acct_rng_wlt_prvdr_config.RNG_STRT_NUM || ', ' 
              || rec_acct_rng_wlt_prvdr_config.WLT_PRVDR_ID);
          INSERT INTO ACCT_RNG_WLT_PRVDR_CONFIG
               VALUES rec_acct_rng_wlt_prvdr_config;
      END LOOP;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': COMPLETED!');
      
   END;
    
    BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ...');
 
      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_new_rng_strt_num IS NULL THEN
          out_rtn_msg := 'in_new_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_base_wlt_prvdr_id IS NULL THEN
          out_rtn_msg := 'in_base_wlt_prvdr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_cloned_wlt_prvdr_id IS NULL THEN
          out_rtn_msg := 'in_cloned_wlt_prvdr_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- get active partition:
      --------------------------------------------------------------------------
      SELECT PARTN_NUM INTO v_active_partn_num FROM ACTV_PARTN;
      IF in_new_partn_num IS NULL THEN
          v_new_partn_num := v_active_partn_num;
      ELSE
          v_new_partn_num := in_new_partn_num;
      END IF;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': v_active_partn_num: '|| v_active_partn_num);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': v_new_partn_num: '|| v_new_partn_num);

      --------------------------------------------------------------------------
      -- reformat range into 19 digit values:
      --------------------------------------------------------------------------
      v_new_rng_strt_num := RPAD (in_new_rng_strt_num, 19, '0');
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': v_new_rng_strt_num: '|| v_new_rng_strt_num);
     
      --------------------------------------------------------------------------
      -- make sure ACCT_RNG_WLT_PRVDR to be cloned (if applicable) exists:
      --------------------------------------------------------------------------
      IF in_base_wlt_prvdr_id IS NOT NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
              ': CONFIRMING BASE ACCT_RNG_WLT_PRVDR EXISTS ...  ' 
              || v_new_partn_num || ',' 
              || v_new_rng_strt_num || ',' 
              || in_base_wlt_prvdr_id);
          SELECT COUNT(*) INTO v_count FROM ACCT_RNG_WLT_PRVDR
           WHERE PARTN_NUM = v_new_partn_num
             AND RNG_STRT_NUM = v_new_rng_strt_num
             AND WLT_PRVDR_ID = in_base_wlt_prvdr_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
              ': v_count = '  || v_count);
          IF v_count = 0 THEN
              out_rtn_msg := 'v_new_partn_num=' || v_new_partn_num
                  || ', in_base_wlt_prvdr_id=' || in_base_wlt_prvdr_id 
                  || ' not found in ACCT_RNG_WLT_PRVDR!';
              RAISE NOT_FOUND;
          END IF;      
      END IF;
  
      --------------------------------------------------------------------------
      -- now clone:
      --------------------------------------------------------------------------
      IF in_cloned_wlt_prvdr_id IS NOT NULL THEN
          LPRC_ACCT_RNG_CLONE_WID;
      END IF;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': PARTN_NUM=' || v_new_partn_num
          || ', RNG_STRT_NUM=' || v_new_rng_strt_num 
          || ', WLT_PRVDR_NAM="' || in_cloned_wlt_prvdr_id
          || '" completed!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
      COMMIT;
 
      EXCEPTION

         WHEN REQUIRED_PARM_NULL THEN
             PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
             out_rtn_cd := -1001;
             ROLLBACK;
         WHEN NOT_FOUND THEN
             PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
             out_rtn_cd := -1002;
             ROLLBACK;
         WHEN OTHERS THEN
             ROLLBACK;
             out_rtn_cd  := -1;
             out_rtn_msg := vc_proc_name || ': PARTN_NUM=' || v_new_partn_num
                 || ', RNG_STRT_NUM=' || v_new_rng_strt_num 
                 || ', WLT_PRVDR_ID="' || in_cloned_wlt_prvdr_id
                 || '" not cloned! Oracle error = '
                 || SUBSTR (SQLERRM, 1, 150);          
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);     
   END PRC_ACCT_RNG_CLONE_WID;
   PROCEDURE PRC_ACCT_RNG_CLONE_MWA (
                    in_new_rng_strt_num             IN  NUMBER,   --required
                    in_new_partn_num                IN  NUMBER,   --optional
                    in_base_mbl_wlt_id              IN  VARCHAR2,
                    in_cloned_mbl_wlt_id            IN  VARCHAR2,
                    out_rtn_cd                      OUT NUMBER,
                    out_rtn_msg                     OUT VARCHAR2)
    IS
      vc_proc_name                    VARCHAR2(50) := 'PRC_ACCT_RNG_CLONE_MWA';
      vc_local_proc_name              VARCHAR2 (50);
      v_active_partn_num              ACTV_PARTN.PARTN_NUM%TYPE;
      v_new_partn_num                 ACTV_PARTN.PARTN_NUM%TYPE;
      v_new_rng_strt_num              ACCT_RNG_MBL_WLT_APPL.RNG_STRT_NUM%TYPE;
      rec_acct_rng_mbl_wlt_appl       ACCT_RNG_MBL_WLT_APPL%ROWTYPE;
      rec_acct_rng_mbl_wlt_appl_cvm   ACCT_RNG_MBL_WLT_APPL_CVM%ROWTYPE;
      rec_issr_tds_config             ISSR_TDS_CONFIG%ROWTYPE;
      v_wlt_prvdr_id                  MBL_WLT_APPL.WLT_PRVDR_ID%TYPE;
      v_count                         NUMBER;
      rows_deleted                    NUMBER := 0;
      NOT_FOUND                       EXCEPTION;
      REQUIRED_PARM_NULL              EXCEPTION;

   
   PROCEDURE LPRC_ACCT_RNG_CLONE_MWA IS
   BEGIN
      --------------------------------------------------------------------------
      -- start local procedure:
      --------------------------------------------------------------------------
      vc_local_proc_name := 'LPRC_ACCT_RNG_CLONE_MWA';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': STARTING ...');

      --------------------------------------------------------------------------
      -- first delete any existing account range data associated with this 
      -- mobile wallet application:
      --------------------------------------------------------------------------
      PRVT_DELETE_ACCT_RNG_MWA_DATA(v_new_partn_num,
                                    v_new_rng_strt_num,
                                    in_cloned_mbl_wlt_id);
      
      --------------------------------------------------------------------------
      -- now retrieve WLT_PRVDR_ID from "cloned" MBL_WLT_APPL:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name 
          || ': RETRIEVING WLT_PRVDR_ID FROM MBL_WLT_APPL: '
                      || v_new_partn_num || ', ' || in_cloned_mbl_wlt_id);
                  SELECT WLT_PRVDR_ID INTO v_wlt_prvdr_id
                    FROM MBL_WLT_APPL
                   WHERE PARTN_NUM = v_new_partn_num
                     AND MBL_WLT_ID = in_cloned_mbl_wlt_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name 
          || ': v_wlt_prvdr_id = ' || v_wlt_prvdr_id);

      --------------------------------------------------------------------------
      -- now clone ACCT_RNG_MBL_WLT_APPL:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name ||
          ': RETRIEVING BASE ACCT_RNG_MBL_WLT_APPL ...' ||
          v_new_partn_num || ', ' || 
          v_new_rng_strt_num || ', ' ||
          in_base_mbl_wlt_id);
      SELECT * INTO rec_acct_rng_mbl_wlt_appl
        FROM ACCT_RNG_MBL_WLT_APPL
       WHERE PARTN_NUM = v_new_partn_num
         AND RNG_STRT_NUM = v_new_rng_strt_num
         AND MBL_WLT_ID = in_base_mbl_wlt_id;

      rec_acct_rng_mbl_wlt_appl.MBL_WLT_ID := in_cloned_mbl_wlt_id;
      rec_acct_rng_mbl_wlt_appl.WLT_PRVDR_ID := v_wlt_prvdr_id;
      rec_acct_rng_mbl_wlt_appl.RPLCTN_UPDT_TS := SYSDATE;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name 
              || ': INSERT INTO ACCT_RNG_MBL_WLT_APPL: '
              || rec_acct_rng_mbl_wlt_appl.PARTN_NUM || ', ' 
              || rec_acct_rng_mbl_wlt_appl.RNG_STRT_NUM || ', ' 
              || rec_acct_rng_mbl_wlt_appl.MBL_WLT_ID || ', ' 
              || rec_acct_rng_mbl_wlt_appl.WLT_PRVDR_ID);
          INSERT INTO ACCT_RNG_MBL_WLT_APPL
               VALUES rec_acct_rng_mbl_wlt_appl;

      --------------------------------------------------------------------------
      -- clone ACCT_RNG_MBL_WLT_APPL_CVM:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name ||
          ': RETRIEVING BASE ACCT_RNG_MBL_WLT_APPL_CVM...' ||
          v_new_partn_num || ', ' || 
          v_new_rng_strt_num || ', ' ||
          in_base_mbl_wlt_id);
      
      --row may or may not exist:
      FOR rec_acct_rng_mbl_wlt_appl_cvm IN
          (SELECT *
             FROM ACCT_RNG_MBL_WLT_APPL_CVM
            WHERE PARTN_NUM = v_new_partn_num 
              AND RNG_STRT_NUM = v_new_rng_strt_num
              AND MBL_WLT_ID = in_base_mbl_wlt_id)
      LOOP
          rec_acct_rng_mbl_wlt_appl_cvm.MBL_WLT_ID := in_cloned_mbl_wlt_id;
          rec_acct_rng_mbl_wlt_appl_cvm.WLT_PRVDR_ID := v_wlt_prvdr_id;
          rec_acct_rng_mbl_wlt_appl_cvm.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name 
              || ': INSERT INTO ACCT_RNG_MBL_WLT_APPL_CVM: '
              || rec_acct_rng_mbl_wlt_appl_cvm.PARTN_NUM || ', ' 
              || rec_acct_rng_mbl_wlt_appl_cvm.RNG_STRT_NUM || ', ' 
              || rec_acct_rng_mbl_wlt_appl_cvm.MBL_WLT_ID || ', ' 
              || rec_acct_rng_mbl_wlt_appl_cvm.WLT_PRVDR_ID);
          INSERT INTO ACCT_RNG_MBL_WLT_APPL_CVM
               VALUES rec_acct_rng_mbl_wlt_appl_cvm;
      END LOOP;

      --------------------------------------------------------------------------
      -- and finally ... clone ISSR_TDS_CONFIG:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name ||
          ': RETRIEVING BASE ISSR_TDS_CONFIG...' ||
          v_new_rng_strt_num || ', ' ||
          in_base_mbl_wlt_id);
      
      --pretty sure base row should exist but just in case:
      FOR rec_issr_tds_config IN
          (SELECT *
             FROM ISSR_TDS_CONFIG
            WHERE RNG_STRT_NUM = v_new_rng_strt_num
              AND MBL_WLT_ID = in_base_mbl_wlt_id)
      LOOP
          rec_issr_tds_config.MBL_WLT_ID := in_cloned_mbl_wlt_id;
          rec_issr_tds_config.WLT_PRVDR_ID := v_wlt_prvdr_id;
          rec_issr_tds_config.RPLCTN_UPDT_TS := SYSDATE;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name 
              || ': INSERT INTO ISSR_TDS_CONFIG: '
              || rec_issr_tds_config.RNG_STRT_NUM || ', ' 
              || rec_issr_tds_config.MBL_WLT_ID || ', ' 
              || rec_issr_tds_config.WLT_PRVDR_ID);
          INSERT INTO ISSR_TDS_CONFIG
               VALUES rec_issr_tds_config;
      END LOOP;

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_local_proc_name || ': COMPLETED!');
      
   END;
    
    BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      out_rtn_cd := 0;
      out_rtn_msg := vc_proc_name || ': ';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ...');
 
      --------------------------------------------------------------------------
      -- check required parameters:
      --------------------------------------------------------------------------
      IF in_new_rng_strt_num IS NULL THEN
          out_rtn_msg := 'in_new_rng_strt_num cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_base_mbl_wlt_id IS NULL THEN
          out_rtn_msg := 'in_base_mbl_wlt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;
      IF in_cloned_mbl_wlt_id IS NULL THEN
          out_rtn_msg := 'in_cloned_mbl_wlt_id cannot be null!';
          RAISE REQUIRED_PARM_NULL;
      END IF;

      --------------------------------------------------------------------------
      -- get active partition:
      --------------------------------------------------------------------------
      SELECT PARTN_NUM INTO v_active_partn_num FROM ACTV_PARTN;
      IF in_new_partn_num IS NULL THEN
          v_new_partn_num := v_active_partn_num;
      ELSE
          v_new_partn_num := in_new_partn_num;
      END IF;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': v_active_partn_num: '|| v_active_partn_num);
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': v_new_partn_num: '|| v_new_partn_num);

      --------------------------------------------------------------------------
      -- reformat range into 19 digit values:
      --------------------------------------------------------------------------
      v_new_rng_strt_num := RPAD (in_new_rng_strt_num, 19, '0');
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name 
          || ': v_new_rng_strt_num: '|| v_new_rng_strt_num);

      --------------------------------------------------------------------------
      -- make sure ACCT_RNG_MBL_WLT_APPL to be cloned (if applicable) exists:
      --------------------------------------------------------------------------
      IF in_base_mbl_wlt_id IS NOT NULL THEN
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
              ': CONFIRMING BASE ACCT_RNG_MBL_WLT_APPL EXISTS ...  ' 
              || v_new_partn_num || ', ' 
              || v_new_rng_strt_num || ', ' 
              || in_base_mbl_wlt_id);
          SELECT COUNT(*) INTO v_count FROM ACCT_RNG_MBL_WLT_APPL
           WHERE PARTN_NUM = v_new_partn_num
             AND RNG_STRT_NUM = v_new_rng_strt_num
             AND MBL_WLT_ID = in_base_mbl_wlt_id;
          PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
              ': v_count = '  || v_count);
          IF v_count = 0 THEN
              out_rtn_msg := 'v_new_partn_num=' || v_new_partn_num
                  || ', in_base_mbl_wlt_id=' || in_base_mbl_wlt_id 
                  || ' not found in ACCT_RNG_MBL_WLT_APPL!';
              RAISE NOT_FOUND;
          END IF;      
      END IF;
      
      --------------------------------------------------------------------------
      -- now clone:
      --------------------------------------------------------------------------
      IF in_cloned_mbl_wlt_id IS NOT NULL THEN
          LPRC_ACCT_RNG_CLONE_MWA;
      END IF;

      --------------------------------------------------------------------------
      -- DONE:
      --------------------------------------------------------------------------
      COMMIT;
      out_rtn_msg := vc_proc_name || ': PARTN_NUM=' || v_new_partn_num
          || ', RNG_STRT_NUM=' || v_new_rng_strt_num 
          || ', MBL_WLT_ID=' || in_cloned_mbl_wlt_id 
          || '" completed!';
      PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
      COMMIT;
 
      EXCEPTION

         WHEN REQUIRED_PARM_NULL THEN
             PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
             out_rtn_cd := -1001;
             ROLLBACK;
         WHEN NOT_FOUND THEN
             PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);
             out_rtn_cd := -1002;
             ROLLBACK;
         WHEN OTHERS THEN
             ROLLBACK;
             out_rtn_cd  := -1;
             out_rtn_msg := vc_proc_name || ': PARTN_NUM=' || v_new_partn_num
                 || ', RNG_STRT_NUM=' || v_new_rng_strt_num 
                 || ', MBL_WLT_ID=' || in_cloned_mbl_wlt_id 
                 || '" not cloned! Oracle error = '
                 || SUBSTR (SQLERRM, 1, 150);          
         PKG_UTILITIES.PRC_OUTPUT_DEBUG (out_rtn_msg);     
    END PRC_ACCT_RNG_CLONE_MWA;
   PROCEDURE PRVT_DELETE_ACCT_RNG_MWA_DATA (
                      in_rng_strt_num                 IN  NUMBER,   --optional
                      in_partn_num                    IN  NUMBER,   --optional
                      in_mbl_wlt_appl_id              IN  VARCHAR2) --required
   IS
      vc_proc_name          VARCHAR2 (50) := 'PRVT_DELETE_ACCT_RNG_MWA_DATA';
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 'STARTING ...');
      
      --delete ISSR_TDS_CONFIG by rng_strt_num and mbl_wlt_appl_id:
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': DELETING EXISTING ISSR_TDS_CONFIG DATA FOR ' ||
          ',in_rng_strt_num=' || in_rng_strt_num || 
          ',in_mbl_wlt_appl_id=' || in_mbl_wlt_appl_id);
      DELETE FROM ISSR_TDS_CONFIG
            WHERE RNG_STRT_NUM = NVL(in_rng_strt_num, RNG_STRT_NUM)
              AND MBL_WLT_ID = in_mbl_wlt_appl_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ISSR_TDS_CONFIG rows deleted: '|| SQL%ROWCOUNT);

      --delete ACCT_RNG_MBL_WLT_APPL_CVM by rng_strt_num, partn_num (optionally)
      --and mbl_wlt_appl_id:
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': DELETING EXISTING ACCT_RNG_MBL_WLT_APPL_CVM DATA FOR ' ||
          'in_partn_num=' || in_partn_num || 
          ',in_rng_strt_num=' || in_rng_strt_num || 
          ',in_mbl_wlt_appl_id=' || in_mbl_wlt_appl_id);
      DELETE FROM ACCT_RNG_MBL_WLT_APPL_CVM
            WHERE PARTN_NUM = NVL(in_partn_num, PARTN_NUM)
              AND RNG_STRT_NUM = NVL(in_rng_strt_num, RNG_STRT_NUM)
              AND MBL_WLT_ID = in_mbl_wlt_appl_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_MBL_WLT_APPL_CVM rows deleted: '|| SQL%ROWCOUNT);

      --delete ACCT_RNG_MBL_WLT_APPL by rng_strt_num, partn_num (optionally)
      --and mbl_wlt_appl_id:
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': DELETING EXISTING ACCT_RNG_MBL_WLT_APPL DATA FOR ' ||
          'in_partn_num=' || in_partn_num || 
          ',in_rng_strt_num=' || in_rng_strt_num || 
          ',in_mbl_wlt_appl_id=' || in_mbl_wlt_appl_id);
      DELETE FROM ACCT_RNG_MBL_WLT_APPL
            WHERE PARTN_NUM = NVL(in_partn_num, PARTN_NUM)
              AND RNG_STRT_NUM = NVL(in_rng_strt_num, RNG_STRT_NUM)
              AND MBL_WLT_ID = in_mbl_wlt_appl_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_MBL_WLT_APPL rows deleted: '|| SQL%ROWCOUNT);

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 'COMPLETED ...');

   END PRVT_DELETE_ACCT_RNG_MWA_DATA;
   PROCEDURE PRVT_DELETE_ACCT_RNG_WID_DATA (
                      in_rng_strt_num                 IN  NUMBER,   --optional
                      in_partn_num                    IN  NUMBER,   --optional
                      in_wlt_prvdr_id                 IN  NUMBER)   --required
   IS
      vc_proc_name          VARCHAR2 (50) := 'PRVT_DELETE_ACCT_RNG_WID_DATA';
      v_count               NUMBER;
   
   BEGIN
      --------------------------------------------------------------------------
      -- initialize output parameters:
      --------------------------------------------------------------------------
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': STARTING ...');
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': in_rng_strt_num=' ||
        in_rng_strt_num || ',in_partn_num=' || in_partn_num ||
        ',in_wlt_prvdr_id=' || in_wlt_prvdr_id);
      
      --delete ISSR_TDS_CONFIG by rng_strt_num and wlt_prvdr_id:
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': DELETING EXISTING ISSR_TDS_CONFIG DATA FOR ' ||
          ',in_rng_strt_num=' || in_rng_strt_num || 
          ',in_wlt_prvdr_id=' || in_wlt_prvdr_id);
      DELETE FROM ISSR_TDS_CONFIG
            WHERE RNG_STRT_NUM = NVL(in_rng_strt_num, RNG_STRT_NUM)
              AND WLT_PRVDR_ID = in_wlt_prvdr_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ISSR_TDS_CONFIG rows deleted: '|| SQL%ROWCOUNT);

      --delete ACCT_RNG_MBL_WLT_APPL_CVM by rng_strt_num, partn_num (optionally)
      --and wlt_prvdr_id:
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': DELETING EXISTING ACCT_RNG_MBL_WLT_APPL_CVM DATA FOR ' ||
          'in_partn_num=' || in_partn_num || 
          ',in_rng_strt_num=' || in_rng_strt_num || 
          ',in_wlt_prvdr_id=' || in_wlt_prvdr_id);
      DELETE FROM ACCT_RNG_MBL_WLT_APPL_CVM
            WHERE PARTN_NUM = NVL(in_partn_num, PARTN_NUM)
              AND RNG_STRT_NUM = NVL(in_rng_strt_num, RNG_STRT_NUM)
              AND WLT_PRVDR_ID = in_wlt_prvdr_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_MBL_WLT_APPL_CVM rows deleted: '|| SQL%ROWCOUNT);

      --delete ACCT_RNG_MBL_WLT_APPL by rng_strt_num, partn_num (optionally)
      --and wlt_prvdr_id:
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': DELETING EXISTING ACCT_RNG_MBL_WLT_APPL DATA FOR ' ||
          'in_partn_num=' || in_partn_num || 
          ',in_rng_strt_num=' || in_rng_strt_num || 
          ',in_wlt_prvdr_id=' || in_wlt_prvdr_id);
      DELETE FROM ACCT_RNG_MBL_WLT_APPL
            WHERE PARTN_NUM = NVL(in_partn_num, PARTN_NUM)
              AND RNG_STRT_NUM = NVL(in_rng_strt_num, RNG_STRT_NUM)
              AND WLT_PRVDR_ID = in_wlt_prvdr_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_MBL_WLT_APPL rows deleted: '|| SQL%ROWCOUNT);

      --delete ACCT_RNG_WLT_PRVDR_CONFIG by rng_strt_num and wlt_prvdr_id:
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': DELETING EXISTING ACCT_RNG_WLT_PRVDR_CONFIG FOR' ||
          ',in_rng_strt_num=' || in_rng_strt_num || 
          ',in_wlt_prvdr_id=' || in_wlt_prvdr_id);
      DELETE FROM ACCT_RNG_WLT_PRVDR_CONFIG
       WHERE RNG_STRT_NUM = NVL(in_rng_strt_num, RNG_STRT_NUM)
         AND WLT_PRVDR_ID = in_wlt_prvdr_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_WLT_PRVDR_CONFIG rows deleted: ' || SQL%ROWCOUNT);

      --delete ACCT_RNG_MBL_WLT_APPL_CVM by rng_strt_num, partn_num (optionally)
      --and wlt_prvdr_id:
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': DELETING EXISTING ACCT_RNG_WLT_PRVDR DATA FOR ' ||
          'in_partn_num=' || in_partn_num || 
          ',in_rng_strt_num=' || in_rng_strt_num || 
          ',in_wlt_prvdr_id=' || in_wlt_prvdr_id);
      DELETE FROM ACCT_RNG_WLT_PRVDR
            WHERE PARTN_NUM = NVL(in_partn_num, PARTN_NUM)
              AND RNG_STRT_NUM = NVL(in_rng_strt_num, RNG_STRT_NUM)
              AND WLT_PRVDR_ID = in_wlt_prvdr_id;
      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || 
          ': ACCT_RNG_WLT_PRVDR rows deleted: '|| SQL%ROWCOUNT);

      PKG_UTILITIES.PRC_OUTPUT_DEBUG(vc_proc_name || ': COMPLETED ...');

   END PRVT_DELETE_ACCT_RNG_WID_DATA;

                      
   FUNCTION GENERATE_CLONED_ID (
                      in_base_id                    IN  VARCHAR2,  --required
                      in_prefix                     IN  VARCHAR2,  --required
                      in_max_len                    IN  NUMBER)   --required
                      RETURN VARCHAR2
   IS
      v_cloned_id     VARCHAR2 (250);
      v_suffix        VARCHAR2(250) := '-' || in_prefix;
      v_suffix_len    NUMBER;
      v_base_id_len   NUMBER := LENGTH(in_base_id);
      v_base_substr   VARCHAR2 (250);
      v_max_base_len  NUMBER;
   BEGIN
       v_suffix_len := LENGTH(v_suffix);
       --PKG_UTILITIES.PRC_OUTPUT_DEBUG ('v_suffix_len=' || v_suffix_len);
       v_max_base_len := in_max_len - v_suffix_len;
       --PKG_UTILITIES.PRC_OUTPUT_DEBUG ('v_max_base_len=' || v_max_base_len);
       IF (v_base_id_len < v_max_base_len) THEN
           v_cloned_id := in_base_id || v_suffix;
       ELSE 
           v_base_substr := SUBSTR(in_base_id,1,v_max_base_len);
           v_cloned_id := v_base_substr || v_suffix;
       END IF;
       --PKG_UTILITIES.PRC_OUTPUT_DEBUG ('v_cloned_id=' || v_cloned_id);
       RETURN v_cloned_id;
   END;

END PKG_DATA_MANAGEMENT;


/
