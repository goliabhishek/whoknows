ALTER SESSION SET CURRENT_SCHEMA = &schema;
/* Formatted on 1/2/2015 12:41:34 PM (QP5 v5.227.12220.39724) */
SET SERVEROUTPUT ON;

SPOOL validation_result.txt

DECLARE
   n_rtn_cd     INTEGER := 0;
   vc_rtn_msg   VARCHAR2 (5000) := ' ';
   n_partn_num  NUMBER := &partn_num;
BEGIN
   --DBMS_OUTPUT.enable(null);
   DBMS_OUTPUT.enable (100000);
   
   PKG_UTILITIES.PRC_SET_DEBUG (FALSE);

   -- if partition numbers are not passed in, the current active partition will be validated
   PKG_DATA_VALIDATION.prc_validate_main (an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg, an_partn_num => n_partn_num, an_ref_partn_num => null);
--   PKG_DATA_VALIDATION.prc_validate_product_config (
--      avc_config_uuid   => 'E9E4E170-DC90-4FCB-8F8E-3129C343B779',
--      an_rtn_cd         => n_rtn_cd,
--      avc_rtn_msg       => vc_rtn_msg);

   -- test 1, fpan range missing dpan range
--   pkg_data_validation.prc_validate_dpan_ranges(an_partn_num => 0, an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   -- test 2, wlt_prvdr_parm validate
--   pkg_data_validation.prc_validate_wlt_prvdr_parm(an_partn_num => 2, an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   -- test 3, token_type validate
--   pkg_data_validation.prc_validate_token_types(an_partn_num => 5, an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   -- test 4, acct_rng_mdes_parm
--   pkg_data_validation.prc_validate_all_ar_parms(an_partn_num => 2, an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   -- test 5, acct_rng_token_type
--   pkg_data_validation.prc_validate_acct_rng_tt_tbls(an_partn_num => 2, an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   -- test 6, acct_rng_wlt_prvdr
--   pkg_data_validation.prc_validate_ar_wlt_prvdr(an_partn_num => 2, an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   -- test 7, acct_rng_ntwrk_msg
--   pkg_data_validation.prc_validate_network_message(an_partn_num => 2, an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   -- test 8, acct_rng_bitmap_parm
--   pkg_data_validation.prc_validate_ar_bitmap_parm(an_partn_num => 2, an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   -- test 9, prdct_config
--   pkg_data_validation.prc_validate_product_config(avc_config_uuid => '2bf88a20-629f-11e3-949a-501b200c7c01', an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   -- test 10, wlt_prvdr
--   pkg_data_validation.prc_validate_wallet_provider(an_partn_num => 2, an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   -- test 11, rule_set
--   pkg_data_validation.prc_validate_ar_rule_set(an_partn_num => 2, an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   -- test 12, crdntl_mgr
--   pkg_data_validation.prc_validate_ar_crdntl_mgr(an_partn_num => 2, an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   -- test 13, data profile selection
--   pkg_data_validation.prc_validate_dp_profile_select(an_partn_num => 2, an_rtn_cd => n_rtn_cd, avc_rtn_msg => vc_rtn_msg);

   DBMS_OUTPUT.PUT_LINE ('FINAL RESULT: code: ' || n_rtn_cd || ', message: ' || vc_rtn_msg);
END;
/

SPOOL OFF;

PROMPT "Finish...";